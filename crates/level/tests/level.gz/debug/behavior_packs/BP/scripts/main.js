// scripts/main.ts
import {
  world as world41,
  BlockTypes as BlockTypes10,
  system as system33,
  BlockPermutation as BlockPermutation15,
  BlockVolume as BlockVolume5
} from "@minecraft/server";

// scripts/command/debug.ts
import {
  CustomCommandParamType as CustomCommandParamType3,
  system as system32
} from "@minecraft/server";

// scripts/constants.ts
var PROJECT_ID = "lpsm_dw";

// scripts/utils.ts
function makeId(path) {
  return `${PROJECT_ID}:${path}`;
}

// node_modules/@lpsmods/mc-utils/src/data/data_storage.ts
import { world as world12 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/data/utils.ts
import {
  BlockPermutation as BlockPermutation4,
  BlockTypes as BlockTypes2,
  DimensionTypes as DimensionTypes2,
  EffectTypes,
  EnchantmentTypes,
  EntityTypes as EntityTypes2,
  ItemTypes as ItemTypes2,
  world as world11
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/type.ts
import {
  Block as Block2,
  BlockPermutation as BlockPermutation3,
  BlockType as BlockType2,
  Container,
  Dimension as Dimension4,
  DimensionType,
  EffectType,
  EnchantmentType,
  Entity as Entity3,
  EntityType,
  ItemStack,
  ItemType,
  world as world3
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/chunk/base.ts
import {
  BlockVolume as BlockVolume3,
  system as system3,
  world as world2
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/drawer.ts
import { BlockPermutation, LocationInUnloadedChunkError, system as system2, world } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/ticking.ts
import { system } from "@minecraft/server";
var Ticking = class _Ticking {
  static all = /* @__PURE__ */ new Map();
  enabled = false;
  runId;
  constructor(tickInterval) {
    this.runId = this.init(tickInterval);
    _Ticking.all.set(this.runId, this);
  }
  pTick() {
    if (!this.enabled) return;
    if (this.tick) this.tick();
  }
  /**
   * Creates the tick event.
   * @param {number} tickInterval An interval of every N ticks that the callback will be called upon.
   */
  init(tickInterval) {
    return system.runInterval(this.pTick.bind(this), tickInterval);
  }
  /**
   * Clears this classes ticking.
   */
  remove() {
    if (!this.runId) return;
    system.clearRun(this.runId);
    _Ticking.all.delete(this.runId);
  }
};

// node_modules/@minecraft/math/lib/general/clamp.js
function clampNumber(val, min2, max2) {
  return Math.min(Math.max(val, min2), max2);
}

// node_modules/@minecraft/math/lib/vector3/coreHelpers.js
var Vector3Utils = class _Vector3Utils {
  /**
   * equals
   *
   * Check the equality of two vectors
   */
  static equals(v1, v2) {
    return v1.x === v2.x && v1.y === v2.y && v1.z === v2.z;
  }
  /**
   * add
   *
   * Add two vectors to produce a new vector
   */
  static add(v1, v2) {
    return { x: v1.x + (v2.x ?? 0), y: v1.y + (v2.y ?? 0), z: v1.z + (v2.z ?? 0) };
  }
  /**
   * subtract
   *
   * Subtract two vectors to produce a new vector (v1-v2)
   */
  static subtract(v1, v2) {
    return { x: v1.x - (v2.x ?? 0), y: v1.y - (v2.y ?? 0), z: v1.z - (v2.z ?? 0) };
  }
  /** scale
   *
   * Multiple all entries in a vector by a single scalar value producing a new vector
   */
  static scale(v1, scale) {
    return { x: v1.x * scale, y: v1.y * scale, z: v1.z * scale };
  }
  /**
   * dot
   *
   * Calculate the dot product of two vectors
   */
  static dot(a2, b2) {
    return a2.x * b2.x + a2.y * b2.y + a2.z * b2.z;
  }
  /**
   * cross
   *
   * Calculate the cross product of two vectors. Returns a new vector.
   */
  static cross(a2, b2) {
    return { x: a2.y * b2.z - a2.z * b2.y, y: a2.z * b2.x - a2.x * b2.z, z: a2.x * b2.y - a2.y * b2.x };
  }
  /**
   * magnitude
   *
   * The magnitude of a vector
   */
  static magnitude(v2) {
    return Math.sqrt(v2.x ** 2 + v2.y ** 2 + v2.z ** 2);
  }
  /**
   * distance
   *
   * Calculate the distance between two vectors
   */
  static distance(a2, b2) {
    return _Vector3Utils.magnitude(_Vector3Utils.subtract(a2, b2));
  }
  /**
   * normalize
   *
   * Takes a vector 3 and normalizes it to a unit vector
   */
  static normalize(v2) {
    const mag = _Vector3Utils.magnitude(v2);
    return { x: v2.x / mag, y: v2.y / mag, z: v2.z / mag };
  }
  /**
   * floor
   *
   * Floor the components of a vector to produce a new vector
   */
  static floor(v2) {
    return { x: Math.floor(v2.x), y: Math.floor(v2.y), z: Math.floor(v2.z) };
  }
  /**
   * toString
   *
   * Create a string representation of a vector3
   */
  static toString(v2, options) {
    const decimals = options?.decimals ?? 2;
    const str = [v2.x.toFixed(decimals), v2.y.toFixed(decimals), v2.z.toFixed(decimals)];
    return str.join(options?.delimiter ?? ", ");
  }
  /**
   * fromString
   *
   * Gets a Vector3 from the string representation produced by {@link Vector3Utils.toString}. If any numeric value is not a number
   * or the format is invalid, undefined is returned.
   * @param str - The string to parse
   * @param delimiter - The delimiter used to separate the components. Defaults to the same as the default for {@link Vector3Utils.toString}
   */
  static fromString(str, delimiter = ",") {
    const parts = str.split(delimiter);
    if (parts.length !== 3) {
      return void 0;
    }
    const output = parts.map((part) => parseFloat(part));
    if (output.some((part) => isNaN(part))) {
      return void 0;
    }
    return { x: output[0], y: output[1], z: output[2] };
  }
  /**
   * clamp
   *
   * Clamps the components of a vector to limits to produce a new vector
   */
  static clamp(v2, limits) {
    return {
      x: clampNumber(v2.x, limits?.min?.x ?? Number.MIN_SAFE_INTEGER, limits?.max?.x ?? Number.MAX_SAFE_INTEGER),
      y: clampNumber(v2.y, limits?.min?.y ?? Number.MIN_SAFE_INTEGER, limits?.max?.y ?? Number.MAX_SAFE_INTEGER),
      z: clampNumber(v2.z, limits?.min?.z ?? Number.MIN_SAFE_INTEGER, limits?.max?.z ?? Number.MAX_SAFE_INTEGER)
    };
  }
  /**
   * lerp
   *
   * Constructs a new vector using linear interpolation on each component from two vectors.
   */
  static lerp(a2, b2, t4) {
    return { x: a2.x + (b2.x - a2.x) * t4, y: a2.y + (b2.y - a2.y) * t4, z: a2.z + (b2.z - a2.z) * t4 };
  }
  /**
   * slerp
   *
   * Constructs a new vector using spherical linear interpolation on each component from two vectors.
   */
  static slerp(a2, b2, t4) {
    const theta = Math.acos(_Vector3Utils.dot(a2, b2));
    const sinTheta = Math.sin(theta);
    const ta = Math.sin((1 - t4) * theta) / sinTheta;
    const tb = Math.sin(t4 * theta) / sinTheta;
    return _Vector3Utils.add(_Vector3Utils.scale(a2, ta), _Vector3Utils.scale(b2, tb));
  }
  /**
   * multiply
   *
   * Element-wise multiplication of two vectors together.
   * Not to be confused with {@link Vector3Utils.dot} product or {@link Vector3Utils.cross} product
   */
  static multiply(a2, b2) {
    return { x: a2.x * b2.x, y: a2.y * b2.y, z: a2.z * b2.z };
  }
  /**
   * rotateX
   *
   * Rotates the vector around the x axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateX(v2, a2) {
    const cos = Math.cos(a2);
    const sin = Math.sin(a2);
    return { x: v2.x, y: v2.y * cos - v2.z * sin, z: v2.z * cos + v2.y * sin };
  }
  /**
   * rotateY
   *
   * Rotates the vector around the y axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateY(v2, a2) {
    const cos = Math.cos(a2);
    const sin = Math.sin(a2);
    return { x: v2.x * cos + v2.z * sin, y: v2.y, z: v2.z * cos - v2.x * sin };
  }
  /**
   * rotateZ
   *
   * Rotates the vector around the z axis counterclockwise (left hand rule)
   * @param a - Angle in radians
   */
  static rotateZ(v2, a2) {
    const cos = Math.cos(a2);
    const sin = Math.sin(a2);
    return { x: v2.x * cos - v2.y * sin, y: v2.y * cos + v2.x * sin, z: v2.z };
  }
};
var VECTOR3_UP = { x: 0, y: 1, z: 0 };
var VECTOR3_DOWN = { x: 0, y: -1, z: 0 };
var VECTOR3_ZERO = { x: 0, y: 0, z: 0 };
var VECTOR3_WEST = { x: -1, y: 0, z: 0 };
var VECTOR3_EAST = { x: 1, y: 0, z: 0 };
var VECTOR3_NORTH = { x: 0, y: 0, z: 1 };
var VECTOR3_SOUTH = { x: 0, y: 0, z: -1 };
var VECTOR2_ZERO = { x: 0, y: 0 };

// node_modules/@lpsmods/mc-utils/src/constants.ts
var MAX_EFFECT = 2e7;
var CENTER_ENTITY = { x: 0.5, y: 0, z: 0.5 };
var CANDLES = [
  "candle",
  "white_candle",
  "light_gray_candle",
  "gray_candle",
  "black_candle",
  "brown_candle",
  "red_candle",
  "orange_candle",
  "yellow_candle",
  "lime_candle",
  "green_candle",
  "cyan_candle",
  "light_blue_candle",
  "blue_candle",
  "purple_candle",
  "magenta_candle",
  "pink_candle"
];
var COLORS = [
  "white",
  "light_gray",
  "gray",
  "black",
  "brown",
  "red",
  "orange",
  "yellow",
  "lime",
  "green",
  "cyan",
  "light_blue",
  "blue",
  "purple",
  "magenta",
  "pink"
];

// node_modules/@lpsmods/mc-utils/src/drawer.ts
var Drawer = class extends Ticking {
  dimensionId;
  tickInterval;
  removeWhenEmpty;
  shapes = [];
  /**
   * Create a new drawer context.
   * @param {number} tickInterval
   * @param {Dimension} dimensionId
   * @param {boolean} removeWhenEmpty Removes this drawer when it has no shapes to draw.
   */
  constructor(dimensionId, tickInterval, removeWhenEmpty = true) {
    super();
    this.removeWhenEmpty = removeWhenEmpty;
    this.tickInterval = tickInterval;
    this.dimensionId = dimensionId;
  }
  get dimension() {
    return world.getDimension(this.dimensionId);
  }
  /**
   * Adds a new shape to the world.
   * @param {Shape} shape
   */
  addShape(shape) {
    shape.drawer = this;
    this.shapes.push(shape);
  }
  add = this.addShape;
  /**
   * Removes all shapes from the world.
   */
  removeAll() {
    this.shapes = [];
  }
  /**
   * Removes an instance of a shape from the world.
   * @param {Shape} shape
   */
  removeShape(shape) {
    const index = this.shapes.indexOf(shape);
    this.shapes.splice(index, 1);
  }
  tick() {
    if (this.removeWhenEmpty && this.shapes.length === 0) {
      this.remove();
    }
    for (const shape of this.shapes) {
      if (!shape) continue;
      if (shape.hasDuration && system2.currentTick % 20 === 0) {
        if (shape.timeLeft > 0) {
          shape.timeLeft--;
        } else {
          shape.remove();
        }
      }
      if (this.tickInterval && system2.currentTick % this.tickInterval === 0) continue;
      if (shape.onTick) shape.onTick(shape);
      this.drawShape(shape);
    }
  }
};
var ParticleDrawer = class extends Drawer {
  drawShape(shape) {
    var palette = shape.material ?? "minecraft:endrod";
    for (let pos of shape.getPoints()) {
      try {
        pos = Vector3Utils.add(pos, CENTER_ENTITY);
        if (palette instanceof BlockPermutation) palette = "minecraft:endrod";
        this.dimension.spawnParticle(palette, pos);
      } catch (err) {
      }
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/math.ts
import { BlockVolume, Entity } from "@minecraft/server";
var MathUtils = class _MathUtils {
  /**
   * Combines multiple block volumes into one bounding box.
   * @param {BlockVolume[]} volumes
   * @returns {BlockVolume}
   */
  static combineBlockVolumes(volumes) {
    if (volumes.length === 0) {
      throw new Error("Volume array cannot be empty");
    }
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    for (const { from, to } of volumes) {
      const bounds = this.getBounds(from, to);
      if (bounds.minX < minX) minX = bounds.minX;
      if (bounds.minY < minY) minY = bounds.minY;
      if (bounds.minZ < minZ) minZ = bounds.minZ;
      if (bounds.maxX > maxX) maxX = bounds.maxX;
      if (bounds.maxY > maxY) maxY = bounds.maxY;
      if (bounds.maxZ > maxZ) maxZ = bounds.maxZ;
    }
    return new BlockVolume({ x: minX, y: minY, z: minZ }, { x: maxX, y: maxY, z: maxZ });
  }
  /**
   * Whether or not the VALUE is within MIN and MAX.
   * @param {number} value
   * @param {number} min
   * @param {number} max
   * @returns {number}
   */
  static inRange(value, min2, max2) {
    return min2 <= value && max2 >= value;
  }
  /**
   * Expands a region by amount.
   * @param {Vector3} from
   * @param {Vector3} to
   * @param {number} amount
   * @returns {{from: Vector3, to: Vector3}}
   */
  static expandRegion(from, to, amount = 1) {
    const min2 = {
      x: Math.min(from.x, to.x) - amount,
      y: Math.min(from.y, to.y) - amount,
      z: Math.min(from.z, to.z) - amount
    };
    const max2 = {
      x: Math.max(from.x, to.x) + amount,
      y: Math.max(from.y, to.y) + amount,
      z: Math.max(from.z, to.z) + amount
    };
    return { from: min2, to: max2 };
  }
  /**
   * Whether or not the entity is in a rectangle.
   * @param {Entity|Vector} origin
   * @param {Vector3} from
   * @param {Vector3} to
   * @returns {boolean}
   */
  static isInRect(origin, from, to) {
    const bounds = _MathUtils.getBounds(from, to);
    let loc = origin instanceof Entity ? Vector3Utils.floor(origin.location) : origin;
    return loc.x >= bounds.minX && loc.x <= bounds.maxX && loc.y >= bounds.minY && loc.y <= bounds.maxY && loc.z >= bounds.minZ && loc.z <= bounds.maxZ;
  }
  /**
   * Normalizes the min and max locations.
   * @param {Vector3} from
   * @param {Vector3} to
   * @returns
   */
  static getBounds(from, to) {
    const minX = Math.min(from.x, to.x);
    const maxX = Math.max(from.x, to.x);
    const minY = Math.min(from.y, to.y);
    const maxY = Math.max(from.y, to.y);
    const minZ = Math.min(from.z, to.z);
    const maxZ = Math.max(from.z, to.z);
    return {
      minX,
      maxX,
      minY,
      maxY,
      minZ,
      maxZ
    };
  }
  /**
   * Calculates the size of the box.
   * @param {Vector3} from
   * @param {Vector3} to
   * @returns {Vector3}
   */
  static getSize(from, to) {
    const bounds = _MathUtils.getBounds(from, to);
    return {
      x: bounds.maxX - bounds.minX + 1,
      y: bounds.maxY - bounds.minY + 1,
      z: bounds.maxZ - bounds.minZ + 1
    };
  }
  /**
   * @deprecated use Vector3Utils.add instead.
   */
  static vecOffset(pos, offset = VECTOR3_ZERO) {
    return Vector3Utils.add(pos, offset);
  }
  /**
   * Applies a bouncing effect to an entity, with decaying vertical strength.
   * Call this function when the entity lands on a block.
   * @param entity
   * @param initialStrength
   * @returns
   */
  static applyBounce(entity, initialStrength = 1, decayRate = 0.8) {
    let strength = entity.getDynamicProperty("mcutils:bounce_strength");
    if (strength === void 0) {
      strength = initialStrength;
    }
    if (strength <= 0.1) {
      entity.setDynamicProperty("mcutils:bounce_strength");
      return;
    }
    entity.applyImpulse({ x: 0, y: strength, z: 0 });
    entity.setDynamicProperty("mcutils:bounce_strength", strength * decayRate);
  }
  // TODO: Modify so size can be a number or Vector3
  /**
   * Scans in a taxicab (Manhattan) pattern from the origin up to a max distance.
   * Calls the callback for each position.
   * If the callback returns a value (non-undefined), scanning stops and that value is returned.
   *
   * @param origin - Starting point for the scan.
   * @param size - Maximum taxicab distance.
   * @param callback - Function called for each position. Return a value to stop scanning early.
   * @returns The first non-undefined result from the callback, or undefined if nothing was found.
   */
  static taxicabDistance(origin, size, callback) {
    for (let dx = -size; dx <= size; dx++) {
      for (let dy = -size; dy <= size; dy++) {
        for (let dz = -size; dz <= size; dz++) {
          const distance = Math.abs(dx) + Math.abs(dy) + Math.abs(dz);
          if (distance > size) continue;
          const pos = {
            x: origin.x + dx,
            y: origin.y + dy,
            z: origin.z + dz
          };
          const result = callback(pos);
          if (result !== void 0) return result;
        }
      }
    }
    return void 0;
  }
  // TODO: Modify so size can be a number or Vector3
  /**
   * Scans in a Chebyshev (king-move) pattern from the origin up to a max distance.
   * Calls the callback for each position.
   * If the callback returns a value (non-undefined), scanning stops and that value is returned.
   *
   * @param origin - Starting point for the scan.
   * @param size - Maximum Chebyshev distance.
   * @param callback - Function called for each position. Return a value to stop scanning early.
   * @returns The first non-undefined result from the callback, or undefined if nothing was found.
   */
  static chebyshevDistance(origin, size, callback) {
    for (let dx = -size; dx <= size; dx++) {
      for (let dy = -size; dy <= size; dy++) {
        for (let dz = -size; dz <= size; dz++) {
          const distance = Math.max(Math.abs(dx), Math.abs(dy), Math.abs(dz));
          if (distance > size) continue;
          const pos = {
            x: origin.x + dx,
            y: origin.y + dy,
            z: origin.z + dz
          };
          const result = callback(pos);
          if (result !== void 0) return result;
        }
      }
    }
    return void 0;
  }
  /**
   * Rotates all points around the origin.
   * @param {Vector3[]} points
   * @param {Vector3} origin
   * @param {Vector3} rotation
   * @returns {Vector3[]}
   */
  static rotatePoints(points, origin, rotation) {
    const rx = rotation.x * Math.PI / 180;
    const ry = rotation.y * Math.PI / 180;
    const rz = rotation.z * Math.PI / 180;
    const sinX = Math.sin(rx), cosX = Math.cos(rx);
    const sinY = Math.sin(ry), cosY = Math.cos(ry);
    const sinZ = Math.sin(rz), cosZ = Math.cos(rz);
    return points.map((pt) => {
      let x2 = pt.x - origin.x;
      let y2 = pt.y - origin.y;
      let z2 = pt.z - origin.z;
      let y1 = y2 * cosX - z2 * sinX;
      let z1 = y2 * sinX + z2 * cosX;
      y2 = y1;
      z2 = z1;
      let x1 = x2 * cosY + z2 * sinY;
      let z22 = -x2 * sinY + z2 * cosY;
      x2 = x1;
      z2 = z22;
      let x22 = x2 * cosZ - y2 * sinZ;
      let y22 = x2 * sinZ + y2 * cosZ;
      x2 = x22;
      y2 = y22;
      return {
        x: x2 + origin.x,
        y: y2 + origin.y,
        z: z2 + origin.z
      };
    });
  }
};

// node_modules/@lpsmods/mc-utils/src/font.ts
var Font = class _Font {
  static fonts = /* @__PURE__ */ new Map();
  /**
   * Get a font by name.
   * @param {Fonts|string} fontName
   * @returns {FontDef|undefined}
   */
  static get(fontName) {
    const res = _Font.fonts.get(fontName.toString().toLowerCase());
    if (!res) throw new Error(`Font ${fontName} not found!`);
    return res;
  }
};
Font.fonts.set("default", {
  a: ["00000", "00000", "01110", "00001", "01111", "10001", "01111", "00000"],
  b: ["10000", "10000", "10000", "10110", "11001", "10001", "11110", "00000"],
  c: ["00000", "00000", "01110", "10001", "10000", "10001", "01110", "00000"],
  d: ["00001", "00001", "00001", "01101", "10011", "10001", "01111", "00000"],
  e: ["00000", "00000", "01110", "10001", "11110", "10000", "01111", "00000"],
  f: ["0011", "0100", "1110", "0100", "0100", "0100", "0100", "00000"],
  g: ["00000", "00000", "01110", "10001", "01111", "00001", "11110"],
  h: ["10000", "10000", "10110", "11001", "10001", "10001", "10001", "00000"],
  i: ["1", "0", "1", "1", "1", "1", "1", "0"],
  j: ["00001", "00000", "00001", "00001", "00001", "10001", "10001", "01110"],
  k: ["1000", "1000", "1001", "1010", "1100", "1010", "1001", "00000"],
  l: ["10", "10", "10", "10", "10", "10", "01", "00"],
  m: ["00000", "00000", "11010", "10101", "10001", "10001", "10001", "00000"],
  n: ["00000", "00000", "11110", "10001", "10001", "10001", "10001", "00000"],
  o: ["00000", "00000", "01110", "10001", "10001", "10001", "01110", "00000"],
  p: ["00000", "00000", "10110", "11001", "10001", "11110", "10000"],
  q: ["00000", "00000", "01101", "10011", "10001", "01111", "00001"],
  r: ["00000", "00000", "10110", "11001", "10000", "10000", "10000", "00000"],
  s: ["0000", "0000", "0111", "1000", "0110", "0001", "1110", "00000"],
  t: ["010", "010", "111", "010", "010", "010", "001", "000"],
  u: ["00000", "00000", "10001", "10001", "10001", "10001", "01111", "00000"],
  v: ["00000", "00000", "10001", "10001", "10001", "01010", "00100", "00000"],
  w: ["00000", "00000", "10001", "10001", "10101", "10101", "01111", "00000"],
  x: ["00000", "00000", "10001", "01010", "00100", "01010", "10001", "00000"],
  y: ["00000", "00000", "10001", "10001", "10001", "01111", "00001", "11110"],
  z: ["00000", "00000", "11111", "00010", "00100", "01000", "11111", "00000"],
  A: ["01110", "10001", "11111", "10001", "10001", "10001", "10001", "00000"],
  B: ["11110", "10001", "11110", "10001", "10001", "10001", "11110", "00000"],
  C: ["01110", "10001", "10000", "10000", "10000", "10001", "01110", "00000"],
  D: ["11110", "10001", "10001", "10001", "10001", "10001", "11110", "00000"],
  E: ["1111", "1000", "1110", "1000", "1000", "1000", "1111", "0000"],
  F: ["1111", "1000", "1110", "1000", "1000", "1000", "1000", "0000"],
  G: ["01111", "10000", "10011", "10001", "10001", "10001", "01110", "00000"],
  H: ["10001", "10001", "11111", "10001", "10001", "10001", "10001", "00000"],
  I: ["111", "010", "010", "010", "010", "010", "111", "000"],
  J: ["00001", "00001", "00001", "00001", "00001", "10001", "01110", "00000"],
  K: ["10001", "10010", "11100", "10010", "10001", "10001", "10001", "00001"],
  L: ["10000", "10000", "10000", "10000", "10000", "10000", "11111", "00000"],
  M: ["10001", "11011", "10101", "10001", "10001", "10001", "10001", "00000"],
  N: ["10001", "10001", "11001", "10101", "10011", "10001", "10001", "00000"],
  O: ["01110", "10001", "10001", "10001", "10001", "10001", "01110", "00000"],
  P: ["11110", "10001", "11110", "10000", "10000", "10000", "10000", "00000"],
  Q: ["01110", "10001", "10001", "10001", "10001", "10010", "01101", "00000"],
  R: ["11110", "10001", "11110", "10001", "10001", "10001", "10001", "00000"],
  S: ["01111", "10000", "01110", "00001", "00001", "10001", "01110", "00000"],
  T: ["11111", "00100", "00100", "00100", "00100", "00100", "00100", "00000"],
  U: ["10001", "10001", "10001", "10001", "10001", "10001", "01110", "00000"],
  V: ["10001", "10001", "10001", "10001", "01010", "01010", "00100", "00000"],
  W: ["10001", "10001", "10001", "10001", "10101", "11011", "10001", "00000"],
  X: ["10001", "01010", "00100", "01010", "10001", "10001", "10001", "00000"],
  Y: ["10001", "01010", "00100", "00100", "00100", "00100", "00100", "00000"],
  Z: ["11111", "00001", "00010", "00100", "01000", "10000", "11111", "00000"],
  0: ["01110", "10001", "10011", "10101", "11001", "10001", "01110", "00000"],
  1: ["00100", "01100", "00100", "00100", "00100", "00100", "11111", "00000"],
  2: ["01110", "10001", "00001", "00110", "01000", "10001", "11111", "00000"],
  3: ["01110", "10001", "00001", "00010", "00001", "10001", "01110", "00000"],
  4: ["00011", "00101", "01001", "10001", "11111", "00001", "00001", "00000"],
  5: ["11111", "10000", "11110", "00001", "00001", "10001", "01110", "00000"],
  6: ["00110", "01000", "10000", "10000", "11110", "10001", "01110", "00000"],
  7: ["11111", "10001", "00001", "00010", "00100", "00100", "00100", "00000"],
  8: ["01110", "10001", "10001", "01110", "10001", "10001", "01110", "00000"],
  9: ["01110", "10001", "10001", "01111", "00001", "00010", "01100", "00000"],
  "!": ["1", "1", "1", "1", "1", "0", "1", "0"],
  "@": ["011110", "100001", "101101", "101101", "101111", "100000", "011110", "000000"],
  "#": ["01010", "01010", "11111", "01010", "11111", "01010", "01010", "00000"],
  $: ["00100", "01111", "10000", "01110", "00001", "11110", "00100", "00000"],
  "%": ["10001", "10010", "00010", "00100", "01000", "01001", "10001", "00000"],
  "^": ["00100", "01010", "10001", "00000", "00000", "00000", "00000", "00000"],
  "&": ["00100", "01010", "00100", "01101", "10110", "10010", "01101", "00000"],
  "*": ["1001", "0110", "1001", "0000", "0000", "0000", "0000", "0000"],
  "(": ["0011", "0100", "1000", "1000", "1000", "0100", "0011", "0000"],
  ")": ["1100", "0010", "0001", "0001", "0001", "0010", "1100", "0000"],
  "-": ["00000", "00000", "00000", "11111", "00000", "00000", "00000", "00000"],
  "=": ["00000", "00000", "11111", "00000", "00000", "11111", "00000", "00000"],
  _: ["00000", "00000", "00000", "00000", "00000", "00000", "00000", "11111"],
  "+": ["00000", "00100", "00100", "11111", "00100", "00100", "00000", "00000"],
  "[": ["111", "100", "100", "100", "100", "100", "111", "000"],
  "]": ["111", "001", "001", "001", "001", "001", "111", "000"],
  "{": ["001", "010", "010", "100", "010", "010", "001", "000"],
  "}": ["100", "010", "010", "001", "010", "010", "100", "000"],
  "\\": ["10000", "01000", "01000", "00100", "00010", "00010", "00001", "00000"],
  "/": ["00001", "00010", "00010", "00100", "01000", "01000", "10000", "00000"],
  "|": ["1", "1", "1", "0", "1", "1", "1", "0"],
  ";": ["0", "1", "1", "0", "0", "1", "1", "1"],
  ":": ["0", "1", "1", "0", "0", "1", "1", "0"],
  "'": ["01", "01", "10", "00", "00", "00", "00", "00"],
  '"': ["0101", "0101", "1010", "0000", "0000", "0000", "0000", "0000"],
  ",": ["0", "0", "0", "0", "0", "1", "1", "1"],
  ".": ["0", "0", "0", "0", "0", "1", "1", "0"],
  "<": ["0001", "0010", "0100", "1000", "0100", "0010", "0001", "0000"],
  ">": ["1000", "0100", "0010", "0001", "0010", "0100", "1000", "0000"],
  "?": ["01110", "10001", "00001", "00010", "00100", "00000", "00100", "00000"],
  "\xA7": ["01111", "10000", "01110", "10001", "01110", "00001", "11110", "00000"],
  "`": ["10", "10", "01", "00", "00", "00", "00", "00"],
  "~": ["011001", "100110", "000000", "000000", "000000", "000000", "000000", "000000"],
  " ": ["00000", "00000", "00000", "00000", "00000", "00000", "00000", "00000"]
});
Font.fonts.set("alt", {
  A: ["00110000", "01001000", "01000000", "01000000", "01000000", "01000000", "11000000", "00000000"],
  B: ["00100000", "00100000", "00100000", "00100000", "00010000", "00001000", "11111000", "00000000"],
  C: ["10000000", "00000000", "10000000", "10000000", "11000000", "01000000", "01000000", "00000000"],
  D: ["11111000", "00000000", "11000000", "00100000", "00011000", "00000000", "00000000", "00000000"],
  E: ["10001000", "10000000", "10000000", "10000000", "10000000", "10000000", "11111000", "00000000"],
  F: ["11111000", "00000000", "10101000", "00000000", "00000000", "00000000", "00000000", "00000000"],
  G: ["00100000", "00100000", "00100000", "11100000", "00100000", "00100000", "00100000", "00000000"],
  H: ["11111000", "00000000", "11111000", "00100000", "00100000", "00100000", "00100000", "00000000"],
  I: ["10000000", "10000000", "10000000", "00000000", "10000000", "10000000", "10000000", "00000000"],
  J: ["10000000", "10000000", "00000000", "10000000", "00000000", "10000000", "10000000", "00000000"],
  K: ["00100000", "00100000", "00100000", "10101000", "00100000", "00100000", "00100000", "00000000"],
  L: ["10000000", "10100000", "10000000", "10000000", "10000000", "10100000", "10000000", "00000000"],
  M: ["10001000", "00001000", "00001000", "00001000", "00001000", "00001000", "11111000", "00000000"],
  N: ["10010000", "10010000", "00010000", "00100000", "00100000", "01000000", "10000000", "00000000"],
  O: ["11110000", "00010000", "00010000", "00100000", "00100000", "01000000", "10000000", "00000000"],
  P: ["10100000", "00100000", "10100000", "10100000", "10100000", "10000000", "10100000", "00000000"],
  Q: ["00100000", "00000000", "11111000", "00001000", "00001000", "00001000", "11111000", "00000000"],
  R: ["10010000", "00000000", "00000000", "00000000", "00000000", "00000000", "10010000", "00000000"],
  S: ["10000000", "10000000", "10000000", "11000000", "01000000", "01000000", "01000000", "00000000"],
  T: ["11111000", "00001000", "00001000", "00001000", "00001000", "00000000", "00001000", "00000000"],
  U: ["00000000", "00000000", "01010000", "00000000", "11111000", "00000000", "00000000", "00000000"],
  V: ["00100000", "00100000", "00100000", "00100000", "11111000", "00000000", "11111000", "00000000"],
  W: ["00000000", "00000000", "00100000", "00000000", "00000000", "10001000", "00000000", "00000000"],
  X: ["10001000", "00010000", "00010000", "00100000", "01000000", "01000000", "10000000", "00000000"],
  Y: ["10100000", "10100000", "10100000", "10100000", "10100000", "10100000", "10100000", "00000000"],
  Z: ["00100000", "01010000", "10001000", "10001000", "10001000", "10001000", "10001000", "00000000"],
  a: ["00110000", "01001000", "01000000", "01000000", "01000000", "01000000", "11000000", "00000000"],
  b: ["00100000", "00100000", "00100000", "00100000", "00010000", "00001000", "11111000", "00000000"],
  c: ["10000000", "00000000", "10000000", "10000000", "11000000", "01000000", "01000000", "00000000"],
  d: ["11111000", "00000000", "11000000", "00100000", "00011000", "00000000", "00000000", "00000000"],
  e: ["10001000", "10000000", "10000000", "10000000", "10000000", "10000000", "11111000", "00000000"],
  f: ["11111000", "00000000", "10101000", "00000000", "00000000", "00000000", "00000000", "00000000"],
  g: ["00100000", "00100000", "00100000", "11100000", "00100000", "00100000", "00100000", "00000000"],
  h: ["11111000", "00000000", "11111000", "00100000", "00100000", "00100000", "00100000", "00000000"],
  i: ["10000000", "10000000", "10000000", "00000000", "10000000", "10000000", "10000000", "00000000"],
  j: ["10000000", "10000000", "00000000", "10000000", "00000000", "10000000", "10000000", "00000000"],
  k: ["00100000", "00100000", "00100000", "10101000", "00100000", "00100000", "00100000", "00000000"],
  l: ["10000000", "10100000", "10000000", "10000000", "10000000", "10100000", "10000000", "00000000"],
  m: ["10001000", "00001000", "00001000", "00001000", "00001000", "00001000", "11111000", "00000000"],
  n: ["10010000", "10010000", "00010000", "00100000", "00100000", "01000000", "10000000", "00000000"],
  o: ["11110000", "00010000", "00010000", "00100000", "00100000", "01000000", "10000000", "00000000"],
  p: ["10100000", "00100000", "10100000", "10100000", "10100000", "10000000", "10100000", "00000000"],
  q: ["00100000", "00000000", "11111000", "00001000", "00001000", "00001000", "11111000", "00000000"],
  r: ["10010000", "00000000", "00000000", "00000000", "00000000", "00000000", "10010000", "00000000"],
  s: ["10000000", "10000000", "10000000", "11000000", "01000000", "01000000", "01000000", "00000000"],
  t: ["11111000", "00001000", "00001000", "00001000", "00001000", "00000000", "00001000", "00000000"],
  u: ["00000000", "00000000", "01010000", "00000000", "11111000", "00000000", "00000000", "00000000"],
  v: ["00100000", "00100000", "00100000", "00100000", "11111000", "00000000", "11111000", "00000000"],
  w: ["00000000", "00000000", "00100000", "00000000", "00000000", "10001000", "00000000", "00000000"],
  x: ["10001000", "00010000", "00010000", "00100000", "01000000", "01000000", "10000000", "00000000"],
  y: ["10100000", "10100000", "10100000", "10100000", "10100000", "10100000", "10100000", "00000000"],
  z: ["00100000", "01010000", "10001000", "10001000", "10001000", "10001000", "10001000", "00000000"],
  " ": ["00000000", "00000000", "00000000", "00000000", "00000000", "00000000", "00000000", "00000000"]
});
Font.fonts.set("illageralt", {
  "!": ["10100000", "10100000", "10100000", "10100000", "10100000", "00000000", "01000000", "00000000"],
  ",": ["00000000", "00000000", "00000000", "00000000", "00000000", "10000000", "10000000", "00000000"],
  "-": ["00000000", "00000000", "00000000", "11000000", "00000000", "00000000", "00000000", "00000000"],
  ".": ["00000000", "00000000", "11100000", "10100000", "11100000", "00000000", "00000000", "00000000"],
  "0": ["01110000", "01010000", "01010000", "01010000", "01110000", "00000000", "11111100", "00000000"],
  "1": ["11100000", "10100000", "10100000", "11100000", "01000000", "01000000", "01000000", "00000000"],
  "2": ["11100000", "10000000", "10000000", "10100000", "00100000", "00100000", "11100000", "00000000"],
  "3": ["10100000", "10100000", "10100000", "00100000", "00100000", "00100000", "11100000", "00000000"],
  "4": ["11100000", "10100000", "10100000", "10000000", "10000000", "10000000", "10000000", "00000000"],
  "5": ["10101000", "10101000", "10101000", "10101000", "10101000", "00000000", "01110000", "00000000"],
  "6": ["01000000", "01000000", "11100000", "00000000", "10100000", "10100000", "11100000", "00000000"],
  "7": ["01100000", "01000000", "01000000", "11100000", "01000000", "01000000", "11000000", "00000000"],
  "8": ["11100000", "10100000", "10100000", "10100000", "10100000", "10100000", "11100000", "00000000"],
  "9": ["11100000", "10100000", "10100000", "00000000", "11100000", "01000000", "01000000", "00000000"],
  "?": ["11100000", "10100000", "11100000", "00000000", "11100000", "01000000", "11100000", "00000000"],
  a: ["00110000", "01001000", "01001000", "01001000", "01001000", "01001000", "11001000", "00000000"],
  b: ["00100000", "00100000", "00100000", "01010000", "01010000", "10001000", "11111000", "00000000"],
  c: ["11100000", "00100000", "00100000", "00100000", "00100000", "00100000", "00011000", "00000000"],
  d: ["11111000", "00100000", "00100000", "00100000", "01110000", "01010000", "11111000", "00000000"],
  e: ["10000000", "10111000", "10100000", "11100000", "10100000", "10111000", "10000000", "00000000"],
  f: ["11111000", "00000000", "01010000", "01010000", "01010000", "01010000", "01010000", "00000000"],
  g: ["11111100", "00100100", "00100100", "00100100", "00000100", "00000100", "00000100", "00000000"],
  h: ["11111000", "00000000", "11111000", "00100000", "10101000", "00100000", "00100000", "00000000"],
  i: ["11111000", "00100000", "00100000", "00000000", "00100000", "00100000", "00100000", "00000000"],
  j: ["00001000", "11101000", "10101000", "10101000", "10101000", "11101000", "00001000", "00000000"],
  k: ["01010000", "01010000", "11111000", "01010000", "01010000", "01010000", "01010000", "00000000"],
  l: ["11111000", "00100000", "00100000", "00100000", "00100000", "00100000", "11111000", "00000000"],
  m: ["11101000", "10001000", "10001000", "11110000", "10001000", "10001000", "11101000", "00000000"],
  n: ["00100000", "11111000", "00100000", "00100000", "01110000", "00100000", "00100000", "00000000"],
  o: ["01110000", "10001000", "10001000", "10001000", "01110000", "10001000", "10001000", "00000000"],
  p: ["10010000", "10010000", "10100000", "11000000", "10000000", "10000000", "10000000", "00000000"],
  q: ["01110000", "10001000", "10101000", "10001000", "01110000", "10001000", "10001000", "00000000"],
  r: ["00100000", "10101000", "10101000", "11111000", "10101000", "10101000", "00100000", "00000000"],
  s: ["11111000", "00100000", "00100000", "01110000", "10001000", "10001000", "01110000", "00000000"],
  t: ["01110000", "10001000", "10101000", "00100000", "00100000", "11111000", "00100000", "00000000"],
  u: ["01110000", "01010000", "01010000", "01010000", "11111000", "01010000", "01010000", "00000000"],
  v: ["01010000", "01010000", "01010000", "01010000", "01110000", "00000000", "11111000", "00000000"],
  w: ["10101000", "10101000", "10101000", "10101000", "11111000", "00000000", "11111000", "00000000"],
  x: ["10010000", "10010000", "10010000", "01100000", "10100000", "10100000", "10100000", "00000000"],
  y: ["11111000", "10001000", "10001000", "01110000", "00100000", "00100000", "00100000", "00000000"],
  z: ["00010000", "00101000", "01001000", "10001000", "10001000", "10001000", "10001000", "00000000"],
  A: ["00110000", "01001000", "01001000", "01001000", "01001000", "01001000", "11001000", "00000000"],
  B: ["00100000", "00100000", "00100000", "01010000", "01010000", "10001000", "11111000", "00000000"],
  C: ["11100000", "00100000", "00100000", "00100000", "00100000", "00100000", "00011000", "00000000"],
  D: ["11111000", "00100000", "00100000", "00100000", "01110000", "01010000", "11111000", "00000000"],
  E: ["10000000", "10111000", "10100000", "11100000", "10100000", "10111000", "10000000", "00000000"],
  F: ["11111000", "00000000", "01010000", "01010000", "01010000", "01010000", "01010000", "00000000"],
  G: ["11111100", "00100100", "00100100", "00100100", "00000100", "00000100", "00000100", "00000000"],
  H: ["11111000", "00000000", "11111000", "00100000", "10101000", "00100000", "00100000", "00000000"],
  I: ["11111000", "00100000", "00100000", "00000000", "00100000", "00100000", "00100000", "00000000"],
  J: ["00001000", "11101000", "10101000", "10101000", "10101000", "11101000", "00001000", "00000000"],
  K: ["01010000", "01010000", "11111000", "01010000", "01010000", "01010000", "01010000", "00000000"],
  L: ["11111000", "00100000", "00100000", "00100000", "00100000", "00100000", "11111000", "00000000"],
  M: ["11101000", "10001000", "10001000", "11110000", "10001000", "10001000", "11101000", "00000000"],
  N: ["00100000", "11111000", "00100000", "00100000", "01110000", "00100000", "00100000", "00000000"],
  O: ["01110000", "10001000", "10001000", "10001000", "01110000", "10001000", "10001000", "00000000"],
  P: ["10010000", "10010000", "10100000", "11000000", "10000000", "10000000", "10000000", "00000000"],
  Q: ["01110000", "10001000", "10101000", "10001000", "01110000", "10001000", "10001000", "00000000"],
  R: ["00100000", "10101000", "10101000", "11111000", "10101000", "10101000", "00100000", "00000000"],
  S: ["11111000", "00100000", "00100000", "01110000", "10001000", "10001000", "01110000", "00000000"],
  T: ["01110000", "10001000", "10101000", "00100000", "00100000", "11111000", "00100000", "00000000"],
  U: ["01110000", "01010000", "01010000", "01010000", "11111000", "01010000", "01010000", "00000000"],
  V: ["01010000", "01010000", "01010000", "01010000", "01110000", "00000000", "11111000", "00000000"],
  W: ["10101000", "10101000", "10101000", "10101000", "11111000", "00000000", "11111000", "00000000"],
  X: ["10010000", "10010000", "10010000", "01100000", "10100000", "10100000", "10100000", "00000000"],
  Y: ["11111000", "10001000", "10001000", "01110000", "00100000", "00100000", "00100000", "00000000"],
  Z: ["00010000", "00101000", "01001000", "10001000", "10001000", "10001000", "10001000", "00000000"],
  " ": ["00000000", "00000000", "00000000", "00000000", "00000000", "00000000", "00000000", "00000000"]
});

// node_modules/@lpsmods/mc-utils/src/shape.ts
var Shape = class {
  static shapeId;
  drawer = void 0;
  location;
  rotation = VECTOR3_ZERO;
  origin;
  // TODO: Only implemented for some shapes.
  scale = 1;
  timeLeft = 0;
  _totalTimeLeft = 0;
  /**
   * A block, entity, or particle.
   */
  material;
  constructor(location) {
    this.location = location;
  }
  get hasDuration() {
    return this.totalTimeLeft > 0;
  }
  get totalTimeLeft() {
    return this._totalTimeLeft;
  }
  set totalTimeLeft(value) {
    this._totalTimeLeft = value;
    this.timeLeft = value;
  }
  /**
   * Removes this shape from the world.
   */
  remove() {
    if (this.drawer) {
      this.drawer.removeShape(this);
    }
  }
  /**
   * Rotate the shape in the X direction.
   * @param {number} value
   */
  rotateX(value) {
    this.rotation.x = value;
  }
  /**
   * Rotate the shape in the Y direction.
   * @param {number} value
   */
  rotateY(value) {
    this.rotation.y = value;
  }
  /**
   * Rotate the shape in the Z direction.
   * @param {number} value
   */
  rotateZ(value) {
    this.rotation.z = value;
  }
};
var BoxShape = class extends Shape {
  static shapeId = "box";
  bound;
  constructor(location, bound) {
    super(location);
    this.bound = bound;
  }
  getPoints() {
    const points = [];
    const minX = Math.min(this.location.x, this.bound.x);
    const maxX = Math.max(this.location.x, this.bound.x);
    const minY = Math.min(this.location.y, this.bound.y);
    const maxY = Math.max(this.location.y, this.bound.y);
    const minZ = Math.min(this.location.z, this.bound.z);
    const maxZ = Math.max(this.location.z, this.bound.z);
    for (let x2 = minX; x2 <= maxX; x2++) {
      points.push({ x: x2, y: minY, z: minZ });
      points.push({ x: x2, y: minY, z: maxZ });
      points.push({ x: x2, y: maxY, z: minZ });
      points.push({ x: x2, y: maxY, z: maxZ });
    }
    for (let y2 = minY; y2 <= maxY; y2++) {
      points.push({ x: minX, y: y2, z: minZ });
      points.push({ x: minX, y: y2, z: maxZ });
      points.push({ x: maxX, y: y2, z: minZ });
      points.push({ x: maxX, y: y2, z: maxZ });
    }
    for (let z2 = minZ; z2 <= maxZ; z2++) {
      points.push({ x: minX, y: minY, z: z2 });
      points.push({ x: minX, y: maxY, z: z2 });
      points.push({ x: maxX, y: minY, z: z2 });
      points.push({ x: maxX, y: maxY, z: z2 });
    }
    return MathUtils.rotatePoints(points, this.location, this.origin ?? this.rotation);
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/random.ts
var Random = class {
  seed = BigInt(0);
  constructor(seed) {
    this.setSeed(seed);
  }
  setSeed(seed) {
    const bigSeed = BigInt(seed);
    this.seed = (bigSeed ^ 0x5deece66dn) & (1n << 48n) - 1n;
  }
  next(bits) {
    this.seed = this.seed * 0x5deece66dn + 0xbn & (1n << 48n) - 1n;
    return Number(this.seed >> 48n - BigInt(bits));
  }
  nextInt(bound) {
    if (bound <= 0) {
      throw new Error("Bound must be positive");
    }
    if ((bound & -bound) === bound) {
      return Math.floor(bound * this.next(31) / (1 << 31));
    }
    let bits, val;
    do {
      bits = this.next(31);
      val = bits % bound;
    } while (bits - val + (bound - 1) < 0);
    return val;
  }
};
var RandomUtils = class _RandomUtils {
  /**
   * Chooses a random location in a block volume.
   * @param {BlockVolume} volume
   */
  static posInVolume(volume) {
    const bounds = MathUtils.getBounds(volume.from, volume.to);
    return {
      x: bounds.minX + Math.random() * (bounds.maxX - bounds.minX + 1),
      y: bounds.minY + Math.random() * (bounds.maxY - bounds.minY + 1),
      z: bounds.minZ + Math.random() * (bounds.maxZ - bounds.minZ + 1)
    };
  }
  /**
   * Create a random UUID.
   * @returns {string}
   */
  static uuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c2) {
      const r2 = Math.random() * 16 | 0;
      const v2 = c2 === "x" ? r2 : r2 & 3 | 8;
      return v2.toString(16);
    });
  }
  /**
   * Returns a random integer within MIN and MAX.
   * @param {number} low
   * @param {number} high
   * @returns {number}
   */
  static int(low, high) {
    return Math.floor(Math.random() * (high - low) + low);
  }
  /**
   * Create a random string.
   * @param {number} length
   * @param {string} characters
   * @returns
   */
  static id(length, characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789") {
    return Array.from({ length }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join("");
  }
  /**
   * Create a random dynamic property id.
   * @returns {string}
   */
  static propertyId() {
    return _RandomUtils.id(12);
  }
  /**
   * Chooses one random item from the array.
   * @param {T[]} choices
   * @returns {T}
   */
  static choice(choices) {
    var index = Math.floor(Math.random() * choices.length);
    return choices[index];
  }
  /**
   * Chooses one random item (with weight) from the array.
   * @param {Array<T, number>} choices
   * @returns {T}
   */
  static weightedChoice(choices) {
    var index = Math.floor(Math.random() * choices.length);
    return choices[index][0];
  }
};

// node_modules/@lpsmods/mc-utils/src/world/utils.ts
import {
  BlockVolume as BlockVolume2,
  LocationInUnloadedChunkError as LocationInUnloadedChunkError3
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/utils/error.ts
import { LocationInUnloadedChunkError as LocationInUnloadedChunkError2, LocationOutOfWorldBoundariesError } from "@minecraft/server";
var ErrorUtils = class {
  /**
   * Wraps the callback in a try-catch statement, making the error silent.
   * @param {object} error
   * @param callback
   * @returns
   */
  static wrapCatch(error, callback) {
    try {
      return callback();
    } catch (err) {
      if (err instanceof error) return;
      throw err;
    }
  }
  /**
   * Wraps the callback in a try-catch statement, making errors silent.
   * @param {Error[]} errors
   * @param callback
   * @returns
   */
  static wrapCatchAll(errors, callback) {
    try {
      return callback();
    } catch (err) {
      if (!err) return;
      for (const error of errors) {
        if (error && typeof error === "function" && err instanceof error) return;
      }
      throw err;
    }
  }
  static tryPos(callback) {
    return this.wrapCatchAll([LocationInUnloadedChunkError2, LocationOutOfWorldBoundariesError], callback);
  }
};
var ValidationError = class _ValidationError extends Error {
  issues;
  constructor(issues) {
    super(`Validation failed with ${issues.length} error(s).`);
    this.name = "ValidationError";
    this.issues = issues;
    Object.setPrototypeOf(this, _ValidationError.prototype);
  }
  toString() {
    return this.issues.map((issue) => `\u2022 ${issue.path}: ${issue.message}`).join("\n");
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      issues: this.issues
    };
  }
  static valueError(issues, path, value, types) {
    const type2 = typeof value;
    if (types.includes(type2)) return true;
    issues.push({
      path,
      message: `Must be a ${types.join(", ")} not "${type2}".`
    });
    return false;
  }
  static optionalValueError(issues, path, value, types) {
    types.push("undefined");
    return this.valueError(issues, path, value, types);
  }
};

// node_modules/@lpsmods/mc-utils/src/world/utils.ts
var WorldUtils = class {
  /**
   * The world seed. (Returns 0)
   * @returns {number}
   */
  static getSeed() {
    return 0;
  }
  /**
   * Get score from objective. Otherwise return undefined.
   * @param {ScoreboardObjective} objective
   * @param {ScoreboardIdentity} name
   * @param {*} defaultValue
   * @returns
   */
  static tryGetScore(objective, name, defaultValue) {
    try {
      var o2 = objective.getScore(name);
      if (o2 == void 0) return defaultValue;
      return o2;
    } catch (err) {
      return defaultValue;
    }
  }
  /**
   * Like {Dimension.setBlockType} but wrapped in a try-catch LocationInUnloadedChunkError.
   * @param {Dimension} dimension
   * @param {Vector3} location
   * @param {Block} block
   * @returns {boolean}
   */
  static trySetBlockType(dimension, location, block) {
    return ErrorUtils.wrapCatch(LocationInUnloadedChunkError3, () => dimension.setBlockType(location, block));
  }
  /**
   * Like {Dimension.setBlockPermutation} but wrapped in a try-catch LocationInUnloadedChunkError.
   * @param {Dimension} dimension
   * @param {Vector3} location
   * @param {BlockPermutation} blockPermutation
   * @returns {boolean}
   */
  static trySetBlockPermutation(dimension, location, blockPermutation) {
    return ErrorUtils.wrapCatch(
      LocationInUnloadedChunkError3,
      () => dimension.setBlockPermutation(location, blockPermutation)
    );
  }
  /**
   * Splits a block volume into smaller chunks.
   * @param {BlockVolume} volume
   * @param {number} maxBlocks
   * @returns {BlockVolume[]}
   */
  static chunkVolume(volume, maxBlocks = 32e3) {
    const min2 = volume.getMin();
    const max2 = volume.getMax();
    const sizeX = max2.x - min2.x + 1;
    const sizeY = max2.y - min2.y + 1;
    const sizeZ = max2.z - min2.z + 1;
    const total = sizeX * sizeY * sizeZ;
    if (total <= maxBlocks) return [volume];
    const maxDim = Math.floor(Math.cbrt(maxBlocks));
    const chunks = [];
    for (let x2 = min2.x; x2 <= max2.x; x2 += maxDim) {
      for (let y2 = min2.y; y2 <= max2.y; y2 += maxDim) {
        for (let z2 = min2.z; z2 <= max2.z; z2 += maxDim) {
          const to = {
            x: Math.min(x2 + maxDim - 1, max2.x),
            y: Math.min(y2 + maxDim - 1, max2.y),
            z: Math.min(z2 + maxDim - 1, max2.z)
          };
          chunks.push(new BlockVolume2({ x: x2, y: y2, z: z2 }, to));
        }
      }
    }
    return chunks;
  }
  /**
   * Like Dimension.fillBlocks but splits it up to override the max blocks.
   * @param {Dimension} dimension
   * @param {BlockVolume} volume
   * @param {BlockType | BlockPermutation | string} block
   * @param {BlockFillOptions} options
   */
  static *fillBlocks(dimension, volume, block, options) {
    const chunks = this.chunkVolume(volume);
    for (const chunk of chunks) {
      dimension.fillBlocks(chunk, block, options);
      yield;
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/chunk/base.ts
function updateChunkData(chunk) {
  const k2 = Hasher.stringify(chunk.location) ?? "unknown";
  const old = world2.getDynamicProperty(k2);
  const nData = new VersionedDataStorage(`mcutils:chunk.${k2}`, 2);
  if (old) {
    const data = JSON.parse(old);
    nData.update(data);
  }
  return nData;
}
var Chunk = class _Chunk {
  dimension;
  location;
  store;
  constructor(dimension, location) {
    this.dimension = dimension;
    this.location = { x: Math.floor(location.x), z: Math.floor(location.z) };
    this.store = updateChunkData(this);
  }
  get origin() {
    return this.from;
  }
  get from() {
    return {
      x: this.location.x * 16,
      y: this.dimension.heightRange.min,
      z: this.location.z * 16
    };
  }
  get to() {
    return {
      x: this.location.x * 16 + 15,
      y: this.dimension.heightRange.max,
      z: this.location.z * 16 + 15
    };
  }
  get x() {
    return this.location.x;
  }
  get z() {
    return this.location.z;
  }
  /**
   * Tests if this chunk matches another.
   * @param chunk
   * @returns
   */
  matches(chunk) {
    if (!(chunk instanceof _Chunk)) return false;
    return chunk.x === this.x && chunk.z === this.z;
  }
  /**
   * @deprecated Use Chunk.matches instead.
   */
  equals = this.matches;
  /**
   * Whether or not this chunk spawns slimes.
   * @returns {boolean}
   */
  isSlimeChunk() {
    const seed = WorldUtils.getSeed();
    const { x: chunkX, z: chunkZ } = this.location;
    const n2 = BigInt(chunkX * chunkX * 4987142) + BigInt(chunkX * 5947611) + BigInt(chunkZ * chunkZ) * BigInt(4392871) + BigInt(chunkZ * 389711) ^ BigInt(seed);
    const rand = new Random(n2);
    return rand.nextInt(10) === 0;
  }
  /**
   * The center position in the chunk.
   * @returns {Vector3}
   */
  getCenter() {
    return {
      x: this.from.x + (this.to.x - this.from.x) / 2 + 0.5,
      y: this.from.y + (this.to.y - this.from.y) / 2,
      z: this.from.z + (this.to.z - this.from.z) / 2 + 0.5
    };
  }
  /**
   * @remarks
   * Clears all dynamic properties that have been set on this
   * block.
   *
   * @throws This function can throw errors.
   */
  clearDynamicProperties() {
    this.store.clear();
  }
  /**
   * @remarks
   * Returns a property value.
   *
   * @param identifier
   * The property identifier.
   * @returns
   * Returns the value for the property, or undefined if the
   * property has not been set.
   * @throws This function can throw errors.
   */
  getDynamicProperty(identifier) {
    return this.store.getItem(identifier);
  }
  /**
   * @remarks
   * Returns the available set of dynamic property identifiers
   * that have been used on this block.
   *
   * @returns
   * A string array of the dynamic properties set on this block.
   * @throws This function can throw errors.
   */
  getDynamicPropertyIds() {
    return this.store.keys();
  }
  /**
   * @remarks
   * Returns the total size, in bytes, of all the dynamic
   * properties that are currently stored for this block. This
   * includes the size of both the key and the value.  This can
   * be useful for diagnosing performance warning signs - if, for
   * example, a block has many megabytes of associated dynamic
   * properties, it may be slow to load on various devices.
   *
   * @throws This function can throw errors.
   */
  getDynamicPropertyTotalByteCount() {
    return this.store.getSize();
  }
  /**
   * @remarks
   * Sets a specified property to a value.
   *
   * @param identifier
   * The property identifier.
   * @param value
   * Data value of the property to set.
   * @throws This function can throw errors.
   */
  setDynamicProperty(identifier, value) {
    this.store.setItem(identifier, value);
  }
  /**
   * Whether or not the chunk is loaded.
   * @returns {boolean}
   */
  isLoaded() {
    return this.dimension.isChunkLoaded(this.getCenter());
  }
  // forceLoad(name?: string): string {
  //   if (!name) {
  //     name = randomId(4);
  //   }
  //   this.dimension.runCommand(
  //     `tickingarea add ${this.from.x} ${this.from.y} ${this.from.z} ${this.to.x} ${this.to.y} ${this.to.z} ${name} true`
  //   );
  //   return name;
  // }
  // removeForceLoad(name: string): void {
  //   this.dimension.runCommand(`tickingarea remove ${name}`);
  // }
  // ENTITY
  /**
   * Get all entities in this chunk.
   * @param {EntityQueryOptions} options
   * @returns {Entity[]}
   */
  getEntities(options) {
    const vol = this.getBlockVolume();
    return this.dimension.getEntities({ location: vol.from, volume: vol.to }).filter((entity) => entity.matches(options));
  }
  getChunkVolume() {
    return new ChunkVolume(this.from, this.to);
  }
  // BLOCK
  /**
   * Get all blocks in this chunk.
   * @returns {Block[]}
   */
  getBlocks() {
    const results = [];
    for (const pos of this.getBlockVolume().getBlockLocationIterator()) {
      try {
        const block = this.dimension.getBlock(pos);
        if (!block) continue;
        results.push(block);
      } catch (err) {
      }
    }
    return results;
  }
  /**
   * Get all topmost blocks in this chunk.
   * @returns {Block[]}
   */
  getTopmostBlocks() {
    const results = [];
    for (let x2 = this.from.x; x2 <= this.to.x; x2++) {
      for (let z2 = this.from.z; z2 <= this.to.z; z2++) {
        const block = this.dimension.getTopmostBlock({ x: x2, z: z2 });
        if (!block) continue;
        results.push(block);
      }
    }
    return results;
  }
  /**
   * Get this chunk as a BlockVolume.
   * @returns {BlockVolume}
   */
  getBlockVolume() {
    return new BlockVolume3(this.from, this.to);
  }
  // show(): void {
  //   // @ts-ignore
  //   const shapes: debug.DebugShape = [];
  //   // @ts-ignore
  //   const shape = new debug.Box(this.from, this.to);
  //   // @ts-ignore
  //   debug.debugDrawer.addShape(shape);
  //   system.runTimeout(() => {
  //     // @ts-ignore
  //     shapes.forEach((shape) => shape.remove());
  //   }, 20);
  // }
  /**
   * Show the chunk borders.
   * @param {string} particle
   */
  show(particle = "minecraft:endrod") {
    const shape = new BoxShape(this.from, this.to);
    shape.material = particle;
    shape.totalTimeLeft = 0.1;
    const drawer = new ParticleDrawer(this.dimension.id, 22, true);
    drawer.addShape(shape);
  }
  /**
   * Ensures the chunk containing this location is loaded before continuing.
   * @param {number} timeout Number of ticks before it gives up.
   */
  ensureLoaded(timeout = 40) {
    return new Promise((resolve, reject) => {
      let c2 = 0;
      const interval = system3.runInterval(() => {
        c2++;
        if (this.isLoaded()) {
          system3.clearRun(interval);
          resolve(this);
        } else if (c2 >= timeout) {
          system3.clearRun(interval);
          reject(`Chunk ${this.x} ${this.z} timed out!`);
        }
      }, 1);
    });
  }
};
var ChunkVolume = class {
  "from";
  to;
  constructor(from, to) {
    this.from = from;
    this.to = to;
  }
  /**
   * Returns an iterator that yields all chunk positions in the volume.
   */
  getChunkLocationIterator() {
    const min2 = this.getMin();
    const max2 = this.getMax();
    function* generator() {
      for (let x2 = min2.x; x2 <= max2.x; x2++) {
        for (let z2 = min2.z; z2 <= max2.z; z2++) {
          yield { x: x2, z: z2 };
        }
      }
    }
    return generator();
  }
  /**
   * Get this chunk volume as a block volume.
   * @returns {BlockVolume}
   */
  getBlockVolume() {
    const from = { x: this.from.x * 16, y: -64, z: this.from.z * 16 };
    const to = { x: this.to.x * 16, y: 320, z: this.to.z * 16 };
    return new BlockVolume3(from, Vector3Utils.add(to, { x: 16, y: 0, z: 16 }));
  }
  /**
   * @remarks
   * Return the capacity (volume) of the ChunkVolume (W*H)
   *
   */
  getCapacity() {
    const span = this.getSpan();
    return span.x * span.z;
  }
  /**
   * @remarks
   * Get the largest corner position of the volume (guaranteed to
   * be >= min)
   */
  getMax() {
    const x2 = Math.max(this.from.x, this.to.x);
    const z2 = Math.max(this.from.z, this.to.z);
    return { x: x2, z: z2 };
  }
  /**
   * @remarks
   * Get the smallest corner position of the volume (guaranteed
   * to be <= max)
   */
  getMin() {
    const x2 = Math.min(this.from.x, this.to.x);
    const z2 = Math.min(this.from.z, this.to.z);
    return { x: x2, z: z2 };
  }
  /**
   * @remarks
   * Get a {@link Vector3} object where each component represents
   * the number of blocks along that axis
   *
   */
  getSpan() {
    const min2 = this.getMin();
    const max2 = this.getMax();
    return { x: max2.x - min2.x, z: max2.z - min2.z };
  }
  /**
   * @remarks
   * Check to see if a given world block location is inside a
   * ChunkVolume
   *
   */
  isInside(location) {
    return false;
  }
  /**
   * @remarks
   * Move a ChunkVolume by a specified amount
   *
   * @param delta
   * Amount of chunks to move by
   */
  translate(delta) {
    this.from = { x: this.from.x + delta.x, z: this.from.z + delta.z };
    this.to = { x: this.to.x + delta.x, z: this.to.z + delta.z };
  }
};

// node_modules/@lpsmods/mc-utils/src/type.ts
var Typing = class {
  static get(value) {
    const type2 = typeof value;
    if (Array.isArray(value)) return "array" /* Array */;
    if (value instanceof Container) return "container" /* Container */;
    if (value instanceof Block2) return "block" /* Block */;
    if (value instanceof ItemStack) return "item" /* ItemStack */;
    if (value instanceof Chunk) return "chunk" /* Chunk */;
    if (value instanceof Entity3) return "entity" /* Entity */;
    if (value instanceof Dimension4) return "dimension" /* Dimension */;
    if (value instanceof BlockType2) return "blockType" /* BlockType */;
    if (value instanceof ItemType) return "itemType" /* ItemType */;
    if (value instanceof EntityType) return "entityType" /* EntityType */;
    if (value instanceof EffectType) return "effectType" /* EffectType */;
    if (value instanceof DimensionType) return "dimensionType" /* DimensionType */;
    if (value instanceof EnchantmentType) return "enchantmentType" /* EnchantmentType */;
    if (value instanceof BlockPermutation3) return "blockPermutation" /* BlockPermutation */;
    switch (type2) {
      case "bigint":
        return "bigint" /* BigInt */;
      case "boolean":
        return "boolean" /* Boolean */;
      case "number":
        return "number" /* Number */;
      case "object":
        if ("x" in value && "y" in value && "z" in value) return "vector3" /* Vector3 */;
        if ("x" in value && "y" in value) return "vector2" /* Vector2 */;
        if ("x" in value && "z" in value) return "vectorxz" /* VectorXZ */;
        return "object" /* Object */;
      case "string":
        return "string" /* String */;
      case "undefined":
        return "undefined" /* Undefined */;
    }
  }
};
var Hasher = class {
  static parseVec3(value) {
    if (!value) return VECTOR3_ZERO;
    const points = value.split(",");
    const x2 = +points[0];
    const y2 = +points[1];
    const z2 = +points[2];
    return { x: x2, y: y2, z: z2 };
  }
  static parseVec2(value) {
    if (!value) return VECTOR2_ZERO;
    const points = value.split(",");
    const x2 = +points[0];
    const y2 = +points[1];
    return { x: x2, y: y2 };
  }
  static parseVecXZ(value) {
    if (!value) return { x: 0, z: 0 };
    const points = value.split(",");
    const x2 = +points[0];
    const z2 = +points[1];
    return { x: x2, z: z2 };
  }
  static parseBlock(value) {
    if (!value) return void 0;
    const points = value.split(",");
    let dim = points[0];
    let location = this.parseVec3(points.slice(1, 4).join(","));
    if (!location) return void 0;
    return world3.getDimension(dim).getBlock(location);
  }
  static parseChunk(value) {
    if (!value) return void 0;
    const points = value.split(",");
    let dim = points[0];
    let location = this.parseVecXZ(points.slice(1, 3).join(","));
    if (!location) return void 0;
    return new Chunk(world3.getDimension(dim), location);
  }
  static stringify(value) {
    if (!value) return value;
    const t4 = Typing.get(value);
    switch (t4) {
      case "container" /* Container */:
        return this.hashContainer(value);
      case "block" /* Block */:
        return this.hashBlock(value);
      case "vectorxz" /* VectorXZ */:
        return this.hashVecXZ(value);
      case "vector3" /* Vector3 */:
        return this.hashVec3(value);
      case "vector2" /* Vector2 */:
        return this.hashVec2(value);
      case "chunk" /* Chunk */:
        return this.hashChunk(value);
      default:
        throw new Error(`Unknown type "${t4}"`);
    }
  }
  static hashVecXZ(pos) {
    return `${pos.x},${pos.z}`;
  }
  static hashVec3(pos) {
    return `${pos.x},${pos.y},${pos.z}`;
  }
  static hashVec2(pos) {
    return `${pos.x},${pos.y}`;
  }
  static hashChunk(chunk) {
    return `${chunk.dimension.id},${this.hashVecXZ(chunk.location)}`;
  }
  static hashContainer(container) {
    const contents = [];
    for (let i2 = 0; i2 < container.size; i2++) {
      const item = container.getItem(i2);
      contents.push(item ? `${item.typeId}:${item.amount}` : "");
    }
    return contents.join("|");
  }
  static hashBlock(block) {
    if (!block) return "air";
    return `${block.dimension.id},${this.hashVec3(block.location)},${block.typeId}`;
  }
};

// node_modules/@lpsmods/mc-utils/src/world/world_border.ts
import {
  world as world4
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/ui/action_form.ts
import { world as world5 } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

// node_modules/@lpsmods/mc-utils/src/utils/text.ts
var TextUtils = class {
  /**
   * Removes strings from text.
   * @param {string} text
   * @param {string[]} strings
   * @returns {string}
   */
  static stripAll(text, strings, prefix, suffix) {
    strings = strings.map((str) => (prefix ?? "") + str + (suffix ?? ""));
    const regex = new RegExp(strings.join("|"), "gi");
    return text.replace(regex, "");
  }
  // TODO: Add support for HTML `<em>Italic</em>`
  /**
   * Uses markdown to format text.
   * @param {string} text
   * @returns {string|RawMessage}
   */
  static renderMarkdown(text) {
    if (typeof text !== "string") return text;
    const ESCAPES = [
      [/\\\\/g, ""],
      [/\\\*/g, ""],
      [/\\_/g, ""],
      [/\\~/g, ""],
      [/\\`/g, ""],
      [/\\&/g, ""]
    ];
    for (const [pattern, replacement] of ESCAPES) {
      text = text.replace(pattern, replacement);
    }
    text = text.replace(/\\n/g, "\n");
    text = text.replace(/&(.)/g, "\xA7$1");
    text = text.replace(/\*\*(.*?)\*\*/gs, "\xA7l$1\xA7r").replace(/\*(.*?)\*/gs, "\xA7o$1\xA7r").replace(/`(.*?)`/gs, "\xA7k$1\xA7r");
    text = text.replace(/^[-+*] (.*)$/gm, "\xA77\u25A0\xA7r $1");
    text = text.replace(/^(\d+)\. (.*)$/gm, "\xA77$1.\xA7r $2");
    const UNESCAPES = [
      [/\u0001/g, "*"],
      [/\u0002/g, "_"],
      [/\u0003/g, "~"],
      [/\u0004/g, "`"],
      [/\u0005/g, "&"],
      [/\u0006/g, "\\"]
    ];
    for (const [pattern, replacement] of UNESCAPES) {
      text = text.replace(pattern, replacement);
    }
    return text;
  }
  /**
   * Makes the text title case.
   * @param {String} text
   * @returns {string}
   */
  static titleCase(text) {
    return text.toLowerCase().replace(/\b\w/g, (s2) => s2.toUpperCase());
  }
  /**
   * Highlights all occurrences of a query string in the given text by wrapping them
   * with §6 and §r, and clamps the result to include up to 5 characters on each side
   * of each match. Multiple matches are supported, and overlapping ranges are merged.
   *
   * @param {string} query - The search term to highlight within the text. Case-insensitive.
   * @param {string} text - The full text to search within.
   * @param {number} padding
   * @returns A string containing the highlighted matches, each with 5 characters of surrounding context.
   */
  static highlightQuery(query, text, padding = 15, color = "\xA76" /* Gold */) {
    if (!query) return text;
    const escapedQuery = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(escapedQuery, "gi");
    const matches = [];
    let match;
    while ((match = regex.exec(text)) !== null) {
      matches.push({ start: match.index, end: match.index + match[0].length });
    }
    if (matches.length === 0) {
      return text;
    }
    const mergedRanges = [];
    for (const { start, end } of matches) {
      const extendedStart = Math.max(0, start - padding);
      const extendedEnd = Math.min(text.length, end + padding);
      if (mergedRanges.length > 0 && mergedRanges[mergedRanges.length - 1].end >= extendedStart) {
        mergedRanges[mergedRanges.length - 1].end = Math.max(mergedRanges[mergedRanges.length - 1].end, extendedEnd);
      } else {
        mergedRanges.push({ start: extendedStart, end: extendedEnd });
      }
    }
    const clampedSnippets = mergedRanges.map(({ start, end }) => {
      const snippet = text.slice(start, end);
      return snippet.replace(regex, (m2) => `${color}${m2}\xA7r`);
    });
    return clampedSnippets.join(" ... ").trim();
  }
  /**
   * Highlight JSON.
   * @param {unknown} data
   * @param {RenderJsonOptions} options
   * @returns {string}
   */
  static renderJSON(data, options) {
    const json = JSON.stringify(data, null, options?.indent ?? 2);
    const stringColor = options?.stringColor ?? "\xA7n" /* MaterialCopper */;
    const keyColor = options?.keyColor ?? "\xA7b" /* Aqua */;
    const defaultColor = options?.defaultColor ?? "\xA7f" /* White */;
    const numberColor = options?.numberColor ?? "\xA7a" /* Green */;
    return json.replace(/\"([^"]+)\"/g, `${stringColor}"$1"\xA7r`).replace(/§a\"([^"]+)\"§r\s*:/g, `${keyColor}"$1"\xA7r${defaultColor}:`).replace(/\b(-?\d+(?:\.\d+)?)\b/g, `${numberColor}$1\xA7r`).replace(/\b(true|false)\b/g, `\xA79$1\xA7r`).replace(/\bnull\b/g, `\xA77null\xA7r`).replace(/([\{\}\[\]])/g, `${defaultColor}$1\xA7r`).replace(/,/g, `${defaultColor},\xA7r`);
  }
  /**
   * Converts a number to roman numerals.
   * @param {number} num 1-3999
   * @returns {string}
   */
  static toRoman(num) {
    if (num <= 0 || num >= 4e3) {
      throw new RangeError("Number must be between 1 and 3999");
    }
    const romanMap = [
      [1e3, "M"],
      [900, "CM"],
      [500, "D"],
      [400, "CD"],
      [100, "C"],
      [90, "XC"],
      [50, "L"],
      [40, "XL"],
      [10, "X"],
      [9, "IX"],
      [5, "V"],
      [4, "IV"],
      [1, "I"]
    ];
    let result = "";
    for (const [value, numeral] of romanMap) {
      while (num >= value) {
        result += numeral;
        num -= value;
      }
    }
    return result;
  }
};

// node_modules/@lpsmods/mc-utils/src/ui/action_form.ts
var ActionFormEvent = class {
  constructor(ui, player, ctx) {
    this.ui = ui;
    this.player = player;
    this.ctx = ctx;
  }
  ui;
  player;
  ctx;
};
var ActionFormShowEvent = class extends ActionFormEvent {
  /**
   * When cancel is true it will not show the form.
   */
  cancel = false;
};
function t(text) {
  if (typeof text !== "string") return text;
  const content = text.charAt(0) == "#" ? { translate: text.toString().slice(1) } : text;
  return TextUtils.renderMarkdown(content);
}
var ActionFormHandler = class _ActionFormHandler {
  form;
  options;
  id;
  static #lastId = 0;
  constructor(form, options) {
    this.options = options ?? {};
    this.form = form;
    this.id = this.options.id ?? `${_ActionFormHandler.#lastId++}`;
  }
  /**
   * Show this form to the player.
   * @param {Player} player
   * @param {any} ctx
   * @returns {boolean}
   */
  show(player, ctx) {
    const ui = new ActionFormData();
    const event = new ActionFormEvent(ui, player, ctx);
    const showEvent = new ActionFormShowEvent(ui, player, ctx);
    if (this.form.onShow) this.form.onShow(showEvent);
    if (showEvent.cancel) return false;
    if (this.form.title) {
      ui.title(t(this.form.title));
    }
    if (this.form.body) {
      ui.body(t(this.form.body));
    }
    const btns = [];
    if (this.form.buttons) {
      for (const btn of this.form.buttons) {
        if (btn.condition && !btn.condition(event)) continue;
        if (btn.top_margin) for (let c2 = 0; c2 < btn.top_margin; c2++) ui.label("");
        if (btn.top_divider) ui.divider();
        ui.button(t(btn.label), btn.icon);
        if (btn.bottom_margin) for (let c2 = 0; c2 < btn.bottom_margin; c2++) ui.label("");
        if (btn.bottom_divider) ui.divider();
        btns.push(btn);
      }
    }
    const res = ui.show(player);
    res.then((res2) => {
      if (this.form.onClose) this.form.onClose(event);
      if (res2.canceled) return;
      if (res2.selection === void 0) return;
      const btn = btns[res2.selection];
      if (btn.onClick) btn.onClick(event);
    });
    return true;
  }
  /**
   * Show the form to all players.
   * @param {any} ctx
   */
  showAll(ctx) {
    for (const player of world5.getAllPlayers()) {
      this.show(player, ctx);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/ui/modal_form.ts
import { world as world6 } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
function t2(text) {
  if (typeof text !== "string") return text;
  const content = text.charAt(0) == "#" ? { translate: text.toString().slice(1) } : text;
  return TextUtils.renderMarkdown(content);
}
var ModalFormEvent = class {
  constructor(ui, player, ctx) {
    this.ui = ui;
    this.player = player;
    this.ctx = ctx;
  }
  ui;
  player;
  ctx;
};
var ModelFormShowEvent = class extends ModalFormEvent {
  /**
   * When cancel is true it will not show the form.
   */
  cancel = false;
};
var ModalFormOnSubmit = class extends ModalFormEvent {
  constructor(ui, player, formResult, ctx) {
    super(ui, player, ctx);
    this.formResult = formResult;
  }
  formResult;
};
var ModalFormHandler = class _ModalFormHandler {
  form;
  saveValues;
  id;
  store;
  options;
  static #lastId = 0;
  constructor(form, options) {
    this.options = options ?? {};
    this.form = form;
    this.saveValues = this.options.saveValues ?? true;
    this.id = this.options.id ?? `${_ModalFormHandler.#lastId++}`;
    this.store = new DataStorage2(`mcutils:form_${this.id}`);
  }
  #buildText(ui, option) {
    ui.textField(t2(option.label), t2(option.placeholder ?? ""), {
      defaultValue: option.value?.toString(),
      tooltip: option.tooltip ? t2(option.tooltip) : void 0
    });
  }
  #buildDropdown(ui, option) {
    ui.dropdown(t2(option.label), option.options ?? ["unset"], {
      defaultValueIndex: option.value ?? 0,
      tooltip: option.tooltip ? t2(option.tooltip) : void 0
    });
  }
  #buildSlider(ui, option) {
    ui.slider(t2(option.label), option.min ?? 0, option.max ?? 100, {
      valueStep: option.step ?? 1,
      defaultValue: option.value ?? 0,
      tooltip: option.tooltip ? t2(option.tooltip) : void 0
    });
  }
  #buildToggle(ui, option) {
    ui.toggle(t2(option.label), {
      defaultValue: option.value ?? false,
      tooltip: option.tooltip ? t2(option.tooltip) : void 0
    });
  }
  #buildOptions(ui, option) {
    switch (option.type ?? "text") {
      case "text":
        return this.#buildText(ui, option);
      case "dropdown":
        return this.#buildDropdown(ui, option);
      case "slider":
        return this.#buildSlider(ui, option);
      case "toggle":
        return this.#buildToggle(ui, option);
    }
  }
  #build(ui, event) {
    if (this.form.title) {
      ui.title(t2(this.form.title));
    }
    if (this.form.submitLabel) {
      ui.submitButton(t2(this.form.submitLabel));
    }
    const keys = [];
    if (this.form.options) {
      const defaults = this.saveValues ? this.#read() : {};
      for (const k2 of Object.keys(this.form.options)) {
        const option = this.form.options[k2];
        if (option.condition && !option.condition(event)) continue;
        keys.push(k2);
        this.#buildOptions(ui, option);
      }
    }
    return keys;
  }
  /**
   * Show this form to the player.
   * @param {Player} player
   * @param {any} ctx
   * @returns {boolean}
   */
  show(player, ctx) {
    const ui = new ModalFormData();
    const event = new ModalFormEvent(ui, player, ctx);
    const showEvent = new ModelFormShowEvent(ui, player, ctx);
    if (this.form.onShow) this.form.onShow(showEvent);
    if (showEvent.cancel) return false;
    const keys = this.#build(ui, event);
    const res = ui.show(player);
    res.then((res2) => {
      if (res2.canceled || res2.formValues === void 0) return this.form.onClose ? this.form.onClose(event) : void 0;
      const results = {};
      for (const i2 in keys) {
        const v2 = res2.formValues[i2];
        const k2 = keys[i2];
        results[k2] = v2;
      }
      const submit = new ModalFormOnSubmit(ui, player, results, ctx);
      if (this.saveValues) this.#write(results);
      if (this.form.onSubmit) this.form.onSubmit(submit);
    });
    return true;
  }
  /**
   * Show the form to all players.
   * @param {any} ctx
   */
  showAll(ctx) {
    for (const player of world6.getAllPlayers()) {
      this.show(player, ctx);
    }
  }
  #read() {
    const results = {};
    const keys = this.store.keys();
    for (const k2 of keys) {
      results[k2] = this.store.getItem(k2);
    }
    return results;
  }
  #write(value) {
    this.store.update(value);
  }
};

// node_modules/@lpsmods/mc-utils/src/ui/paged_action_form.ts
import { world as world9 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/utils/addon.ts
import { BlockTypes, EntityTypes, ItemTypes } from "@minecraft/server";
var AddonUtils = class {
  static addonId = "mcutils";
  /**
   * Returns a identifier with the PROJECT_ID as the namespace.
   * @param {string} path
   * @returns {string}
   */
  static makeId(path) {
    return `${this.addonId}:${path}`;
  }
  /**
   * All blocks added by this Add-On.
   * @returns {BlockType[]}
   */
  static getBlockTypes() {
    return BlockTypes.getAll().filter((block) => block.id.startsWith(this.addonId + ":"));
  }
  /**
   * All blocks added by this Add-On.
   * @returns {ItemType[]}
   */
  static getItemTypes() {
    return ItemTypes.getAll().filter((item) => item.id.startsWith(this.addonId + ":"));
  }
  /**
   * All entities added by this Add-On.
   * @returns {EntityType[]}
   */
  static getEntityTypes() {
    return EntityTypes.getAll().filter((entity) => entity.id.startsWith(this.addonId + ":"));
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/attack.ts
import { EntityDamageCause } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/utils/direction.ts
import { Direction } from "@minecraft/server";
var DirectionUtils = class _DirectionUtils {
  /**
   * Converts a {@link Vector2} rotation to facing direction.
   * @param {Vector2} rotation
   * @returns {Direction}
   */
  static rot2dir(rotation) {
    const { x: pitch, y: yaw } = rotation;
    if (pitch <= -45) return Direction.Up;
    if (pitch >= 45) return Direction.Down;
    const norm = (yaw % 360 + 540) % 360 - 180;
    if (norm >= -45 && norm < 45) return Direction.South;
    if (norm >= 45 && norm < 135) return Direction.West;
    if (norm >= -135 && norm < -45) return Direction.East;
    return Direction.North;
  }
  /**
   * Converts a number to a direction.
   * @param {number} num
   * @returns {Direction}
   */
  static fromNumber(num) {
    switch (num) {
      case 0:
        return Direction.North;
      case 1:
        return Direction.South;
      case 2:
        return Direction.East;
      case 3:
        return Direction.West;
      case 4:
        return Direction.Up;
      case 5:
        return Direction.Down;
      default:
        return Direction.North;
    }
  }
  /**
   * Rotates the Y direction counterclockwise.
   * @param {string} dir
   * @returns {Direction}
   */
  static rotateYCounterclockwise(dir) {
    if (!dir) {
      return Direction.North;
    }
    if (typeof dir == "number") dir = _DirectionUtils.fromNumber(dir);
    switch (dir.toLowerCase()) {
      case "north":
        return Direction.East;
      case "east":
        return Direction.South;
      case "south":
        return Direction.West;
      case "west":
        return Direction.North;
      default:
        return Direction.North;
    }
  }
  /**
   * Returns the primary cardinal direction from one location to another.
   * @param {Vector3} origin
   * @param {Vector3} target
   * @returns {Direction|undefined}
   */
  static relDir(origin, target) {
    const dx = target.x - origin.x;
    const dy = target.y - origin.y;
    const dz = target.z - origin.z;
    if (dx === 0 && dy === 0 && dz === 0) return void 0;
    if (Math.abs(dx) >= Math.abs(dy) && Math.abs(dx) >= Math.abs(dz)) {
      return dx > 0 ? Direction.West : Direction.East;
    } else if (Math.abs(dz) >= Math.abs(dx) && Math.abs(dz) >= Math.abs(dy)) {
      return dz > 0 ? Direction.North : Direction.South;
    } else {
      return dy > 0 ? Direction.Down : Direction.Up;
    }
  }
  /**
   * Get the opposite direction.
   * @param {string|number} dir
   * @returns {Direction}
   */
  static getOpposite(dir) {
    if (!dir) {
      return Direction.North;
    }
    if (typeof dir == "number") dir = _DirectionUtils.fromNumber(dir);
    switch (dir.toLowerCase()) {
      case "north":
        return Direction.South;
      case "south":
        return Direction.North;
      case "east":
        return Direction.West;
      case "west":
        return Direction.East;
      case "top":
        return "bottom";
      case "above":
        return Direction.Down;
      case "bottom":
        return "top";
      case "below":
        return Direction.Up;
      default:
        return Direction.North;
    }
  }
  /**
   * Convert direction to an axis.
   * @param {string} dir
   * @returns {string}
   */
  static toAxis(dir) {
    if (!dir) {
      return "x";
    }
    if (typeof dir == "number") dir = _DirectionUtils.fromNumber(dir);
    switch (dir.toLowerCase()) {
      case "north":
      case "south":
        return "x";
      case "east":
      case "west":
        return "z";
      case "top":
      case "bottom":
        return "y";
      default:
        return "x";
    }
  }
  /**
   * Convert a direction to offset location.
   * @param {string|number} dir
   * @returns {Vector3}
   */
  static toOffset(dir) {
    if (!dir) {
      return { x: 0, y: 0, z: -1 };
    }
    if (typeof dir == "number") dir = _DirectionUtils.fromNumber(dir);
    switch (dir.toLowerCase()) {
      case "north":
        return VECTOR3_NORTH;
      case "south":
        return VECTOR3_SOUTH;
      case "east":
        return VECTOR3_EAST;
      case "west":
        return VECTOR3_WEST;
      case "top":
      case "above":
      case "up":
        return VECTOR3_UP;
      case "bottom":
      case "below":
      case "down":
        return VECTOR3_DOWN;
      default:
        return VECTOR3_ZERO;
    }
  }
  /**
   * Convert a direction to rotation.
   * @param {string|number} dir
   * @returns {Vector2}
   */
  static toRotation(dir) {
    if (!dir) {
      return VECTOR2_ZERO;
    }
    if (typeof dir == "number") dir = _DirectionUtils.fromNumber(dir);
    switch (dir.toLowerCase()) {
      case "north":
        return { x: 0, y: 180 };
      case "south":
        return VECTOR2_ZERO;
      case "east":
        return { x: 0, y: -90 };
      case "west":
        return { x: 0, y: 90 };
      case "above":
      case "up":
        return { x: -90, y: 0 };
      case "below":
      case "down":
        return { x: 90, y: 0 };
      default:
        return VECTOR2_ZERO;
    }
  }
  /**
   * Returns world offset vector from a local (^ ^ ^) offset and direction
   * @param local Local offset in ^ ^ ^ space
   * @param direction Cardinal direction (north, south, east, west)
   * @returns Offset in world space
   */
  static offsetFromDirection(local, direction) {
    let forward;
    let left;
    const up = { x: 0, y: 1, z: 0 };
    switch (direction.toLowerCase()) {
      case "north":
        forward = { x: 0, y: 0, z: -1 };
        left = { x: 1, y: 0, z: 0 };
        break;
      case "south":
        forward = { x: 0, y: 0, z: 1 };
        left = { x: -1, y: 0, z: 0 };
        break;
      case "east":
        forward = { x: 1, y: 0, z: 0 };
        left = { x: 0, y: 0, z: 1 };
        break;
      case "west":
        forward = { x: -1, y: 0, z: 0 };
        left = { x: 0, y: 0, z: -1 };
        break;
      default:
        throw new Error("Unsupported direction: " + direction);
    }
    return {
      x: local.x * left.x + local.y * up.x + local.z * forward.x,
      y: local.x * left.y + local.y * up.y + local.z * forward.y,
      z: local.x * left.z + local.y * up.z + local.z * forward.z
    };
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/molang.ts
import {
  EquipmentSlot,
  GameMode,
  Player as Player4,
  system as system4,
  world as world7
} from "@minecraft/server";

// node_modules/molang/dist/molang.esm.js
var e = { "!": "BANG", "&": "AND", "(": "LEFT_PARENT", ")": "RIGHT_PARENT", "*": "ASTERISK", "+": "PLUS", ",": "COMMA", "-": "MINUS", "/": "SLASH", ":": "COLON", ";": "SEMICOLON", "<": "SMALLER", "=": "EQUALS", ">": "GREATER", "?": "QUESTION", "[": "ARRAY_LEFT", "]": "ARRAY_RIGHT", "{": "CURLY_LEFT", "|": "OR", "}": "CURLY_RIGHT" };
var t3 = /* @__PURE__ */ new Set(["return", "continue", "break", "for_each", "loop", "false", "true"]);
var s = class {
  constructor(e2, t4, s2, r2) {
    this.type = e2, this.text = t4, this.startColumn = s2, this.startLine = r2;
  }
  getType() {
    return this.type;
  }
  getText() {
    return this.text;
  }
  getPosition() {
    return { startColumn: this.startColumn, startLineNumber: this.startLine, endColumn: this.startColumn + this.text.length, endLineNumber: this.startLine };
  }
};
var r = class {
  constructor(e2) {
    this.i = 0, this.currentColumn = 0, this.currentLine = 0, this.lastColumns = 0, this.keywordTokens = e2 ? /* @__PURE__ */ new Set([...t3, ...e2]) : t3;
  }
  init(e2) {
    this.currentLine = 0, this.currentColumn = 0, this.lastColumns = 0, this.i = 0, this.expression = e2;
  }
  next() {
    for (this.currentColumn = this.i - this.lastColumns; this.i < this.expression.length && (" " === this.expression[this.i] || "	" === this.expression[this.i] || "\n" === this.expression[this.i]); ) "\n" === this.expression[this.i] && (this.currentLine++, this.currentColumn = 0, this.lastColumns = this.i + 1), this.i++;
    if ("#" === this.expression[this.i]) {
      const e2 = this.expression.indexOf("\n", this.i + 1);
      return this.i = -1 === e2 ? this.expression.length : e2, this.currentLine++, this.lastColumns = this.i + 1, this.currentColumn = 0, this.next();
    }
    let t4 = e[this.expression[this.i]];
    if (t4) return new s(t4, this.expression[this.i++], this.currentColumn, this.currentLine);
    if (this.isLetter(this.expression[this.i]) || "_" === this.expression[this.i]) {
      let e2 = this.i + 1;
      for (; e2 < this.expression.length && (this.isLetter(this.expression[e2]) || this.isNumber(this.expression[e2]) || "_" === this.expression[e2] || "." === this.expression[e2]); ) e2++;
      const t5 = this.expression.substring(this.i, e2).toLowerCase();
      return this.i = e2, new s(this.keywordTokens.has(t5) ? t5.toUpperCase() : "NAME", t5, this.currentColumn, this.currentLine);
    }
    if (this.isNumber(this.expression[this.i]) || "." === this.expression[this.i]) {
      let e2 = this.i + 1, t5 = "." === this.expression[this.i];
      for (; e2 < this.expression.length && (this.isNumber(this.expression[e2]) || "." === this.expression[e2] && !t5); ) "." === this.expression[e2] && (t5 = true), e2++;
      const r2 = new s("NUMBER", this.expression.substring(this.i, e2), this.currentColumn, this.currentLine), i2 = t5 && "f" === this.expression[e2];
      return this.i = i2 ? e2 + 1 : e2, r2;
    }
    if ("'" === this.expression[this.i]) {
      let e2 = this.i + 1;
      for (; e2 < this.expression.length && "'" !== this.expression[e2]; ) e2++;
      e2++;
      const t5 = new s("STRING", this.expression.substring(this.i, e2), this.currentColumn, this.currentLine);
      return this.i = e2, t5;
    }
    return this.hasNext() ? (this.i++, this.next()) : new s("EOF", "", this.currentColumn, this.currentLine);
  }
  hasNext() {
    return this.i < this.expression.length;
  }
  isLetter(e2) {
    return e2 >= "a" && e2 <= "z" || e2 >= "A" && e2 <= "Z";
  }
  isNumber(e2) {
    return e2 >= "0" && e2 <= "9";
  }
};
var i = (e2, t4, s2) => "number" != typeof e2 || Number.isNaN(e2) ? t4 : e2 > s2 ? s2 : e2 < t4 ? t4 : e2;
var n = (e2, t4, s2) => {
  let r2 = 0;
  for (; 0 < e2; ) r2 += p(t4, s2);
  return r2;
};
var o = (e2, t4, s2) => {
  let r2 = 0;
  for (; 0 < e2; ) r2 += l(t4, s2);
  return r2;
};
var a = (e2) => 3 * e2 ** 2 - 2 * e2 ** 3;
var h = (e2, t4, s2) => (s2 < 0 ? s2 = 0 : s2 > 1 && (s2 = 1), e2 + (t4 - e2) * s2);
var c = (e2, t4, s2) => {
  const r2 = (e3) => ((e3 + 180) % 360 + 180) % 360;
  if ((e2 = r2(e2)) > (t4 = r2(t4))) {
    let s3 = e2;
    e2 = t4, t4 = s3;
  }
  return t4 - e2 > 180 ? r2(t4 + s2 * (360 - (t4 - e2))) : e2 + s2 * (t4 - e2);
};
var u = (e2, t4) => e2 % t4;
var p = (e2, t4) => e2 + Math.random() * (t4 - e2);
var l = (e2, t4) => Math.round(e2 + Math.random() * (t4 - e2));
var x = (e2) => ((e2 = ((e2 %= 360) + 360) % 360) > 179 && (e2 -= 360), e2);
var E = (e2) => {
  const t4 = e2 ? 1 : Math.PI / 180;
  return { "math.abs": Math.abs, "math.acos": (e3) => Math.acos(e3) / t4, "math.asin": (e3) => Math.asin(e3) / t4, "math.atan": (e3) => Math.atan(e3) / t4, "math.atan2": (e3, s2) => Math.atan2(e3, s2) / t4, "math.ceil": Math.ceil, "math.clamp": i, "math.cos": (e3) => Math.cos(e3 * t4), "math.die_roll": n, "math.die_roll_integer": o, "math.exp": Math.exp, "math.floor": Math.floor, "math.hermite_blend": a, "math.lerp": h, "math.lerp_rotate": c, "math.ln": Math.log, "math.max": Math.max, "math.min": Math.min, "math.min_angle": x, "math.mod": u, "math.pi": Math.PI, "math.pow": Math.pow, "math.random": p, "math.random_integer": l, "math.round": Math.round, "math.sin": (e3) => Math.sin(e3 * t4), "math.sqrt": Math.sqrt, "math.trunc": Math.trunc };
};
var f = { "query.in_range": (e2, t4, s2) => "number" != typeof e2 || "number" != typeof t4 || "number" != typeof s2 ? (console.error('"query.in_range": value, min and max must be numbers'), false) : e2 >= t4 && e2 <= s2, "query.all": (e2, ...t4) => t4.every((t5) => t5 === e2), "query.any": (e2, ...t4) => t4.some((t5) => t5 === e2), "query.count": (e2) => Array.isArray(e2) ? e2.length : 1 };
var g = (e2) => ({ ...E(e2), ...f });
var m = class {
  constructor(e2, t4) {
    if (this.config = t4, !e2) throw new Error("Provided environment must be an object");
    this.env = { ...g(t4.useRadians ?? false), "query.self": () => this.env, ...t4.isFlat ? e2 : this.flattenEnv(e2) };
  }
  updateConfig({ variableHandler: e2, convertUndefined: t4, useRadians: s2 }) {
    void 0 !== t4 && (this.config.convertUndefined = t4), "function" == typeof e2 && (this.config.variableHandler = e2), !!this.config.useRadians != !!s2 && (this.env = Object.assign(this.env, g(!!s2)));
  }
  get() {
    return this.env;
  }
  flattenEnv(e2, t4 = "", s2 = {}) {
    for (let r2 in e2) {
      let i2 = r2;
      if ("." === r2[1]) switch (r2[0]) {
        case "q":
          i2 = "query" + r2.substring(1, r2.length);
          break;
        case "t":
          i2 = "temp" + r2.substring(1, r2.length);
          break;
        case "v":
          i2 = "variable" + r2.substring(1, r2.length);
          break;
        case "c":
          i2 = "context" + r2.substring(1, r2.length);
          break;
        case "f":
          i2 = "function" + r2.substring(1, r2.length);
      }
      e2[r2].__isContext ? s2[`${t4}${i2}`] = e2[r2].env : "object" != typeof e2[r2] || Array.isArray(e2[r2]) ? s2[`${t4}${i2}`] = e2[r2] : this.flattenEnv(e2[r2], `${t4}${r2}.`, s2);
    }
    return s2;
  }
  setAt(e2, t4) {
    if ("." === e2[1]) switch (e2[0]) {
      case "q":
        e2 = "query" + e2.substring(1, e2.length);
        break;
      case "t":
        e2 = "temp" + e2.substring(1, e2.length);
        break;
      case "v":
        e2 = "variable" + e2.substring(1, e2.length);
        break;
      case "c":
        e2 = "context" + e2.substring(1, e2.length);
        break;
      case "f":
        e2 = "function" + e2.substring(1, e2.length);
    }
    return this.env[e2] = t4;
  }
  getFrom(e2) {
    if ("." === e2[1]) switch (e2[0]) {
      case "q":
        e2 = "query" + e2.substring(1, e2.length);
        break;
      case "t":
        e2 = "temp" + e2.substring(1, e2.length);
        break;
      case "v":
        e2 = "variable" + e2.substring(1, e2.length);
        break;
      case "c":
        e2 = "context" + e2.substring(1, e2.length);
        break;
      case "f":
        e2 = "function" + e2.substring(1, e2.length);
    }
    const t4 = this.env[e2] ?? this.config.variableHandler?.(e2, this.env);
    return void 0 === t4 && this.config.convertUndefined ? 0 : t4;
  }
};
var d = class {
  toString() {
    return "" + this.eval();
  }
  walk(e2, t4 = /* @__PURE__ */ new Set()) {
    let s2 = e2(this) ?? this;
    return s2.iterate(e2, t4), s2;
  }
  iterate(e2, t4) {
    for (let s2 = 0; s2 < this.allExpressions.length; s2++) {
      const r2 = this.allExpressions[s2];
      if (t4.has(r2)) continue;
      t4.add(r2);
      const i2 = e2(r2) ?? r2;
      i2 !== r2 && t4.has(i2) || (t4.add(i2), this.setExpressionAt(s2, i2), i2.iterate(e2, t4));
    }
  }
  some(e2) {
    return this.allExpressions.some((t4) => e2(t4) || t4.some(e2));
  }
};
var v = class extends d {
  constructor() {
    super(...arguments), this.type = "VoidExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return true;
  }
  eval() {
    return 0;
  }
  toString() {
    return "";
  }
};
var S = class extends d {
  constructor(e2, t4, s2, r2) {
    super(), this.left = e2, this.right = t4, this.operator = s2, this.evalHelper = r2, this.type = "GenericOperatorExpression";
  }
  get allExpressions() {
    return [this.left, this.right];
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.left = t4 : 1 === e2 && (this.right = t4);
  }
  isStatic() {
    return this.left.isStatic() && this.right.isStatic();
  }
  eval() {
    return this.evalHelper(this.left, this.right);
  }
  toString() {
    return `${this.left.toString()}${this.operator}${this.right.toString()}`;
  }
};
var R = (e2, t4) => {
  const s2 = e2.eval(), r2 = t4.eval();
  if ("number" != typeof s2 && "boolean" != typeof s2 || "number" != typeof r2 && "boolean" != typeof r2) throw new Error(`Cannot use numeric operators for expression "${s2} + ${r2}"`);
  return s2 + r2;
};
var A = (e2, t4) => {
  const s2 = e2.eval(), r2 = t4.eval();
  if ("number" != typeof s2 && "boolean" != typeof s2 || "number" != typeof r2 && "boolean" != typeof r2) throw new Error(`Cannot use numeric operators for expression "${s2} - ${r2}"`);
  return s2 - r2;
};
var y = (e2, t4) => {
  const s2 = e2.eval(), r2 = t4.eval();
  if ("number" != typeof s2 && "boolean" != typeof s2 || "number" != typeof r2 && "boolean" != typeof r2) throw new Error(`Cannot use numeric operators for expression "${s2} / ${r2}"`);
  return s2 / r2;
};
var C = (e2, t4) => {
  const s2 = e2.eval(), r2 = t4.eval();
  if ("number" != typeof s2 && "boolean" != typeof s2 || "number" != typeof r2 && "boolean" != typeof r2) throw new Error(`Cannot use numeric operators for expression "${s2} * ${r2}"`);
  return s2 * r2;
};
var T = (e2, t4) => {
  if (e2.setPointer) return e2.setPointer(t4.eval()), 0;
  throw Error("Cannot assign to " + e2.type);
};
var N = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    const r2 = e2.parseExpression(this.precedence), i2 = s2.getText();
    switch (i2) {
      case "+":
        return new S(t4, r2, i2, R);
      case "-":
        return new S(t4, r2, i2, A);
      case "*":
        return new S(t4, r2, i2, C);
      case "/":
        return new S(t4, r2, i2, y);
      case "=":
        return new S(t4, r2, "=", T);
      default:
        throw new Error("Operator not implemented");
    }
  }
};
var k;
!(function(e2) {
  e2[e2.SCOPE = 1] = "SCOPE", e2[e2.STATEMENT = 2] = "STATEMENT", e2[e2.ASSIGNMENT = 3] = "ASSIGNMENT", e2[e2.CONDITIONAL = 4] = "CONDITIONAL", e2[e2.ARRAY_ACCESS = 5] = "ARRAY_ACCESS", e2[e2.NULLISH_COALESCING = 6] = "NULLISH_COALESCING", e2[e2.AND = 7] = "AND", e2[e2.OR = 8] = "OR", e2[e2.EQUALS_COMPARE = 9] = "EQUALS_COMPARE", e2[e2.COMPARE = 10] = "COMPARE", e2[e2.SUM = 11] = "SUM", e2[e2.PRODUCT = 12] = "PRODUCT", e2[e2.EXPONENT = 13] = "EXPONENT", e2[e2.PREFIX = 14] = "PREFIX", e2[e2.POSTFIX = 15] = "POSTFIX", e2[e2.FUNCTION = 16] = "FUNCTION";
})(k || (k = {}));
var b = class extends d {
  constructor(e2, t4) {
    super(), this.tokenType = e2, this.expression = t4, this.type = "PrefixExpression";
  }
  get allExpressions() {
    return [this.expression];
  }
  setExpressionAt(e2, t4) {
    this.expression = t4;
  }
  isStatic() {
    return this.expression.isStatic();
  }
  eval() {
    const e2 = this.expression.eval();
    if ("number" != typeof e2) throw new Error(`Cannot use "${this.tokenType}" operator in front of ${typeof e2} "${e2}"`);
    switch (this.tokenType) {
      case "MINUS":
        return -e2;
      case "BANG":
        return !e2;
    }
  }
  toString() {
    switch (this.tokenType) {
      case "MINUS":
        return "-" + this.expression.toString();
      case "BANG":
        return "!" + this.expression.toString();
    }
    throw new Error(`Unknown prefix operator: "${this.tokenType}"`);
  }
};
var P = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new b(t4.getType(), e2.parseExpression(this.precedence));
  }
};
var I = class extends d {
  constructor(e2) {
    super(), this.value = e2, this.type = "NumberExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return true;
  }
  eval() {
    return this.value;
  }
  toString() {
    const e2 = "" + this.value;
    return e2.startsWith("0.") ? e2.slice(1) : e2;
  }
};
var L = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new I(Number(t4.getText()));
  }
};
var O = class extends d {
  constructor(e2, t4, s2 = false) {
    super(), this.executionEnv = e2, this.name = t4, this.isFunctionCall = s2, this.type = "NameExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return false;
  }
  setPointer(e2) {
    this.executionEnv.setAt(this.name, e2);
  }
  setFunctionCall(e2 = true) {
    this.isFunctionCall = e2;
  }
  setName(e2) {
    this.name = e2;
  }
  setExecutionEnv(e2) {
    this.executionEnv = e2;
  }
  eval() {
    const e2 = this.executionEnv.getFrom(this.name);
    return this.isFunctionCall || "function" != typeof e2 ? e2 : e2();
  }
  toString() {
    return this.name;
  }
};
var M = class extends d {
  constructor(e2, t4) {
    super(), this.leftExpr = e2, this.rightExpr = t4, this.type = "NameExpression";
  }
  get allExpressions() {
    return [this.leftExpr, this.rightExpr];
  }
  setExpressionAt(e2, t4) {
    if (!(t4 instanceof O)) throw new Error('Cannot use context switch operator "->" on ' + t4.type);
    0 === e2 ? this.leftExpr = t4 : 1 === e2 && (this.rightExpr = t4);
  }
  isStatic() {
    return false;
  }
  eval() {
    const e2 = this.leftExpr.eval();
    return "object" != typeof e2 ? 0 : (this.rightExpr.setExecutionEnv(new m(e2, this.rightExpr.executionEnv.config)), this.rightExpr.eval());
  }
  toString() {
    return `${this.leftExpr.toString()}->${this.rightExpr.toString()}`;
  }
};
var _ = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    const s2 = new O(e2.executionEnv, t4.getText()), r2 = [e2.lookAhead(0), e2.lookAhead(1)];
    if ("MINUS" === r2[0].getType() && "GREATER" === r2[1].getType()) {
      e2.consume("MINUS"), e2.consume("GREATER");
      const t5 = e2.parseExpression(k.FUNCTION - 1);
      if ("NameExpression" !== t5.type && "FunctionExpression" !== t5.type) throw new Error('Cannot use context switch operator "->" on ' + t5.type);
      return new M(s2, t5);
    }
    return s2;
  }
};
var U = class extends d {
  constructor(e2, t4) {
    super(), this.expression = e2, this.brackets = t4, this.type = "GroupExpression";
  }
  get allExpressions() {
    return [this.expression];
  }
  setExpressionAt(e2, t4) {
    this.expression = t4;
  }
  isStatic() {
    return this.expression.isStatic();
  }
  get isReturn() {
    return this.expression.isReturn;
  }
  get isBreak() {
    return this.expression.isBreak;
  }
  get isContinue() {
    return this.expression.isContinue;
  }
  eval() {
    return this.expression.eval();
  }
  toString() {
    return `${this.brackets[0]}${this.expression.toString()}${this.brackets[1]}`;
  }
};
var $ = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    const s2 = e2.parseExpression(this.precedence);
    return e2.consume("RIGHT_PARENT"), e2.config.keepGroups ? new U(s2, "()") : s2;
  }
};
var F = class extends d {
  constructor(e2) {
    super(), this.expression = e2, this.type = "ReturnExpression", this.isReturn = true;
  }
  get allExpressions() {
    return [this.expression];
  }
  setExpressionAt(e2, t4) {
    this.expression = t4;
  }
  isStatic() {
    return false;
  }
  eval() {
    return this.expression.eval();
  }
  toString() {
    return "return " + this.expression.toString();
  }
};
var G = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    const s2 = e2.parseExpression(k.STATEMENT + 1);
    return new F(e2.match("SEMICOLON", false) ? s2 : new I(0));
  }
};
var B = class extends d {
  constructor(e2, t4 = false) {
    super(), this.value = e2, this.isReturn = t4, this.type = "StaticExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return true;
  }
  eval() {
    return this.value;
  }
  toString() {
    let e2 = this.value;
    return "string" == typeof e2 && (e2 = `'${e2}'`), this.isReturn ? "return " + e2 : "" + e2;
  }
};
var z = class extends d {
  constructor(e2) {
    super(), this.expressions = e2, this.type = "StatementExpression", this.didReturn = void 0, this.wasLoopBroken = false, this.wasLoopContinued = false;
  }
  get allExpressions() {
    return this.expressions;
  }
  setExpressionAt(e2, t4) {
    this.expressions[e2] = t4;
  }
  get isReturn() {
    if (void 0 !== this.didReturn) return this.didReturn;
    let e2 = 0;
    for (; e2 < this.expressions.length; ) {
      const t4 = this.expressions[e2];
      if (t4.isBreak) return false;
      if (t4.isContinue) return false;
      if (t4.isReturn) return this.didReturn = true, true;
      e2++;
    }
    return this.didReturn = false, false;
  }
  get isBreak() {
    return !!this.wasLoopBroken && (this.wasLoopBroken = false, true);
  }
  get isContinue() {
    return !!this.wasLoopContinued && (this.wasLoopContinued = false, true);
  }
  isStatic() {
    let e2 = 0;
    for (; e2 < this.expressions.length; ) {
      if (!this.expressions[e2].isStatic()) return false;
      e2++;
    }
    return true;
  }
  eval() {
    this.didReturn = false, this.wasLoopBroken = false, this.wasLoopContinued = false;
    let e2 = 0;
    for (; e2 < this.expressions.length; ) {
      let t4 = this.expressions[e2].eval();
      if (this.expressions[e2].isReturn) return this.didReturn = true, t4;
      if (this.expressions[e2].isContinue) return void (this.wasLoopContinued = true);
      if (this.expressions[e2].isBreak) return void (this.wasLoopBroken = true);
      e2++;
    }
    return 0;
  }
  toString() {
    let e2 = "";
    for (const t4 of this.expressions) {
      if (t4 instanceof v || t4 instanceof B && !t4.isReturn) continue;
      const s2 = t4.toString();
      s2 && (e2 += s2 + ";");
    }
    return e2;
  }
};
var H = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  findReEntryPoint(e2) {
    let t4 = 1, s2 = e2.lookAhead(0).getType();
    for (; "EOF" !== s2 && ("CURLY_RIGHT" == s2 ? t4-- : "CURLY_LEFT" === s2 && t4++, 0 !== t4); ) e2.consume(), s2 = e2.lookAhead(0).getType();
  }
  parse(e2, t4, s2) {
    if (e2.config.useOptimizer && (t4.isStatic() && (t4 = new B(t4.eval(), t4.isReturn)), e2.config.earlyReturnsSkipParsing && t4.isReturn)) return e2.config.earlyReturnsSkipTokenization || this.findReEntryPoint(e2), new z([t4]);
    const r2 = [t4];
    if (!e2.match("CURLY_RIGHT", false)) do {
      let t5 = e2.parseExpression(this.precedence);
      if (e2.config.useOptimizer) {
        if (t5.isStatic()) {
          if (e2.config.useAgressiveStaticOptimizer && !t5.isReturn) continue;
          t5 = new B(t5.eval(), t5.isReturn);
        }
        if (e2.config.earlyReturnsSkipParsing && (t5.isBreak || t5.isContinue || t5.isReturn)) return r2.push(t5), e2.config.earlyReturnsSkipTokenization || this.findReEntryPoint(e2), new z(r2);
      }
      r2.push(t5);
    } while (e2.match("SEMICOLON") && !e2.match("EOF") && !e2.match("CURLY_RIGHT", false));
    e2.match("SEMICOLON");
    return new z(r2);
  }
};
var q = class extends d {
  constructor(e2) {
    super(), this.name = e2, this.type = "StringExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return true;
  }
  eval() {
    return this.name.substring(1, this.name.length - 1);
  }
  toString() {
    return this.name;
  }
};
var Y = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new q(t4.getText());
  }
};
var D = class extends d {
  constructor(e2, t4) {
    super(), this.name = e2, this.args = t4, this.type = "FunctionExpression";
  }
  get allExpressions() {
    return [this.name, ...this.args];
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.name = t4 : e2 > 0 && (this.args[e2 - 1] = t4);
  }
  setExecutionEnv(e2) {
    this.name.setExecutionEnv(e2);
  }
  get executionEnv() {
    return this.name.executionEnv;
  }
  isStatic() {
    return false;
  }
  eval() {
    const e2 = [];
    let t4 = 0;
    for (; t4 < this.args.length; ) e2.push(this.args[t4++].eval());
    const s2 = this.name.eval();
    if ("function" != typeof s2) throw new Error(this.name.toString() + " is not callable!");
    return s2(...e2);
  }
  toString() {
    let e2 = this.name.toString() + "(";
    for (let t4 = 0; t4 < this.args.length; t4++) e2 += `${this.args[t4].toString()}${t4 + 1 < this.args.length ? "," : ""}`;
    return e2 + ")";
  }
};
var Q = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    const r2 = [];
    if (!t4.setFunctionCall) throw new Error(t4.type + " is not callable!");
    if (t4.setFunctionCall(true), !e2.match("RIGHT_PARENT")) {
      do {
        r2.push(e2.parseExpression());
      } while (e2.match("COMMA"));
      e2.consume("RIGHT_PARENT");
    }
    return new D(t4, r2);
  }
};
var X = class extends d {
  constructor(e2, t4) {
    super(), this.name = e2, this.lookup = t4, this.type = "ArrayAccessExpression";
  }
  get allExpressions() {
    return [this.name, this.lookup];
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.name = t4 : 1 === e2 && (this.lookup = t4);
  }
  isStatic() {
    return false;
  }
  setPointer(e2) {
    this.name.eval()[this.lookup.eval()] = e2;
  }
  eval() {
    return this.name.eval()[this.lookup.eval()];
  }
  toString() {
    return `${this.name.toString()}[${this.lookup.toString()}]`;
  }
};
var j = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    const r2 = e2.parseExpression(this.precedence - 1);
    if (!t4.setPointer) throw new Error(`"${t4.type}" is not an array`);
    if (!e2.match("ARRAY_RIGHT")) throw new Error(`No closing bracket for opening bracket "[${r2.eval()}"`);
    return new X(t4, r2);
  }
};
var W = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    let s2 = e2.parseExpression(this.precedence);
    return e2.config.useOptimizer && e2.config.earlyReturnsSkipTokenization && s2.isReturn ? e2.match("CURLY_RIGHT") : e2.consume("CURLY_RIGHT"), e2.config.keepGroups ? new U(s2, "{}") : s2;
  }
};
var K = class extends d {
  constructor(e2, t4) {
    super(), this.count = e2, this.expression = t4, this.type = "LoopExpression";
  }
  get allExpressions() {
    return [this.count, this.expression];
  }
  get isNoopLoop() {
    return this.count.isStatic() && 0 === this.count.eval();
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.count = t4 : 1 === e2 && (this.expression = t4);
  }
  get isReturn() {
    return !this.isNoopLoop && this.expression.isReturn;
  }
  isStatic() {
    return this.count.isStatic() && this.expression.isStatic();
  }
  eval() {
    const e2 = Number(this.count.eval());
    if (0 === e2) return 0;
    if (Number.isNaN(e2)) throw new Error(`First loop() argument must be of type number, received "${typeof this.count.eval()}"`);
    if (e2 > 1024) throw new Error(`Cannot loop more than 1024x times, received "${e2}"`);
    let t4 = 0;
    for (; t4 < e2; ) {
      t4++;
      const e3 = this.expression.eval();
      if (this.expression.isBreak) break;
      if (!this.expression.isContinue && this.expression.isReturn) return e3;
    }
    return 0;
  }
  toString() {
    return this.isNoopLoop ? "" : `loop(${this.count.toString()},${this.expression.toString()})`;
  }
};
var V = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    e2.consume("LEFT_PARENT");
    const s2 = [];
    if (e2.match("RIGHT_PARENT")) throw new Error("loop() called without arguments");
    do {
      s2.push(e2.parseExpression());
    } while (e2.match("COMMA"));
    if (e2.consume("RIGHT_PARENT"), 2 !== s2.length) throw new Error("There must be exactly two loop() arguments; found " + s2.length);
    return new K(s2[0], s2[1]);
  }
};
var Z = class extends d {
  constructor(e2, t4, s2) {
    if (super(), this.variable = e2, this.arrayExpression = t4, this.expression = s2, this.type = "ForEachExpression", !this.variable.setPointer) throw new Error(`First for_each() argument must be a variable, received "${typeof this.variable.eval()}"`);
  }
  get isReturn() {
    return this.expression.isReturn;
  }
  get allExpressions() {
    return [this.variable, this.arrayExpression, this.expression];
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.variable = t4 : 1 === e2 ? this.arrayExpression = t4 : 2 === e2 && (this.expression = t4);
  }
  isStatic() {
    return this.variable.isStatic() && this.arrayExpression.isStatic() && this.expression.isStatic();
  }
  eval() {
    const e2 = this.arrayExpression.eval();
    if (!Array.isArray(e2)) throw new Error(`Second for_each() argument must be an array, received "${typeof e2}"`);
    let t4 = 0;
    for (; t4 < e2.length; ) {
      this.variable.setPointer?.(e2[t4++]);
      const s2 = this.expression.eval();
      if (this.expression.isBreak) break;
      if (!this.expression.isContinue && this.expression.isReturn) return s2;
    }
    return 0;
  }
  toString() {
    return `for_each(${this.variable.toString()},${this.arrayExpression.toString()},${this.expression.toString()})`;
  }
};
var J = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    e2.consume("LEFT_PARENT");
    const s2 = [];
    if (e2.match("RIGHT_PARENT")) throw new Error("for_each() called without arguments");
    do {
      s2.push(e2.parseExpression());
    } while (e2.match("COMMA"));
    if (e2.consume("RIGHT_PARENT"), 3 !== s2.length) throw new Error("There must be exactly three for_each() arguments; found " + s2.length);
    return new Z(s2[0], s2[1], s2[2]);
  }
};
var ee = class extends d {
  constructor() {
    super(), this.type = "ContinueExpression", this.isContinue = true;
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return false;
  }
  eval() {
    return 0;
  }
  toString() {
    return "continue";
  }
};
var te = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new ee();
  }
};
var se = class extends d {
  constructor() {
    super(), this.type = "BreakExpression", this.isBreak = true;
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return false;
  }
  eval() {
    return 0;
  }
  isString() {
    return "break";
  }
};
var re = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new se();
  }
};
var ie = class extends d {
  constructor(e2) {
    super(), this.value = e2, this.type = "BooleanExpression";
  }
  get allExpressions() {
    return [];
  }
  setExpressionAt() {
  }
  isStatic() {
    return true;
  }
  eval() {
    return this.value;
  }
};
var ne = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4) {
    return new ie("true" === t4.getText());
  }
};
var oe = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    return new S(t4, e2.parseExpression(this.precedence), "==", (e3, t5) => e3.eval() === t5.eval());
  }
};
var ae = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    if (e2.match("EQUALS")) return new S(t4, e2.parseExpression(this.precedence), "!=", (e3, t5) => e3.eval() !== t5.eval());
    throw new Error("! was used as a binary operator");
  }
};
var he = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    if (e2.match("AND")) return new S(t4, e2.parseExpression(this.precedence), "&&", (e3, t5) => e3.eval() && t5.eval());
    throw new Error('"&" not followed by another "&"');
  }
};
var ce = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    if (e2.match("OR")) return new S(t4, e2.parseExpression(this.precedence), "||", (e3, t5) => e3.eval() || t5.eval());
    throw new Error('"|" not followed by another "|"');
  }
};
var ue = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    return e2.match("EQUALS") ? new S(t4, e2.parseExpression(this.precedence), "<=", (e3, t5) => e3.eval() <= t5.eval()) : new S(t4, e2.parseExpression(this.precedence), "<", (e3, t5) => e3.eval() < t5.eval());
  }
};
var pe = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    return e2.match("EQUALS") ? new S(t4, e2.parseExpression(this.precedence), ">=", (e3, t5) => e3.eval() >= t5.eval()) : new S(t4, e2.parseExpression(this.precedence), ">", (e3, t5) => e3.eval() > t5.eval());
  }
};
var le = class extends d {
  constructor(e2, t4, s2) {
    super(), this.leftExpression = e2, this.thenExpression = t4, this.elseExpression = s2, this.type = "TernaryExpression";
  }
  get allExpressions() {
    return this.leftExpression.isStatic() ? [this.leftExpression, this.leftExpression.eval() ? this.thenExpression : this.elseExpression] : [this.leftExpression, this.thenExpression, this.elseExpression];
  }
  setExpressionAt(e2, t4) {
    0 === e2 ? this.leftExpression = t4 : 1 === e2 ? this.thenExpression = t4 : 2 === e2 && (this.elseExpression = t4);
  }
  get isReturn() {
    return void 0 === this.leftResult ? this.thenExpression.isReturn && this.elseExpression.isReturn : this.leftResult ? this.thenExpression.isReturn : this.elseExpression.isReturn;
  }
  get hasReturn() {
    return this.thenExpression.isReturn || this.elseExpression.isReturn;
  }
  get isContinue() {
    return void 0 === this.leftResult ? this.thenExpression.isContinue && this.elseExpression.isContinue : this.leftResult ? this.thenExpression.isContinue : this.elseExpression.isContinue;
  }
  get isBreak() {
    return void 0 === this.leftResult ? this.thenExpression.isBreak && this.elseExpression.isBreak : this.leftResult ? this.thenExpression.isBreak : this.elseExpression.isBreak;
  }
  isStatic() {
    return this.leftExpression.isStatic() && this.thenExpression.isStatic() && this.elseExpression.isStatic();
  }
  eval() {
    return this.leftResult = this.leftExpression.eval(), this.leftResult ? this.thenExpression.eval() : this.elseExpression.eval();
  }
  toString() {
    return this.elseExpression instanceof v ? `${this.leftExpression.toString()}?${this.thenExpression.toString()}` : `${this.leftExpression.toString()}?${this.thenExpression.toString()}:${this.elseExpression.toString()}`;
  }
};
var xe = new class {
  constructor(e2 = 0) {
    this.precedence = e2, this.exprName = "Ternary";
  }
  parse(e2, t4, s2) {
    let r2, i2 = e2.parseExpression(this.precedence - 1);
    return r2 = e2.match("COLON") ? e2.parseExpression(this.precedence - 1) : new v(), e2.config.useOptimizer && t4.isStatic() ? t4.eval() ? i2 : r2 : new le(t4, i2, r2);
  }
}(k.CONDITIONAL);
var Ee = class {
  constructor(e2 = 0) {
    this.precedence = e2;
  }
  parse(e2, t4, s2) {
    return e2.match("QUESTION") ? new S(t4, e2.parseExpression(this.precedence), "??", (e3, t5) => e3.eval() ?? t5.eval()) : xe.parse(e2, t4, s2);
  }
};
var fe = class extends class {
  constructor(e2) {
    this.config = e2, this.prefixParselets = /* @__PURE__ */ new Map(), this.infixParselets = /* @__PURE__ */ new Map(), this.readTokens = [], this.tokenIterator = new r();
  }
  updateConfig(e2) {
    this.config = e2;
  }
  init(e2) {
    this.tokenIterator.init(e2), this.readTokens = [];
  }
  setTokenizer(e2) {
    this.tokenIterator = e2;
  }
  setExecutionEnvironment(e2) {
    this.executionEnv = e2;
  }
  parseExpression(e2 = 0) {
    let t4 = this.consume();
    if ("EOF" === t4.getType()) return new v();
    const s2 = this.prefixParselets.get(t4.getType());
    if (!s2) throw new Error(`Cannot parse ${t4.getType()} expression "${t4.getType()}"`);
    let r2 = s2.parse(this, t4);
    return this.parseInfixExpression(r2, e2);
  }
  parseInfixExpression(e2, t4 = 0) {
    let s2;
    for (; this.getPrecedence() > t4; ) {
      s2 = this.consume();
      let t5 = s2.getType();
      "EQUALS" !== t5 || this.match("EQUALS") || (t5 = "ASSIGN");
      const r2 = this.infixParselets.get(t5);
      if (!r2) throw new Error(`Unknown infix parselet: "${t5}"`);
      e2 = r2.parse(this, e2, s2);
    }
    return e2;
  }
  getPrecedence() {
    const e2 = this.infixParselets.get(this.lookAhead(0).getType());
    return e2?.precedence ?? 0;
  }
  consume(e2) {
    const t4 = this.lookAhead(0);
    if (e2 && t4.getType() !== e2) throw new Error(`Expected token "${e2}" and found "${t4.getType()}"`);
    return this.readTokens.shift(), t4;
  }
  match(e2, t4 = true) {
    return this.lookAhead(0).getType() === e2 && (t4 && this.consume(), true);
  }
  lookAhead(e2) {
    for (; e2 >= this.readTokens.length; ) this.readTokens.push(this.tokenIterator.next());
    return this.readTokens[e2];
  }
  registerInfix(e2, t4) {
    this.infixParselets.set(e2, t4);
  }
  registerPrefix(e2, t4) {
    this.prefixParselets.set(e2, t4);
  }
  getInfix(e2) {
    return this.infixParselets.get(e2);
  }
  getPrefix(e2) {
    return this.prefixParselets.get(e2);
  }
} {
  constructor(e2) {
    super(e2), this.registerPrefix("NAME", new _()), this.registerPrefix("STRING", new Y()), this.registerPrefix("NUMBER", new L()), this.registerPrefix("TRUE", new ne(k.PREFIX)), this.registerPrefix("FALSE", new ne(k.PREFIX)), this.registerPrefix("RETURN", new G()), this.registerPrefix("CONTINUE", new te()), this.registerPrefix("BREAK", new re()), this.registerPrefix("LOOP", new V()), this.registerPrefix("FOR_EACH", new J()), this.registerInfix("QUESTION", new Ee(k.CONDITIONAL)), this.registerPrefix("LEFT_PARENT", new $()), this.registerInfix("LEFT_PARENT", new Q(k.FUNCTION)), this.registerInfix("ARRAY_LEFT", new j(k.ARRAY_ACCESS)), this.registerPrefix("CURLY_LEFT", new W(k.SCOPE)), this.registerInfix("SEMICOLON", new H(k.STATEMENT)), this.registerPrefix("MINUS", new P(k.PREFIX)), this.registerPrefix("BANG", new P(k.PREFIX)), this.registerInfix("PLUS", new N(k.SUM)), this.registerInfix("MINUS", new N(k.SUM)), this.registerInfix("ASTERISK", new N(k.PRODUCT)), this.registerInfix("SLASH", new N(k.PRODUCT)), this.registerInfix("EQUALS", new oe(k.EQUALS_COMPARE)), this.registerInfix("BANG", new ae(k.EQUALS_COMPARE)), this.registerInfix("GREATER", new pe(k.COMPARE)), this.registerInfix("SMALLER", new ue(k.COMPARE)), this.registerInfix("AND", new he(k.AND)), this.registerInfix("OR", new ce(k.OR)), this.registerInfix("ASSIGN", new N(k.ASSIGNMENT));
  }
};
var we = Object.freeze({ __proto__: null, ArrayAccessExpression: X, BooleanExpression: ie, BreakExpression: se, ContinueExpression: ee, ForEachExpression: Z, FunctionExpression: D, GenericOperatorExpression: S, GroupExpression: U, LoopExpression: K, NameExpression: O, NumberExpression: I, PostfixExpression: class extends d {
  constructor(e2, t4) {
    super(), this.expression = e2, this.tokenType = t4, this.type = "PostfixExpression";
  }
  get allExpressions() {
    return [this.expression];
  }
  setExpressionAt(e2, t4) {
    this.expression = t4;
  }
  isStatic() {
    return this.expression.isStatic();
  }
  eval() {
    this.tokenType;
  }
}, PrefixExpression: b, ReturnExpression: F, StatementExpression: z, StaticExpression: B, StringExpression: q, TernaryExpression: le, VoidExpression: v });
var de = class {
  constructor(e2 = {}, t4 = {}) {
    this.config = t4, this.expressionCache = {}, this.totalCacheEntries = 0, void 0 === t4.useOptimizer && (this.config.useOptimizer = true), void 0 === t4.useCache && (this.config.useCache = true), void 0 === t4.earlyReturnsSkipParsing && (this.config.earlyReturnsSkipParsing = true), void 0 === t4.earlyReturnsSkipTokenization && (this.config.earlyReturnsSkipTokenization = true), void 0 === t4.convertUndefined && (this.config.convertUndefined = false), this.parser = new fe({ ...this.config, tokenizer: void 0 }), this.updateExecutionEnv(e2, t4.assumeFlatEnvironment);
  }
  updateConfig(e2) {
    (e2 = Object.assign(this.config, e2)).tokenizer && this.parser.setTokenizer(e2.tokenizer), this.parser.updateConfig({ ...this.config, tokenizer: void 0 }), this.executionEnvironment.updateConfig(e2);
  }
  updateExecutionEnv(e2, t4 = false) {
    this.executionEnvironment = new m(e2, { useRadians: this.config.useRadians, convertUndefined: this.config.convertUndefined, isFlat: t4, variableHandler: this.config.variableHandler }), this.parser.setExecutionEnvironment(this.executionEnvironment);
  }
  clearCache() {
    this.expressionCache = {}, this.totalCacheEntries = 0;
  }
  execute(e2) {
    this.parser.setExecutionEnvironment(this.executionEnvironment);
    const t4 = this.parse(e2).eval();
    return void 0 === t4 ? 0 : "boolean" == typeof t4 ? Number(t4) : t4;
  }
  executeAndCatch(e2) {
    try {
      return this.execute(e2);
    } catch {
      return 0;
    }
  }
  parse(e2) {
    if (this.config.useCache ?? 1) {
      const t5 = this.expressionCache[e2];
      if (t5) return t5;
    }
    this.parser.init(e2);
    let t4 = this.parser.parseExpression();
    return (this.config.useOptimizer ?? 1) && t4.isStatic() && (t4 = new B(t4.eval())), (this.config.useCache ?? 1) && (this.totalCacheEntries > (this.config.maxCacheSize || 256) && this.clearCache(), this.expressionCache[e2] = t4, this.totalCacheEntries++), t4;
  }
  resolveStatic(e2) {
    return e2 = (e2 = e2.walk((e3) => {
      if (!(e3 instanceof q)) return e3.isStatic() ? new B(e3.eval()) : void 0;
    })).walk((e3) => {
      if (e3 instanceof S) switch (e3.operator) {
        case "+":
        case "-": {
          const t4 = e3.allExpressions.find((e4) => e4.isStatic() && 0 === e4.eval());
          if (t4) return e3.allExpressions.find((e4) => e4 !== t4);
          break;
        }
        case "*":
          if (e3.allExpressions.find((e4) => e4.isStatic() && 0 === e4.eval())) return new B(0);
        case "*":
        case "/": {
          const t4 = e3.allExpressions.find((e4) => e4.isStatic() && 1 === e4.eval());
          if (t4) return e3.allExpressions.find((e4) => e4 !== t4);
          break;
        }
      }
    });
  }
  minimize(e2) {
    e2 = this.resolveStatic(e2);
    const t4 = /* @__PURE__ */ new Map([["query.", "q."], ["variable.", "v."], ["context.", "c."], ["temp.", "t."]]);
    e2 = e2.walk((e3) => {
      if (e3 instanceof O) {
        const s3 = e3.toString();
        for (const [r2, i2] of t4) s3.startsWith(r2) && e3.setName(s3.replace(r2, i2));
        return e3;
      }
    });
    const s2 = /* @__PURE__ */ new Map();
    return e2 = e2.walk((e3) => {
      if (e3 instanceof O) {
        const t5 = e3.toString();
        if (!t5.startsWith("v.") && !t5.startsWith("t.")) return;
        if (s2.has(t5)) e3.setName(s2.get(t5));
        else {
          const r2 = "v.v" + s2.size;
          s2.set(t5, r2), e3.setName(r2);
        }
        return e3;
      }
    });
  }
  getParser() {
    return this.parser;
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/molang.ts
var MolangUtils = class _MolangUtils {
  /**
   * Executes molang synchronously using the context of the broader block.
   * @param {Block} block
   * @param {string} expression
   * @returns {unknown}
   */
  static block(block, expression, env = {}) {
    const dim = block.dimension;
    let defaultEnv = {
      query: {
        cardinal_facing: "down",
        cardinal_facing_2d: "north",
        cardinal_player_facing: "down",
        block_state(stateName) {
          return block.permutation.getState(stateName);
        },
        has_block_state(stateName) {
          return block.permutation.getState(stateName) !== void 0;
        },
        all_tags(...tags) {
          return tags.every((tag) => block.hasTag(tag));
        },
        any_tag(...tags) {
          return tags.some((tag) => block.hasTag(tag));
        },
        block_has_all_tags(x2, y2, z2, ...tags) {
          const blk = dim.getBlock({ x: x2, y: y2, z: z2 });
          if (!blk) return false;
          return tags.every((tag) => blk.hasTag(tag));
        },
        block_has_any_tag(x2, y2, z2, ...tags) {
          const blk = dim.getBlock({ x: x2, y: y2, z: z2 });
          if (!blk) return false;
          return tags.some((tag) => blk.hasTag(tag));
        },
        block_neighbor_has_all_tags(x2, y2, z2, ...tags) {
          const blk = block.offset({ x: x2, y: y2, z: z2 });
          if (!blk) return false;
          return tags.every((tag) => block.hasTag(tag));
        },
        block_neighbor_has_any_tag(x2, y2, z2, ...tags) {
          const blk = block.offset({ x: x2, y: y2, z: z2 });
          if (!blk) return false;
          return tags.some((tag) => block.hasTag(tag));
        }
      },
      variable: {},
      context: {}
    };
    defaultEnv = deepMerge(defaultEnv, env);
    _MolangUtils.commonEnv(defaultEnv, dim);
    const molang = new de(defaultEnv, { useCache: true });
    return molang.execute(expression);
  }
  /**
   * Executes molang synchronously using the context of the broader item.
   * @param {ItemStack} itemStack
   * @param {string} expression
   * @returns {unknown}
   */
  static item(itemStack, expression, env = {}) {
    let defaultEnv = {
      query: {
        max_durability: 0,
        remaining_durability: 0,
        is_cooldown_category(name) {
          const cooldown = itemStack.getComponent("cooldown");
          if (!cooldown) return false;
          return cooldown.cooldownCategory === name;
        },
        all_tags(...tags) {
          return tags.every((tag) => itemStack.hasTag(tag));
        },
        any_tag(...tags) {
          return tags.some((tag) => itemStack.hasTag(tag));
        }
      },
      variable: {},
      context: {}
    };
    const durability = itemStack.getComponent("durability");
    if (durability) {
      defaultEnv.query.max_durability = durability.maxDurability;
      defaultEnv.query.remaining_durability = durability.maxDurability - durability.damage;
    }
    defaultEnv = deepMerge(defaultEnv, env);
    _MolangUtils.commonEnv(defaultEnv);
    const molang = new de(defaultEnv, { useCache: true });
    return molang.execute(expression);
  }
  /**
   * Executes molang synchronously using the context of the broader entity.
   * @param {Entity} entity
   * @param {string} expression
   * @returns {unknown}
   */
  static entity(entity, expression, env = {}) {
    const dim = entity.dimension;
    let defaultEnv = {
      query: {
        target_x_rotation: entity.getRotation().x,
        target_y_rotation: entity.getRotation().y,
        is_on_ground: entity.isOnGround,
        is_sleeping: entity.isSleeping,
        is_in_water: entity.isInWater,
        is_sneaking: entity.isSneaking,
        is_sprinting: entity.isSprinting,
        is_swimming: entity.isSwimming,
        mark_variant: 0,
        variant: 0,
        skin_id: 0,
        max_health: 0,
        model_scale: 1,
        main_hand_item_max_duration: 0,
        has_collision: false,
        ground_speed: 0,
        has_head_gear: false,
        has_owner: false,
        has_player_rider: false,
        has_rider: false,
        heath: 0,
        is_baby: false,
        is_charged: false,
        is_chested: false,
        is_fire_immune: false,
        is_ignited: false,
        is_illager_captain: false,
        is_leashed: false,
        is_onfire: false,
        is_saddled: false,
        is_shaking: false,
        is_sheared: false,
        is_stackable: false,
        is_stunned: false,
        is_tamed: false,
        on_fire_time: 0,
        scoreboard(objectiveName) {
          return world7.scoreboard.getObjective(objectiveName)?.getScore(entity) ?? 0;
        },
        equipped_item_all_tags(slotName, ...tags) {
          const equ2 = entity.getComponent("equippable");
          const stack = equ2?.getEquipment(slotName);
          if (!stack) return false;
          return tags.every((tag) => stack.hasTag(tag));
        },
        equipped_item_any_tag(slotName, ...tags) {
          const equ2 = entity.getComponent("equippable");
          const stack = equ2?.getEquipment(slotName);
          if (!stack) return false;
          return tags.some((tag) => stack.hasTag(tag));
        },
        graphics_mode_is_any(...modes) {
          return false;
        },
        has_any_family(...families) {
          return families.some((fam) => entity.matches({ families: [fam] }));
        },
        has_property(property) {
          return entity.getProperty(property) !== void 0;
        },
        property(property) {
          return entity.getProperty(property);
        },
        is_item_equipped(slot, name) {
          if (slot === "main_hand") slot = 0;
          if (slot === "off_hand") slot = 1;
          const equ2 = entity.getComponent("equippable");
          if (!equ2) return false;
          switch (slot) {
            case 0:
              return equ2.getEquipment(EquipmentSlot.Mainhand)?.matches(name) ?? false;
            case 1:
              return equ2.getEquipment(EquipmentSlot.Offhand)?.matches(name) ?? false;
          }
          return false;
        },
        is_name_any(...names) {
          return names.some((name) => entity.typeId === name);
        },
        is_owner_identifier_any(...identifiers) {
          const projectile2 = entity.getComponent("projectile");
          const tameable2 = entity.getComponent("tameable");
          return identifiers.some((id) => {
            if (projectile2) {
              return projectile2.owner?.matches({ type: id }) ?? false;
            }
            if (tameable2) {
              return tameable2.tamedToPlayer?.matches({ type: id }) ?? false;
            }
            return false;
          });
        },
        position(axis) {
          const pos = entity.location;
          switch (axis) {
            case 0:
              return pos.x;
            case 1:
              return pos.y;
            case 2:
              return pos.z;
          }
          return pos;
        }
      },
      variable: {
        is_holding_left: false,
        is_holding_right: false,
        is_holding_spyglass: false,
        is_sneaking: entity.isSneaking,
        player_x_rotation: 0,
        player_y_rotation: 0
      },
      context: {}
    };
    const equ = entity.getComponent("equippable");
    if (equ) {
      const right = equ.getEquipment(EquipmentSlot.Mainhand);
      defaultEnv.variable.is_holding_right = right !== void 0;
      if (right) {
        const durability = right.getComponent("durability");
        defaultEnv.query.main_hand_item_max_duration = durability?.maxDurability ?? 0;
        if (right.matches("spyglass")) {
          defaultEnv.variable.is_holding_spyglass = true;
        }
      }
      const left = equ.getEquipment(EquipmentSlot.Offhand);
      defaultEnv.variable.is_holding_left = left !== void 0;
      if (left) {
        if (left.matches("spyglass")) {
          defaultEnv.variable.is_holding_spyglass = true;
        }
      }
      const head = equ.getEquipment(EquipmentSlot.Head);
      defaultEnv.query.has_head_gear = head !== void 0;
    }
    const projectile = entity.getComponent("projectile");
    if (projectile) {
      defaultEnv.query.has_owner = projectile.owner !== void 0;
    }
    const tameable = entity.getComponent("tameable");
    if (tameable) {
      defaultEnv.query.has_owner = tameable.tamedToPlayer !== void 0;
    }
    const rideable = entity.getComponent("rideable");
    if (rideable) {
      defaultEnv.query.has_rider = rideable.getRiders().length !== 0;
      defaultEnv.query.has_player_rider = rideable.getRiders().some((entity2) => entity2 instanceof Player4);
    }
    const mov = entity.getComponent("movement");
    if (mov) {
      defaultEnv.query.ground_speed = mov.currentValue;
    }
    const health = entity.getComponent("health");
    if (health) {
      defaultEnv.query.heath = health.currentValue;
      defaultEnv.query.max_health = health.effectiveMax;
    }
    const leashable = entity.getComponent("leashable");
    if (leashable) {
      defaultEnv.query.is_leashed = leashable.isLeashed;
    }
    const onfire = entity.getComponent("onfire");
    if (onfire) {
      defaultEnv.query.is_onfire = onfire.onFireTicksRemaining > 0;
      defaultEnv.query.on_fire_time = onfire.onFireTicksRemaining;
    }
    defaultEnv.query.mark_variant = entity.getComponent("mark_variant")?.value ?? 0;
    defaultEnv.query.variant = entity.getComponent("variant")?.value ?? 0;
    defaultEnv.query.skin_id = entity.getComponent("skin_id")?.value ?? 0;
    defaultEnv.query.model_scale = entity.getComponent("scale")?.value ?? 0;
    defaultEnv.query.is_baby = entity.getComponent("is_baby") !== void 0;
    defaultEnv.query.is_charged = entity.getComponent("is_charged") !== void 0;
    defaultEnv.query.is_chested = entity.getComponent("is_chested") !== void 0;
    defaultEnv.query.is_ignited = entity.getComponent("is_ignited") !== void 0;
    defaultEnv.query.is_illager_captain = entity.getComponent("is_illager_captain") !== void 0;
    defaultEnv.query.is_fire_immune = entity.getComponent("fire_immune") !== void 0;
    defaultEnv.query.is_saddled = entity.getComponent("is_saddled") !== void 0;
    defaultEnv.query.is_shaking = entity.getComponent("is_shaking") !== void 0;
    defaultEnv.query.is_sheared = entity.getComponent("is_sheared") !== void 0;
    defaultEnv.query.is_stackable = entity.getComponent("is_stackable") !== void 0;
    defaultEnv.query.is_stunned = entity.getComponent("is_stunned") !== void 0;
    defaultEnv.query.is_tamed = entity.getComponent("is_tamed") !== void 0;
    if (entity instanceof Player4) _MolangUtils.player(defaultEnv, entity);
    defaultEnv = deepMerge(defaultEnv, env);
    _MolangUtils.commonEnv(defaultEnv, dim);
    const molang = new de(defaultEnv, { useCache: true });
    return molang.execute(expression);
  }
  static player(env, player) {
    if (!env.query) env.query = {};
    if (!env.variable) env.variable = {};
    env.query.is_spectator = player.getGameMode() === GameMode.Spectator;
    env.query.is_jumping = player.isJumping;
    env.query.is_emoting = player.isEmoting;
    env.variable.player_x_rotation = player.getRotation().x;
    env.variable.player_y_rotation = player.getRotation().y;
    env.query.client_max_render_distance = player.clientSystemInfo.maxRenderDistance;
    env.query.client_memory_tier = player.clientSystemInfo.memoryTier.toString();
    env.query.player_level = player.level;
    env.query.graphics_mode_is_any = (...modes) => {
      return modes.some((mode) => mode === player.graphicsMode);
    };
    env.query.is_selected_item = (item) => {
      const equ = player.getComponent("equippable");
      if (!equ) return false;
      return equ.getEquipment(EquipmentSlot.Mainhand)?.matches(item) ?? false;
    };
  }
  static commonEnv(env, dim) {
    if (!env.query) env.query = {};
    env.query.day = world7.getDay();
    env.query.time_of_day = (world7.getTimeOfDay() * 0.25 / 2400 % 1 + 1) % 1;
    if (!dim) return;
    env.query.heightmap = (x2, z2) => {
      const blk = dim.getTopmostBlock({ x: x2, z: z2 });
      return blk?.y ?? 0;
    };
    env.query.log = (msg) => {
      console.info(msg);
    };
    env.query.moon_brightness = 0;
    env.query.moon_phase = world7.getMoonPhase();
    env.query.server_memory_tier = system4.serverSystemInfo.memoryTier;
    env.query.time_stamp = (/* @__PURE__ */ new Date()).getTime();
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/misc.ts
import { system as system6, DimensionTypes, world as world8 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/cache.ts
import { MemoryTier, system as system5 } from "@minecraft/server";
var LRUCache = class {
  cache;
  options;
  /**
   * Creates a new LRUCache instance.
   * @param {LRUCacheOptions} options
   */
  constructor(options) {
    this.cache = /* @__PURE__ */ new Map();
    this.options = options ?? {};
    if (this.options.maxSize === void 0) {
      this.options.maxSize = this.#defaultSize();
    }
    if (this.options.maxSize <= 0) {
      throw new Error("Cache size must be greater than 0");
    }
  }
  #defaultSize() {
    switch (system5.serverSystemInfo.memoryTier) {
      case MemoryTier.SuperLow:
        return 128;
      case MemoryTier.Low:
        return 256;
      case MemoryTier.Mid:
        return 512;
      case MemoryTier.High:
        return 1024;
      case MemoryTier.SuperHigh:
        return 2048;
      default:
        return 512;
    }
  }
  /**
   * Retrieves a value from the cache by its key.
   * If the key exists, it is marked as recently used.
   * @param key The key to look up.
   * @returns The cached value, or undefined if the key is not in the cache.
   */
  get(key) {
    if (!this.cache.has(key)) {
      return void 0;
    }
    const value = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }
  /**
   * Adds a key-value pair to the cache.
   * If the cache exceeds the maximum size, the least recently used entry is removed.
   * @param key The key to store the value under.
   * @param value The value to store.
   */
  set(key, value) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= (this.options.maxSize ?? this.#defaultSize())) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) this.cache.delete(oldestKey);
    }
    this.cache.set(key, value);
    return value;
  }
  /**
   * Checks if a key exists in the cache.
   * @param key The key to check.
   * @returns True if the key exists, false otherwise.
   */
  has(key) {
    return this.cache.has(key);
  }
  /**
   * Removes a key-value pair from the cache.
   * @param key The key to remove.
   */
  delete(key) {
    this.cache.delete(key);
  }
  /**
   * Clears all entries from the cache.
   */
  clear() {
    this.cache.clear();
  }
  /**
   * Gets the current size of the cache.
   * @returns The number of entries in the cache.
   */
  size() {
    return this.cache.size;
  }
  /**
   * Get or create a new entry
   * @param key
   * @param compute
   * @returns
   */
  getOrCompute(key, compute) {
    const value = this.get(key);
    if (!value) {
      return this.set(key, compute(key));
    }
    if (this.options.debug) console.log(`${key} from cache`);
    return value;
  }
};

// node_modules/@lpsmods/mc-utils/src/utils/misc.ts
var soundCache = new LRUCache();
function getInteractSound(block, defaultSound = "dig.stone") {
  if (!block) return "dig.stone";
  const key = block.typeId;
  if (soundCache.has(key)) return soundCache.get(key) ?? defaultSound;
  if (key.includes("dirt") || key.includes("farmland") || key.includes("gravel"))
    return soundCache.set(key, "dig.gravel");
  if (key.includes("crimson") || key.includes("warped")) return soundCache.set(key, "dig.stem");
  if (key.includes("cherry")) return soundCache.set(key, "break.cherry_wood");
  return soundCache.set(key, defaultSound);
}
function forAllDimensions(callback) {
  for (const dimType of DimensionTypes.getAll()) {
    callback(world8.getDimension(dimType.typeId));
  }
}
function offsetVolume(offset, callback) {
  for (let x2 = -offset.x; x2 < offset.x + 1; x2++) {
    for (let y2 = -offset.y; y2 < offset.y + 1; y2++) {
      for (let z2 = -offset.z; z2 < offset.z + 1; z2++) {
        const result = callback({ x: x2, y: y2, z: z2 });
        if (result !== void 0) return result;
      }
    }
  }
}
function deepCopy(input, seen = /* @__PURE__ */ new WeakMap()) {
  if (input === null || typeof input !== "object") {
    return input;
  }
  if (typeof input === "function") {
    return input;
  }
  if (seen.has(input)) {
    return seen.get(input);
  }
  if (Array.isArray(input)) {
    const copy2 = [];
    seen.set(input, copy2);
    for (const item of input) {
      copy2.push(deepCopy(item, seen));
    }
    return copy2;
  }
  const copy = {};
  seen.set(input, copy);
  for (const [key, value] of Object.entries(input)) {
    copy[key] = deepCopy(value, seen);
  }
  return copy;
}
function differenceArray(a2, b2) {
  const setA = new Set(a2);
  const setB = new Set(b2);
  const result = [];
  for (const item of setA) {
    if (!setB.has(item)) {
      result.push(item);
    }
  }
  for (const item of setB) {
    if (!setA.has(item)) {
      result.push(item);
    }
  }
  return result;
}
function removeItems(source, itemsToRemove) {
  const toRemove = new Set(itemsToRemove);
  return source.filter((item) => !toRemove.has(item));
}
function deepMerge(obj1, obj2) {
  const result = { ...obj1 };
  for (const key in obj2) {
    if (Object.prototype.hasOwnProperty.call(obj2, key)) {
      if (typeof obj2[key] === "object" && obj2[key] !== null && !Array.isArray(obj2[key]) && typeof result[key] === "object" && result[key] !== null && !Array.isArray(result[key])) {
        result[key] = deepMerge(result[key], obj2[key]);
      } else {
        result[key] = obj2[key];
      }
    }
  }
  return result;
}

// node_modules/@lpsmods/mc-utils/src/settings.ts
var Settings = class {
  id;
  store;
  options;
  descriptor = /* @__PURE__ */ new Map();
  constructor(id, options) {
    this.id = id;
    this.options = options ?? {};
    this.store = new VersionedDataStorage(this.id, this.options.formatVersion ?? 1, this.options.core);
  }
  getDescriptor() {
    return this.descriptor;
  }
  defineProperty(name, descriptor) {
    this.getDescriptor().set(name, descriptor);
  }
  get(name, fallbackValue) {
    const prop = this.getDescriptor().get(name);
    if (!prop) throw new Error(`${name} is not defined!`);
    return this.store.get(name) ?? fallbackValue ?? prop.value;
  }
  set(name, value) {
    if (!this.getDescriptor().has(name)) {
      throw new Error(`${name} is not defined!`);
    }
    return this.store.set(name, value);
  }
  reset() {
    for (const k2 of this.getDescriptor().keys()) {
      this.set(k2);
    }
  }
  update(data) {
    for (const [k2, v2] of Object.entries(data)) {
      this.set(k2, v2);
    }
  }
  show(player, title) {
    const form = {
      title: title ?? "World Settings",
      options: {},
      onSubmit: (event) => {
        this.update(event.formResult);
      }
    };
    for (const [k2, prop] of this.getDescriptor().entries()) {
      const label = prop.title ?? k2;
      const tooltip = prop.description;
      switch (prop.type) {
        case "string":
          form.options[k2] = { label, tooltip, type: "text", value: this.get(k2) };
          if (prop.values) {
            form.options[k2].type = "dropdown";
            form.options[k2].options = prop.values;
          }
          break;
        case "number":
          form.options[k2] = {
            label,
            tooltip,
            type: "slider",
            value: this.get(k2),
            min: prop.min,
            max: prop.max
          };
          break;
        case "boolean":
          form.options[k2] = { label, tooltip, type: "toggle", value: this.get(k2) };
          break;
        case "Vector3":
          form.options[k2] = { label, tooltip, type: "text", value: JSON.stringify(this.get(k2)) };
          break;
        default:
          throw new Error(`Unsupported type ${prop.type}`);
      }
    }
    const ui = new ModalFormHandler(form);
    ui.show(player);
  }
};
var PlayerSettings = class _PlayerSettings extends Settings {
  player;
  static descriptor = /* @__PURE__ */ new Map();
  constructor(player, formatVersion, id) {
    super(id ?? "mcutils:settings", { formatVersion, core: player });
    this.player = player;
  }
  getDescriptor() {
    return _PlayerSettings.descriptor;
  }
  static defineProperty(name, descriptor) {
    this.descriptor.set(name, descriptor);
  }
  show(arg1, arg2) {
    if (typeof arg1 === "string" || arg1 === void 0) {
      super.show(this.player, arg2);
    } else {
      super.show(arg1, arg2);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/ui/paged_action_form.ts
var PagedActionFormEvent = class _PagedActionFormEvent {
  constructor(player, pages, pageId, options, ctx) {
    this.player = player;
    this.pages = pages;
    this.ctx = ctx;
    this.options = options ?? { default: "home" };
    this.pageId = pageId ?? options?.default ?? "home";
  }
  player;
  pages;
  pageId;
  options;
  ctx;
  static withPage(event, pageId) {
    return new _PagedActionFormEvent(event.player, event.pages, pageId, event.options);
  }
  /**
   * Context for ActionFormEvent
   * @returns {any}
   */
  getContext() {
    return {
      pageId: this.pageId,
      pages: this.pages,
      options: this.options
    };
  }
};
var CustomPage = class {
  static pageId;
  ui;
};
var PlayerSettingsPage = class extends CustomPage {
  static pageId = "mcutils:player_settings";
  getButton(event) {
    return {
      label: "Player Settings",
      icon: "textures/ui/icon_setting.png",
      onClick: (clickEvent) => {
        this.show(event);
      }
    };
  }
  show(event) {
    new PlayerSettings(event.player).show();
  }
};
var PagedActionForm = class _PagedActionForm {
  static lastId = 0;
  id;
  options;
  pages;
  customPages = /* @__PURE__ */ new Map();
  constructor(pages, options) {
    this.options = options ?? {};
    this.id = this.options.id ?? `mcutils:${_PagedActionForm.lastId++}`;
    this.pages = pages ?? {};
    this.customPage(PlayerSettingsPage.pageId, new PlayerSettingsPage());
  }
  convert(page, event) {
    const form = page;
    if (page.title) {
      form.title = this.t(event, page.title);
    }
    if (page.body) {
      form.body = this.t(event, page.body);
    }
    if (page.buttons && form.buttons) {
      for (let i2 = 0; i2 < page.buttons.length; i2++) {
        let btn = page.buttons[i2];
        if (typeof btn === "string") {
          const page2 = event.pages[btn];
          const customPage = this.customPages.get(btn);
          if (customPage) {
            form.buttons[i2] = customPage.getButton(event);
            continue;
          }
          form.buttons[i2] = { label: "UNKNOWN" };
          if (!page2) {
            console.warn(`Page not found for "${btn}"`);
            continue;
          }
          form.buttons[i2].icon = page2.icon;
          btn = { label: page2.title ?? "", pageId: btn };
        }
        form.buttons[i2].label = this.t(event, btn.label);
        if (!btn.pageId) continue;
        form.buttons[i2].onClick = (w) => {
          this.show(event.player, btn.pageId, event.options, event.ctx);
        };
      }
    }
    return form;
  }
  t(event, key) {
    return key;
  }
  /**
   * Add a custom page.
   * @param {string} identifier
   * @param {CustomPage} page
   * @returns {PagedActionForm}
   */
  customPage(identifier, page) {
    this.customPages.set(identifier, page);
    page.ui = this;
    return this;
  }
  isDefault(event) {
    return (event.options.default ?? "home") === event.pageId;
  }
  getHistory(player) {
    return DataUtils.getDynamicProperty(player, `${this.id}.history`, []);
  }
  setHistory(player, history) {
    DataUtils.setDynamicProperty(player, `${this.id}.history`, history);
  }
  clearHistory(player) {
    this.setHistory(player, []);
  }
  isPageValid(pageId) {
    try {
      this.validatePage(pageId);
      return true;
    } catch (e2) {
    }
    return false;
  }
  hasPage(pageId) {
    return this.customPages.has(pageId) || this.pages[pageId] !== void 0;
  }
  validatePage(pageId, ignorePages = []) {
    if (this.customPages.has(pageId)) return;
    const page = this.pages[pageId];
    const errors = [];
    ValidationError.optionalValueError(errors, `${pageId}.title`, page.title, ["string"]);
    ValidationError.optionalValueError(errors, `${pageId}.body`, page.body, ["string"]);
    ValidationError.optionalValueError(errors, `${pageId}.icon`, page.icon, ["string"]);
    ValidationError.optionalValueError(errors, `${pageId}.hidden`, page.hidden, ["boolean"]);
    ValidationError.optionalValueError(errors, `${pageId}.onShow`, page.onShow, ["function"]);
    ValidationError.optionalValueError(errors, `${pageId}.onClose`, page.onClose, ["function"]);
    if (page.keywords) {
      for (let i2 = 0; i2 < page.keywords.length; i2++) {
        const keyword = page.keywords[i2];
        ValidationError.valueError(errors, `${pageId}.keywords[${i2}]`, keyword, ["string"]);
      }
    }
    if (page.buttons) {
      for (let i2 = 0; i2 < page.buttons.length; i2++) {
        const button = page.buttons[i2];
        const bool = ValidationError.valueError(errors, `${pageId}.buttons[${i2}]`, button, ["string", "object"]);
        if (!bool) continue;
        if (typeof button === "string") {
          if (ignorePages.includes(button)) continue;
          if (!this.hasPage(button)) {
            errors.push({
              path: `${pageId}.buttons[${i2}]`,
              message: `Page "${button}" does not exist.`
            });
            continue;
          }
          ignorePages.push(button);
          this.validatePage(button, ignorePages);
          continue;
        }
        if (typeof button === "object") {
          ValidationError.valueError(errors, `${pageId}.buttons[${i2}].label`, button.label, ["string"]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].icon`, button.icon, ["string"]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].pageId`, button.pageId, ["string"]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].top_margin`, button.top_margin, [
            "number"
          ]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].bottom_margin`, button.bottom_margin, [
            "number"
          ]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].top_divider`, button.top_divider, [
            "boolean"
          ]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].bottom_divider`, button.bottom_divider, [
            "boolean"
          ]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].onClick`, button.onClick, ["function"]);
          ValidationError.optionalValueError(errors, `${pageId}.buttons[${i2}].condition`, button.condition, [
            "function"
          ]);
          if (button.pageId && !ignorePages.includes(button.pageId)) {
            if (!this.hasPage(button.pageId)) {
              errors.push({
                path: `${pageId}.buttons[${i2}].pageId`,
                message: `Page "${button.pageId}" does not exist.`
              });
              continue;
            }
            ignorePages.push(button.pageId);
            this.validatePage(button.pageId, ignorePages);
          }
        }
      }
    }
    if (errors.length > 0) {
      throw new ValidationError(errors).toString();
    }
  }
  show(player, pageId, options, ctx) {
    ctx = ctx === void 0 ? {} : ctx;
    ctx.handler = this;
    const event = new PagedActionFormEvent(player, this.pages, pageId, options, ctx);
    const history = this.getHistory(player);
    history.push(event.pageId);
    this.setHistory(player, history);
    if (this.customPages.has(event.pageId)) return this.customPages.get(event.pageId)?.show(event);
    const page = deepCopy(this.pages[event.pageId]);
    const form = this.convert(page, event);
    if (event.options.back_button != void 0 && !this.isDefault(event)) {
      if (!form.buttons) form.buttons = [];
      form.buttons.push({
        label: event.options.back_button.label ?? "#gui.back",
        icon: event.options.back_button.icon ?? "textures/ui/arrowLeft.png",
        top_margin: event.options.back_button.top_margin ?? 1,
        bottom_margin: event.options.back_button.bottom_margin,
        top_divider: event.options.back_button.top_divider ?? true,
        bottom_divider: event.options.back_button.bottom_divider,
        onClick: () => {
          const end = history.length - 2;
          const page2 = history[end];
          history.splice(end, 2);
          this.setHistory(player, history);
          this.show(player, page2, options, ctx);
        }
      });
    }
    const ui = new ActionFormHandler(form);
    ui.show(event.player, { ...event.getContext(), ...ctx });
  }
  showAll(pageId, options, ctx) {
    world9.getAllPlayers().forEach((player) => this.show(player, pageId, options, ctx));
  }
};

// node_modules/@lpsmods/mc-utils/src/ui/progress_bar.ts
import { world as world10 } from "@minecraft/server";
var ProgressBarColors = class {
  static Aqua = {
    fill: "\xA7b" /* Aqua */,
    empty: "\xA73" /* DarkAqua */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Blue = {
    fill: "\xA79" /* Blue */,
    empty: "\xA71" /* DarkBlue */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Green = {
    fill: "\xA7a" /* Green */,
    empty: "\xA72" /* DarkGreen */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Purple = {
    fill: "\xA7d" /* LightPurple */,
    empty: "\xA75" /* DarkPurple */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Red = {
    fill: "\xA7c" /* Red */,
    empty: "\xA74" /* DarkRed */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static White = {
    fill: "\xA7f" /* White */,
    empty: "\xA77" /* Gray */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Yellow = {
    fill: "\xA7e" /* Yellow */,
    empty: "\xA76" /* Gold */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Gray = {
    fill: "\xA77" /* Gray */,
    empty: "\xA78" /* DarkGray */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
  static Orange = {
    fill: "\xA7v" /* MaterialResin */,
    empty: "\xA7n" /* MaterialCopper */,
    leftCap: "\xA7l",
    rightCap: "\xA7l"
  };
};

// node_modules/@lpsmods/mc-utils/src/data/utils.ts
var DataUtils = class _DataUtils {
  static getDynamicProperty(object2, name, defaultValue) {
    const value = object2.getDynamicProperty(name);
    if (value === void 0) return defaultValue;
    return this.load(value);
  }
  static setDynamicProperty(object2, name, value) {
    object2.setDynamicProperty(name, this.dump(value));
  }
  static getDynamicProperties(object2) {
    const props = {};
    for (const key of object2.getDynamicPropertyIds()) {
      const value = this.getDynamicProperty(object2, key);
      props[key] = value;
    }
    return props;
  }
  static decrementDynamicProperty(object2, name, defaultValue) {
    let value = this.getDynamicProperty(object2, name);
    if (value === void 0) value = defaultValue ?? 0;
    if (typeof value !== "number") throw new TypeError(`Expected a number but got ${typeof value}`);
    value--;
    this.setDynamicProperty(object2, name, value);
    return value;
  }
  static incrementDynamicProperty(object2, name, defaultValue) {
    let value = this.getDynamicProperty(object2, name);
    if (value === void 0) value = defaultValue ?? 0;
    if (typeof value !== "number") throw new TypeError(`Expected a number but got ${typeof value}`);
    value++;
    this.setDynamicProperty(object2, name, value);
    return value;
  }
  static loadJson(data) {
    if (data.type === void 0) return data;
    const value = data.value;
    switch (data.type) {
      case "block_permutation":
        return BlockPermutation4.resolve(value.blockName, value.states);
      case "block_type":
        return BlockTypes2.get(value);
      case "item_type":
        return ItemTypes2.get(value);
      case "entity_type":
        return EntityTypes2.get(value);
      case "effect_type":
        return EffectTypes.get(value);
      case "dimension_type":
        return DimensionTypes2.get(value);
      case "enchantment_type":
        return EnchantmentTypes.get(value);
      case "dimension":
        return world11.getDimension(value);
      case "block":
        return world11.getDimension(value.dimension).getBlock({ x: value.x, y: value.y, z: value.z });
      case "chunk":
        return new Chunk(world11.getDimension(value.dimension), { x: value.x, z: value.z });
      case "entity":
        return world11.getEntity(value);
      case "bigint":
        return BigInt(value);
      case "undefined":
        return void 0;
      case "array":
        return value.map(_DataUtils.loadJson);
      case "object":
        const result = {};
        for (const [k2, v2] of Object.entries(value)) {
          result[k2] = _DataUtils.loadJson(v2);
        }
        return result;
    }
    return value;
  }
  static load(value) {
    if (typeof value !== "string") return value;
    try {
      const data = JSON.parse(value);
      if (!data.type) return data;
      return this.loadJson(data);
    } catch (err) {
      return value;
    }
  }
  static dumpJson(value) {
    switch (Typing.get(value)) {
      case "blockPermutation" /* BlockPermutation */:
        return { type: "block_permutation", value: { blockName: value.type.id, states: value.getAllStates() } };
      case "blockType" /* BlockType */:
        return { type: "block_type", value: value.id };
      case "itemType" /* ItemType */:
        return { type: "item_type", value: value.id };
      case "entityType" /* EntityType */:
        return { type: "entity_type", value: value.id };
      case "effectType" /* EffectType */:
        return { type: "effect_type", value: value.getName() };
      case "dimensionType" /* DimensionType */:
        return { type: "dimension_type", value: value.typeId };
      case "enchantmentType" /* EnchantmentType */:
        return { type: "enchantment_type", value: value.id };
      case "dimension" /* Dimension */:
        return { type: "dimension", value: value.id };
      case "block" /* Block */:
        return { type: "block", value: { dimension: value.dimension.id, x: value.x, y: value.y, z: value.z } };
      case "chunk" /* Chunk */:
        return { type: "chunk", value: { dimension: value.dimension.id, x: value.x, z: value.z } };
      case "entity" /* Entity */:
        return { type: "entity", value: value.id };
      case "vector2" /* Vector2 */:
        return { type: "vector2", value };
      case "vectorxz" /* VectorXZ */:
        return { type: "vectorxz", value };
      case "bigint" /* BigInt */:
        return { type: "bigint", value: Number(value) };
      case "undefined" /* Undefined */:
        return { type: "undefined" };
      case "array" /* Array */:
        return { type: "array", value: value.map(_DataUtils.dumpJson) };
      case "object" /* Object */:
        const result = {};
        for (const [k2, v2] of Object.entries(value)) {
          result[k2] = _DataUtils.dumpJson(v2);
        }
        return { type: "object", value: result };
    }
    return value;
  }
  /**
   * Converts the value to a dynamic property safe value.
   * @param {any} value
   * @returns {PropertyValue}
   */
  static dump(value) {
    if (typeof value === "object") {
      return JSON.stringify(this.dumpJson(value));
    }
    return value;
  }
  /**
   * Prints all properties to console.
   */
  static viewDynamicProperties(object2) {
    for (const [k2, v2] of Object.entries(this.getDynamicProperties(object2))) {
      console.warn(`${k2} = ${JSON.stringify(v2)}`);
    }
  }
  /**
   * Opens a UI where you can view, edit, or delete dynamic properties.
   * @param object
   * @param player
   */
  static showInspector(object2, player) {
    const clearAction = {
      icon: "textures/ui/icon_trash.png",
      label: "\xA7cDelete All",
      top_divider: true,
      onClick: (event) => {
        object2.clearDynamicProperties();
      }
    };
    const pages = { home: { title: "Data Inspector", buttons: [] } };
    const props = Object.entries(this.getDynamicProperties(object2));
    for (const [k2, v2] of props) {
      const pageId = `prop_${k2}`;
      const buttons = [];
      const deleteAction = {
        icon: "textures/ui/icon_trash.png",
        label: "\xA7cDelete",
        onClick: (event) => {
          object2.setDynamicProperty(k2, void 0);
          this.showInspector(object2, player);
        }
      };
      const editAction = {
        icon: "textures/ui/pencil_edit_icon.png",
        label: "Edit",
        onClick: (event) => {
          const form = {
            title: `Edit ${k2}`,
            options: { content: { type: "text", label: "Content", value: JSON.stringify(_DataUtils.dumpJson(v2)) } },
            onSubmit: (event2) => {
              const data = _DataUtils.load(event2.formResult.content);
              _DataUtils.setDynamicProperty(object2, k2, data);
              this.showInspector(object2, player);
            }
          };
          const ui2 = new ModalFormHandler(form, { saveValues: false });
          ui2.show(event.player);
        }
      };
      const renameAction = {
        icon: "textures/items/name_tag.png",
        label: "Rename",
        onClick: (event) => {
          const form = {
            title: `Rename ${k2}`,
            options: { key: { type: "text", label: "Key", value: k2 } },
            onSubmit: (event2) => {
              const newKey = event2.formResult.key;
              if (newKey !== k2) {
                _DataUtils.setDynamicProperty(object2, newKey, v2);
                object2.setDynamicProperty(k2, void 0);
              }
              this.showInspector(object2, player);
            }
          };
          const ui2 = new ModalFormHandler(form, { saveValues: false });
          ui2.show(event.player);
        }
      };
      buttons.push(deleteAction);
      buttons.push(editAction);
      buttons.push(renameAction);
      const content = TextUtils.renderJSON(v2);
      const rawContent = object2.getDynamicProperty(k2)?.toString();
      const page = {
        title: `"${k2}"`,
        body: `\xA7lType:\xA7r ${typeof v2}

\xA7lContent:\xA7r
${content}

\xA7lRaw Content:\xA7r
${rawContent}

`,
        buttons
      };
      pages.home.buttons?.push(pageId);
      pages[pageId] = page;
    }
    if (props.length === 0) {
      pages.home.body = "Object has no data.";
    } else {
      pages.home.buttons?.push(clearAction);
    }
    const ui = new PagedActionForm(pages, { id: "mcutils:data_inspector", back_button: {} });
    ui.show(player);
  }
};

// node_modules/@lpsmods/mc-utils/src/event/utils.ts
var EventSignal = class {
  listeners = [];
  constructor() {
  }
  get size() {
    return this.listeners.length;
  }
  subscribe(callback, options) {
    this.listeners.push({ callback, options });
    return callback;
  }
  unsubscribe(callback) {
    this.listeners = this.listeners.filter((fn) => fn.callback !== callback);
  }
  apply(event) {
    for (const fn of this.listeners) {
      try {
        fn.callback(event);
      } catch (err) {
        console.error(err);
      }
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/event/data.ts
var DataEvent = class {
  constructor(store, propertyName) {
    this.store = store;
    this.propertyName = propertyName;
  }
  store;
  propertyName;
};
var ReadDataEvent = class extends DataEvent {
};
var WriteDataEvent = class extends DataEvent {
};
var DeleteDataEvent = class extends DataEvent {
};
var ReadDataEventSignal = class extends EventSignal {
};
var WriteDataEventSignal = class extends EventSignal {
};
var DeleteDataEventSignal = class extends EventSignal {
};
var DataStorageEvents = class {
  constructor() {
  }
  /**
   * This event fires when data is read from DataStorage.
   * @eventProperty
   */
  static readData = new ReadDataEventSignal();
  /**
   * This event fires when data is written to DataStorage.
   * @eventProperty
   */
  static writeData = new WriteDataEventSignal();
  /**
   * This event fires when data is removed from DataStorage.
   * @eventProperty
   */
  static deleteData = new DeleteDataEventSignal();
};

// node_modules/@lpsmods/mc-utils/src/data/data_storage.ts
var DataStorage2 = class _DataStorage {
  static instances = /* @__PURE__ */ new Map();
  rootId;
  core;
  /**
   * Stores data.
   * @param {string} rootId
   * @param {DynamicObject} core
   */
  constructor(rootId, core) {
    this.rootId = rootId;
    this.core = core ?? world12;
    _DataStorage.instances.set(rootId, this);
    this.onLoad();
  }
  getItem(key, defaultValue) {
    const data = this.read();
    DataStorageEvents.readData.apply(new ReadDataEvent(this, key));
    return data[key] ?? defaultValue;
  }
  hasItem(key) {
    var item = this.getItem(key);
    return item !== void 0;
  }
  removeItem(key) {
    const data = this.read();
    DataStorageEvents.readData.apply(new ReadDataEvent(this, key));
    DataStorageEvents.deleteData.apply(new DeleteDataEvent(this, key));
    delete data[key];
    this.write(data);
    DataStorageEvents.writeData.apply(new WriteDataEvent(this, key));
  }
  setItem(key, value) {
    const data = this.read();
    DataStorageEvents.readData.apply(new ReadDataEvent(this, key));
    data[key] = value;
    this.write(data);
    DataStorageEvents.writeData.apply(new WriteDataEvent(this, key));
  }
  // Array methods
  /**
   * Removes the last element from an array and returns it. If the array is empty, undefined is returned and the array is not modified.
   * @param {string} key
   * @returns {any}
   */
  pop(key) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    DataStorageEvents.deleteData.apply(new DeleteDataEvent(this, key));
    return arr.pop();
  }
  /**
   * Appends new elements to the end of an array, and returns the new length of the array.
   * @param {string} key
   * @param {any} value
   * @returns {number}
   */
  push(key, value) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    arr.push(value);
    this.set(key, arr);
    return arr.length;
  }
  /**
   * Returns the elements of an array that meet the condition specified in a callback function.
   * @param {string} key
   * @param predicate
   * @returns {any[]}
   */
  filter(key, predicate) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    return arr.filter(predicate);
  }
  /**
   * Determines whether the specified callback function returns true for any element of an array.
   * @param {string} key
   * @param predicate
   * @returns {boolean}
   */
  some(key, predicate) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    return arr.some(predicate);
  }
  /**
   * Determines whether all the members of an array satisfy the specified test.
   * @param {string} key
   * @param predicate
   * @returns {boolean}
   */
  every(key, predicate) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    return arr.every(predicate);
  }
  /**
   * Returns the value of the first element in the array where predicate is true, and undefined otherwise.
   * @param {string} key
   * @param predicate
   * @returns {any|undefined}
   */
  find(key, predicate) {
    const arr = this.get(key);
    if (!Array.isArray(arr)) throw new TypeError(`Expected an array but got ${typeof arr}`);
    return arr.find(predicate);
  }
  clear() {
    DataStorageEvents.deleteData.apply(new DeleteDataEvent(this));
    this.core.setDynamicProperty(this.rootId, void 0);
  }
  keys() {
    const data = this.read();
    DataStorageEvents.readData.apply(new ReadDataEvent(this));
    return Object.keys(data);
  }
  getSize() {
    var res = this.core.getDynamicProperty(this.rootId);
    if (!res) return 0;
    var str = res.toString();
    let bytes = 0;
    for (let i2 = 0; i2 < str.length; i2++) {
      const codePoint = str.charCodeAt(i2);
      if (codePoint >= 55296 && codePoint <= 56319 && i2 + 1 < str.length) {
        const next = str.charCodeAt(i2 + 1);
        if (next >= 56320 && next <= 57343) {
          const fullCodePoint = (codePoint - 55296 << 10) + (next - 56320) + 65536;
          bytes += 4;
          i2++;
          continue;
        }
      }
      if (codePoint < 128) {
        bytes += 1;
      } else if (codePoint < 2048) {
        bytes += 2;
      } else {
        bytes += 3;
      }
    }
    return bytes;
  }
  update(data) {
    for (const k2 of Object.keys(data)) {
      const v2 = data[k2];
      this.setItem(k2, v2);
    }
  }
  remove() {
    this.clear();
    _DataStorage.instances.delete(this.rootId);
  }
  read() {
    if (this.onRead) this.onRead();
    return DataUtils.getDynamicProperty(this.core, this.rootId, {});
  }
  write(data) {
    if (this.onWrite) this.onWrite();
    return DataUtils.setDynamicProperty(this.core, this.rootId, data);
  }
  // Alias
  get = this.getItem;
  set = this.setItem;
  delete = this.removeItem;
  has = this.hasItem;
  // EVENTS
  /**
   * Fires when this storage is loaded.
   */
  onLoad() {
  }
  /**
   * Fires when this storage is unloaded.
   */
  onUnload() {
  }
  /**
   * Fires when this storage is read.
   */
  onRead() {
  }
  /**
   * Fires when this storage is written.
   */
  onWrite() {
  }
};
var VersionedDataStorage = class extends DataStorage2 {
  formatVersion;
  schemas = /* @__PURE__ */ new Map();
  /**
   * Stores versioned data.
   * @param {string} rootId
   * @param {number} formatVersion The current data version.
   * @param {DynamicObject} core
   */
  constructor(rootId, formatVersion, core) {
    super(rootId, core);
    this.formatVersion = formatVersion;
  }
  read() {
    const data = DataUtils.getDynamicProperty(this.core, this.rootId, { format_version: this.formatVersion });
    if (data.format_version < this.formatVersion) {
      for (const schema of this.schemas.values()) {
        if (schema.minFormat > this.formatVersion || schema.maxFormat < this.formatVersion) continue;
        schema.callback(data);
      }
      data.format_version = this.formatVersion;
      this.write(data);
      DataStorageEvents.writeData.apply(new WriteDataEvent(this));
    }
    return data;
  }
  write(data) {
    return DataUtils.setDynamicProperty(this.core, this.rootId, data);
  }
  addSchema(name, schema) {
    this.schemas.set(name, schema);
  }
  removeSchema(name) {
    this.schemas.delete(name);
  }
};
var LocalStorage = class extends DataStorage2 {
  constructor() {
    super("mcutils:local_storage");
  }
};
var SessionStorage = class extends DataStorage2 {
  constructor() {
    super("mcutils:session_storage");
  }
  onUnload() {
    this.remove();
  }
};
var localStorage = new LocalStorage();
var sessionStorage = new SessionStorage();
function playerLeave(event) {
  const count = world12.getAllPlayers().length;
  if (count > 1) return;
  for (const store of DataStorage2.instances.values()) {
    store.onUnload();
  }
}
world12.beforeEvents.playerLeave.subscribe(playerLeave);

// node_modules/@lpsmods/mc-utils/src/block/block_handler.ts
import {
  system as system8,
  world as world13
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/entity/player_utils.ts
import { EquipmentSlot as EquipmentSlot2, GameMode as GameMode2, system as system7 } from "@minecraft/server";
var ArmorSetEvent = class {
  constructor(player, itemStack, equipmentSlot, beforeItemStack) {
    this.player = player;
    this.itemStack = itemStack;
    this.beforeItemStack = beforeItemStack;
    this.equipmentSlot = equipmentSlot;
  }
  player;
  itemStack;
  beforeItemStack;
  equipmentSlot;
};
var PlayerUtils = class {
  /**
   * Get all loaded chunks by the player.
   * @param {player} player
   * @param {number} simulationDistance
   * @returns
   */
  static getLoadedChunks(player, simulationDistance = 4) {
    const px = Math.floor(player.location.x);
    const pz = Math.floor(player.location.z);
    const chunkX = Math.floor(px / 16);
    const chunkZ = Math.floor(pz / 16);
    const chunks = [];
    const maxDistance = simulationDistance + 1;
    for (let dx = -maxDistance; dx <= maxDistance; dx++) {
      for (let dz = -maxDistance; dz <= maxDistance; dz++) {
        const taxicab = Math.abs(dx) + Math.abs(dz);
        const isCardinal = dx === 0 && Math.abs(dz) === simulationDistance || dz === 0 && Math.abs(dx) === simulationDistance;
        if (taxicab <= simulationDistance + 1 && (taxicab <= simulationDistance || isCardinal)) {
          const x2 = chunkX + dx;
          const z2 = chunkZ + dz;
          chunks.push(new Chunk(player.dimension, { x: x2, z: z2 }));
        }
      }
    }
    return chunks;
  }
  /**
   * Gets all blocks around a player within the specified radius.
   * @param {Player} player - The player to search around.
   * @param {number} radius - The radius to check blocks in all directions.
   * @returns {Block[]} List of blocks and their positions.
   */
  static getBlocksAroundPlayer(player, radius) {
    const size = radius ?? 5;
    const blocks = [];
    const dimension = player.dimension;
    const center = player.location;
    for (let x2 = -size; x2 <= size; x2++) {
      for (let y2 = -size; y2 <= size; y2++) {
        for (let z2 = -size; z2 <= size; z2++) {
          const pos = {
            x: Math.floor(center.x + x2),
            y: Math.floor(center.y + y2),
            z: Math.floor(center.z + z2)
          };
          try {
            const block = dimension.getBlock(pos);
            if (block) {
              blocks.push(block);
            }
          } catch (e2) {
          }
        }
      }
    }
    return blocks;
  }
  /**
   * Shortcut function for adding armor to the player.
   * @param {PLayer} player
   * @param {ArmorSet} armorSet
   * @param condition
   * @returns
   */
  static applyArmor(player, armorSet, condition) {
    const equ = player.getComponent("equippable");
    if (!equ) return;
    for (const key in EquipmentSlot2) {
      const slot = EquipmentSlot2[key];
      const itemStack = armorSet[key.toLowerCase()];
      if (!itemStack) continue;
      const event = new ArmorSetEvent(player, itemStack, slot, equ.getEquipment(slot));
      if (condition === void 0 || condition(event)) {
        equ.setEquipment(event.equipmentSlot, event.itemStack);
      }
    }
  }
  // TODO: reloading the world makes you stuck.
  /**
   * Make the player sit.
   * @param {Player} player
   */
  static sit(player, location, rotation, callback, animations) {
    player.inputPermissions.setPermissionCategory(9, false);
    player.inputPermissions.setPermissionCategory(10, false);
    player.inputPermissions.setPermissionCategory(11, false);
    player.inputPermissions.setPermissionCategory(12, false);
    player.teleport(location, { rotation });
    for (const anim of animations ?? ["animation.player.riding.arms", "animation.player.riding.legs"]) {
      player.playAnimation(anim, {
        stopExpression: "q.is_sneaking||q.is_jumping"
      });
    }
    const runId = system7.runInterval(() => {
      if (!player.isSneaking && !player.isJumping) return;
      var cancel = false;
      try {
        if (callback) callback(cancel);
      } finally {
        if (cancel) return;
        player.inputPermissions.setPermissionCategory(9, true);
        player.inputPermissions.setPermissionCategory(10, true);
        player.inputPermissions.setPermissionCategory(11, true);
        player.inputPermissions.setPermissionCategory(12, true);
        system7.clearRun(runId);
      }
    });
  }
  /**
   * Make the player sleep.
   * @param {Player} player
   */
  static sleep(player, location, rotation, callback, animations) {
    player.inputPermissions.setPermissionCategory(9, false);
    player.inputPermissions.setPermissionCategory(10, false);
    player.inputPermissions.setPermissionCategory(11, false);
    player.inputPermissions.setPermissionCategory(12, false);
    player.teleport(location, { rotation });
    for (const anim of animations ?? ["animation.player.sleeping"]) {
      player.playAnimation(anim, {
        stopExpression: "q.is_sneaking||q.is_jumping"
      });
    }
    const runId = system7.runInterval(() => {
      if (!player.isSneaking && !player.isJumping) return;
      var cancel = false;
      try {
        if (callback) callback(cancel);
      } finally {
        if (cancel) return;
        player.inputPermissions.setPermissionCategory(9, true);
        player.inputPermissions.setPermissionCategory(10, true);
        player.inputPermissions.setPermissionCategory(11, true);
        player.inputPermissions.setPermissionCategory(12, true);
        system7.clearRun(runId);
      }
    });
  }
  /**
   * Whether or not the player can eat.
   * @param {Player} player
   * @returns {boolean}
   */
  static canEat(player) {
    if (player.getGameMode() === GameMode2.Creative) return true;
    const hunger = player.getComponent("player.hunger");
    return !hunger || hunger.currentValue < hunger.effectiveMax;
  }
  /**
   * Gives the player nutrition like they ate.
   * @param {Player} player
   * @param {number} nutrition
   * @param {boolean|string} sound
   */
  static eat(player, nutrition = 0, saturationModifier = 0, sound = true) {
    const hunger = player.getComponent("player.hunger");
    if (nutrition && hunger) {
      hunger.setCurrentValue(clampNumber(hunger.currentValue + nutrition, hunger.effectiveMin, hunger.effectiveMax));
    }
    const sat = player.getComponent("player.saturation");
    if (sat && saturationModifier) {
      const a2 = nutrition * saturationModifier * 2;
      sat.setCurrentValue(clampNumber(sat.currentValue + a2, sat.effectiveMin, sat.effectiveMax));
    }
    if (sound) player.dimension.playSound(typeof sound === "string" ? sound : "random.burp", player.location);
  }
};

// node_modules/@lpsmods/mc-utils/src/identifier.ts
import {
  BiomeType,
  Block as Block6,
  BlockPermutation as BlockPermutation5,
  BlockType as BlockType4,
  EffectType as EffectType2,
  EnchantmentType as EnchantmentType2,
  Entity as Entity8,
  EntityType as EntityType3,
  ItemStack as ItemStack6,
  ItemType as ItemType3
} from "@minecraft/server";
var Identifier = class _Identifier {
  namespace;
  path;
  constructor(namespace, path) {
    this.namespace = namespace;
    this.path = path;
  }
  equals(other) {
    const id = _Identifier.parse(other);
    return this.namespace === id.namespace && this.path === id.path;
  }
  matches = this.equals;
  /**
   * Add text to the end of the path.
   * @param {string} value
   * @returns {Identifier}
   */
  suffix(value) {
    this.path = this.path + value;
    return this;
  }
  /**
   * Add text to the start of the path.
   * @param {string} value
   * @returns {Identifier}
   */
  prefix(value) {
    this.path = value + this.path;
    return this;
  }
  /**
   * Replace text in the path.
   * @param {string|RegExp} searchValue
   * @param {string} replaceValue
   * @returns {Identifier}
   */
  replace(searchValue, replaceValue) {
    this.path = this.path.replace(searchValue, replaceValue);
    return this;
  }
  /**
   * A custom function to transform the path.
   * @param fn Function containing the logic to convert the path.
   * @returns {Identifier}
   */
  transform(fn) {
    this.path = fn(this.path);
    return this;
  }
  static parse(value) {
    if (!value) return new _Identifier("minecraft", "unknown");
    if (value instanceof BlockPermutation5) return _Identifier.parse(value.type.id);
    if (value instanceof Block6) return _Identifier.parse(value.typeId);
    if (value instanceof ItemStack6) return _Identifier.parse(value.typeId);
    if (value instanceof Entity8) return _Identifier.parse(value.typeId);
    if (value instanceof BiomeType) return _Identifier.parse(value.id);
    if (value instanceof BlockType4) return _Identifier.parse(value.id);
    if (value instanceof ItemType3) return _Identifier.parse(value.id);
    if (value instanceof EntityType3) return _Identifier.parse(value.id);
    if (value instanceof EffectType2) return _Identifier.parse(value.getName());
    if (value instanceof EnchantmentType2) return _Identifier.parse(value.id);
    if (value instanceof _Identifier) return value;
    let parts = value.split(":");
    let namespace = "minecraft";
    let path = "";
    if (parts.length >= 2) {
      namespace = parts[0];
      path = parts.slice(1).join(":");
    } else {
      path = parts[0];
    }
    return new _Identifier(namespace, path);
  }
  static string(value) {
    return this.parse(value).toString();
  }
  toString() {
    return `${this.namespace}:${this.path}`;
  }
  /**
   * Change the path while keeping the same namespace.
   * @param {string} path
   * @returns {Identifier}
   */
  withPath(path) {
    this.path = path;
    return this;
  }
};

// node_modules/@lpsmods/mc-utils/src/block/utils.ts
import {
  BlockPermutation as BlockPermutation7,
  BlockType as BlockType11,
  GameMode as GameMode4
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/registry/registry.ts
var Registry = class {
  static registryId;
  instances = /* @__PURE__ */ new Map();
  constructor() {
  }
  get size() {
    return this.instances.size;
  }
  register(name, object2) {
    const id = Identifier.string(name);
    this.instances.set(id, object2);
    return object2;
  }
  unregister(name) {
    const id = Identifier.string(name);
    this.instances.delete(id);
  }
  keys() {
    return this.instances.keys();
  }
  values() {
    return this.instances.values();
  }
  entries() {
    return this.instances.entries();
  }
  get(name, fallback) {
    const id = Identifier.string(name);
    return this.instances.get(id) ?? fallback;
  }
  has(name) {
    const id = Identifier.string(name);
    return this.instances.has(id);
  }
};

// node_modules/@lpsmods/mc-utils/src/registry/flattenable.ts
import { BlockType as BlockType5, BlockTypes as BlockTypes3, system as system14, world as world21 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/item/item_handler.ts
import {
  world as world20
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/event/area.ts
import { world as world14 } from "@minecraft/server";
var AreaEnterEventSignal = class extends EventSignal {
};
var AreaLeaveEventSignal = class extends EventSignal {
};
var AreaTickEventSignal = class extends EventSignal {
};
var AreaEvents = class {
  constructor() {
  }
  /**
   * This event fires when a entity enters the area.
   * @eventProperty
   */
  static entityEnter = new AreaEnterEventSignal();
  /**
   * This event fires when a entity leaves the area.
   * @eventProperty
   */
  static entityLeave = new AreaLeaveEventSignal();
  /**
   * This event fires every tick a entity is in the area.
   * @eventProperty
   */
  static entityTick = new AreaTickEventSignal();
  static get size() {
    return this.entityEnter.size + this.entityLeave.size + this.entityTick.size;
  }
};

// node_modules/@lpsmods/mc-utils/src/event/block.ts
var initialized = false;
var BlockEvent = class {
  constructor(block, dimension) {
    this.block = block;
    this.dimension = dimension ?? block.dimension;
    if (!initialized) init();
  }
  block;
  dimension;
};
var BlockNearbyEntityTickEventSignal = class extends EventSignal {
  constructor() {
    super();
  }
};
var BlockNeighborUpdateEventSignal = class extends EventSignal {
  constructor() {
    super();
  }
};
var BlockEvents = class {
  constructor() {
  }
  /**
   * This event fires every tick a entity is near a block.
   * @eventProperty
   */
  static nearbyEntityTick = new BlockNearbyEntityTickEventSignal();
  /**
   * This event fires when a block has updated.
   * @eventProperty
   */
  static neighborUpdate = new BlockNeighborUpdateEventSignal();
  static get size() {
    return this.nearbyEntityTick.size + this.neighborUpdate.size;
  }
};
function init() {
  initialized = true;
}

// node_modules/@lpsmods/mc-utils/src/event/chunk.ts
import { system as system11, world as world17 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/event/entity.ts
import {
  InvalidEntityError,
  LocationOutOfWorldBoundariesError as LocationOutOfWorldBoundariesError2,
  system as system10,
  world as world16
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/chunk/chunk_queue.ts
import { system as system9, world as world15, BlockPermutation as BlockPermutation6 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/chunk/utils.ts
var ChunkUtils = class {
  /**
   * Converts a block pos to a chunk pos.
   * @param {Vector3} location
   * @returns {VectorXZ}
   */
  static pos(location) {
    return {
      x: Math.floor(location.x / 16),
      z: Math.floor(location.z / 16)
    };
  }
  /**
   * Get the chunk from a position in the world.
   * @param {Dimension} dimension
   * @param {Vector3} location
   * @returns {Chunk}
   */
  static pos2Chunk(dimension, location) {
    const pos = this.pos(location);
    return new Chunk(dimension, pos);
  }
  /**
   * Get the chunk the block is in.
   * @param {Block} block
   * @returns {Chunk}
   */
  static block2Pos(block) {
    return this.pos2Chunk(block.dimension, block.location);
  }
  /**
   * Get the chunk the entity is in.
   * @param {Entity} entity
   * @returns {Chunk}
   */
  static entity2Pos(entity) {
    return this.pos2Chunk(entity.dimension, entity.location);
  }
};

// node_modules/@lpsmods/mc-utils/src/event/entity.ts
var EntityEvent = class {
  constructor(entity) {
    this.entity = entity;
  }
  entity;
};
var EntityBlockEvent = class extends EntityEvent {
  constructor(entity, block) {
    super(entity);
    this.block = block;
  }
  block;
};
var EntityMountEvent = class extends EntityEvent {
  constructor(entity, rider) {
    super(entity);
    this.rider = rider;
  }
  rider;
};
var EntityDismountEvent = class extends EntityEvent {
  constructor(entity, rider) {
    super(entity);
    this.rider = rider;
  }
  rider;
};
var EntityMovedEvent = class extends EntityEvent {
  constructor(entity, prevLocation) {
    super(entity);
    this.prevLocation = prevLocation;
    const pos = Vector3Utils.floor(entity.location);
    const prev = Vector3Utils.floor(prevLocation);
    this.movedBlock = !Vector3Utils.equals(pos, prev);
    const cPos = ChunkUtils.pos(pos);
    const cPrev = ChunkUtils.pos(prev);
    this.movedChunk = cPos.x != cPrev.x || cPos.z != cPrev.z;
  }
  /**
   * The previous entity location.
   */
  prevLocation;
  /**
   * Whether or not the player moved to a new block.
   */
  movedBlock;
  /**
   * Whether or not the player moved to a new chunk.
   */
  movedChunk;
};
var EntityFallOnEvent = class extends EntityEvent {
  constructor(entity, distance) {
    super(entity);
    this.distance = distance;
  }
  distance;
};
var EntityTickEvent = class extends EntityEvent {
};
var EntityStepOnEvent = class extends EntityBlockEvent {
};
var EntityEnterBlockEvent = class extends EntityBlockEvent {
  constructor(entity, block, previousBlock) {
    super(entity, block);
    this.previousBlock = previousBlock;
    this.sameType = !previousBlock || block.matches(previousBlock.typeId);
  }
  previousBlock;
  /**
   * Whether or not the current and previous block are the same type.
   */
  sameType;
};
var EntityLeaveBlockEvent = class extends EntityBlockEvent {
  constructor(entity, block, newBlock) {
    super(entity, block);
    this.newBlock = newBlock;
    this.sameType = !newBlock || block.matches(newBlock.typeId);
  }
  newBlock;
  /**
   * Whether or not the current and new block are the same type.
   */
  sameType;
};
var EntityInBlockTickEvent = class extends EntityBlockEvent {
};
var EntityEventSignal = class extends EventSignal {
  apply(event) {
    for (const fn of this.listeners) {
      if (!event.entity.isValid) continue;
      if (fn.options && !event.entity.matches(fn.options)) continue;
      try {
        fn.callback(event);
      } catch (err) {
        console.error(err);
      }
    }
  }
};
var EntityMountEventSignal = class extends EntityEventSignal {
};
var EntityDismountEventSignal = class extends EntityEventSignal {
};
var EntityMovedEventSignal = class extends EntityEventSignal {
};
var EntityTickEventSignal = class extends EntityEventSignal {
};
var EntityFallOnEventSignal = class extends EntityEventSignal {
};
var EntityStepOnEventSignal = class extends EntityEventSignal {
};
var EntityStepOffEventSignal = class extends EntityEventSignal {
};
var EntityEnterBlockEventSignal = class extends EntityEventSignal {
};
var EntityLeaveBlockEventSignal = class extends EntityEventSignal {
};
var EntityInBlockTickEventSignal = class extends EntityEventSignal {
};
var EntityEvents = class {
  constructor() {
  }
  /**
   * This event fires when a entity mounts.
   * @eventProperty
   */
  static mount = new EntityMountEventSignal();
  /**
   * This event fires when a entity dismounts.
   * @eventProperty
   */
  static dismount = new EntityDismountEventSignal();
  /**
   * This event fires when a entity moves.
   * @eventProperty
   */
  static moved = new EntityMovedEventSignal();
  /**
   * This event fires every tick.
   * @eventProperty
   */
  static tick = new EntityTickEventSignal();
  /**
   * This event fires when a entity falls on the ground.
   * @eventProperty
   */
  static fallOn = new EntityFallOnEventSignal();
  /**
   * This event fires when a entity steps on a block.
   * @eventProperty
   */
  static stepOn = new EntityStepOnEventSignal();
  /**
   * This event fires when a entity steps off a block.
   * @eventProperty
   */
  static stepOff = new EntityStepOffEventSignal();
  /**
   * This event fires when an entity enters a block.
   * @eventProperty
   */
  static enterBlock = new EntityEnterBlockEventSignal();
  /**
   * This event fires when a entity leaves a block.
   * @eventProperty
   */
  static leaveBlock = new EntityLeaveBlockEventSignal();
  /**
   * This event fires every tick a entity is in a block.
   * @eventProperty
   */
  static inBlockTick = new EntityInBlockTickEventSignal();
  static get size() {
    return this.mount.size + this.dismount.size + this.moved.size + this.tick.size + this.fallOn.size + this.stepOn.size + this.stepOff.size + this.enterBlock.size + this.leaveBlock.size + this.inBlockTick.size;
  }
};
function mountEntityTick(entity) {
  const riding = entity.getComponent("riding");
  if (riding) {
    let lastMount = entity.getDynamicProperty("mcutils:last_mount");
    let target = riding.entityRidingOn.id;
    if (target != lastMount) {
      entity.setDynamicProperty("mcutils:last_mount", target);
    }
    return;
  }
  let id = entity.getDynamicProperty("mcutils:last_mount");
  if (id) {
    const mountEvent = new EntityDismountEvent(world16.getEntity(id) ?? entity, entity);
    entity.setDynamicProperty("mcutils:last_mount", void 0);
    entity.removeTag("mcutils_riding");
    EntityEvents.dismount.apply(mountEvent);
  }
}
function mountTick(event) {
  forAllDimensions((dim) => {
    for (const entity of dim.getEntities({ tags: ["mcutils_riding"] })) {
      mountEntityTick(entity);
    }
  });
}
function movedTick(event) {
  const dim = event.entity.dimension;
  const value = event.entity.getDynamicProperty("mcutils:prev_location") ?? "0,0,0";
  const prevPos = Vector3Utils.fromString(value);
  if (!prevPos) return;
  const pos = event.entity.location;
  pos.x = Math.round(pos.x * 100) / 100;
  pos.y = Math.round(pos.y * 100) / 100;
  pos.z = Math.round(pos.z * 100) / 100;
  if (Vector3Utils.equals(prevPos, pos)) return;
  event.entity.setDynamicProperty("mcutils:prev_location", Vector3Utils.toString(pos));
  const movedEvent = new EntityMovedEvent(event.entity, prevPos);
  EntityEvents.moved.apply(movedEvent);
  if (!movedEvent.movedBlock) return;
  let block = void 0;
  let prevBlock = void 0;
  try {
    block = dim.getBlock(pos);
    prevBlock = dim.getBlock(prevPos);
  } catch (err) {
  }
  if (prevBlock) {
    EntityEvents.leaveBlock.apply(new EntityLeaveBlockEvent(event.entity, prevBlock, block));
  }
  if (block) {
    EntityEvents.enterBlock.apply(new EntityEnterBlockEvent(event.entity, block, prevBlock));
  }
  ErrorUtils.wrapCatch(LocationOutOfWorldBoundariesError2, () => {
    const newBlock = block?.below();
    const prevBlock2 = prevBlock?.below();
    if (!newBlock || !prevBlock2) return;
    const newHash = Hasher.stringify(newBlock);
    const prevHash = Hasher.stringify(prevBlock2);
    if (newHash === prevHash) return;
    EntityEvents.stepOn.apply(new EntityStepOnEvent(event.entity, newBlock));
    EntityEvents.stepOff.apply(new EntityStepOnEvent(event.entity, prevBlock2));
  });
}
function entityTick(event) {
  mountTick(event);
  EntityEvents.tick.apply(event);
  movedTick(event);
  let block = void 0;
  try {
    block = event.entity.dimension.getBlock(event.entity.location);
  } catch (err) {
  }
  if (block) {
    EntityEvents.inBlockTick.apply(new EntityInBlockTickEvent(event.entity, block));
  }
  let fallingPos = event.entity.getDynamicProperty("mcutils:falling_pos");
  if (fallingPos == void 0 && event.entity.isFalling) {
    fallingPos = event.entity.location;
    event.entity.setDynamicProperty("mcutils:falling_pos", fallingPos);
  }
  if (fallingPos && event.entity.isOnGround) {
    let dif = Vector3Utils.floor(Vector3Utils.subtract(fallingPos, event.entity.location));
    event.entity.setDynamicProperty("mcutils:falling_pos");
    EntityEvents.fallOn.apply(new EntityFallOnEvent(event.entity, dif.y));
  }
}
function tick() {
  try {
    forAllDimensions((dim) => {
      for (const entity of dim.getEntities()) {
        const event = new EntityTickEvent(entity);
        entityTick(event);
      }
    });
  } catch (err) {
    if (err instanceof InvalidEntityError) return;
    throw err;
  }
}
function playerInteract(event) {
  try {
    if (event.player.isSneaking || event.player.hasTag("mcutils_riding")) return;
    const rideable = event.target.getComponent("rideable");
    if (!rideable) return;
    const mountEvent = new EntityMountEvent(event.target, event.player);
    event.player.addTag("mcutils_riding");
    EntityEvents.mount.apply(mountEvent);
  } catch (err) {
    if (err instanceof InvalidEntityError) return;
    throw err;
  }
}
function init2() {
  system10.runInterval(tick);
  world16.afterEvents.playerInteractWithEntity.subscribe(playerInteract);
}
init2();

// node_modules/@lpsmods/mc-utils/src/event/chunk.ts
var ChunkEvent = class {
  constructor(chunk) {
    this.chunk = chunk;
    this.dimension = chunk.dimension;
  }
  chunk;
  dimension;
};
var PlayerChunkEvent = class extends ChunkEvent {
  constructor(chunk, player) {
    super(chunk);
    this.player = player;
  }
  player;
};
var PlayerChunkLoadEvent = class extends PlayerChunkEvent {
  constructor(chunk, player, initial) {
    super(chunk, player);
    this.initial = initial;
  }
  initial;
};
var PlayerChunkUnloadEvent = class extends PlayerChunkEvent {
};
var ChunkTickEvent = class extends ChunkEvent {
};
var PlayerChunkLoadEventSignal = class extends EventSignal {
  subscribe(callback) {
    return super.subscribe(callback);
  }
};
var PlayerChunkUnloadEventSignal = class extends EventSignal {
  subscribe(callback) {
    return super.subscribe(callback);
  }
};
var PlayerChunkTickEventSignal = class extends EventSignal {
  subscribe(callback) {
    return super.subscribe(callback);
  }
};
var ChunkEvents = class {
  constructor() {
  }
  /**
   * This event fires when a player loads a chunk.
   * @eventProperty
   */
  static playerLoad = new PlayerChunkLoadEventSignal();
  /**
   * This event fires when a player unloads a chunk.
   * @eventProperty
   */
  static playerUnload = new PlayerChunkUnloadEventSignal();
  /**
   * This event fires every tick for player loaded chunks.
   * @eventProperty
   */
  static loadedTick = new PlayerChunkTickEventSignal();
  static get size() {
    return this.playerLoad.size + this.playerUnload.size + this.loadedTick.size;
  }
};
var SIMULATION_DISTANCE = 4;
var loadedChunks = /* @__PURE__ */ new Set();
function tick2() {
  for (const hash of loadedChunks) {
    const chunk = Hasher.parseChunk(hash);
    if (!chunk) continue;
    ChunkEvents.loadedTick.apply(new ChunkTickEvent(chunk));
  }
}
function movedChunk(player) {
  if (ChunkEvents.size === 0) return;
  const cache = [];
  const chunks = PlayerUtils.getLoadedChunks(player, SIMULATION_DISTANCE);
  for (const chunk of chunks) {
    const key = Hasher.stringify(chunk);
    if (!key) continue;
    cache.push(key);
    if (loadedChunks.has(key)) continue;
    loadedChunks.add(key);
    const gen = chunk.getDynamicProperty("mcutils:has_generated") ?? false;
    chunk.ensureLoaded().then((loaded) => {
      if (!loaded) return;
      if (!gen) {
        chunk.setDynamicProperty("mcutils:has_generated", true);
      }
      ChunkEvents.playerLoad.apply(new PlayerChunkLoadEvent(chunk, player, !gen));
    });
  }
  const diff = differenceArray(cache, [...loadedChunks]);
  for (const hash of diff) {
    const chunk = Hasher.parseChunk(hash);
    if (!chunk) continue;
    ChunkEvents.playerUnload.apply(new PlayerChunkUnloadEvent(chunk, player));
  }
  loadedChunks = new Set(removeItems([...loadedChunks], diff));
}
function init3() {
  system11.runInterval(tick2);
  world17.afterEvents.playerSpawn.subscribe((event) => {
    if (!event.initialSpawn) return;
    movedChunk(event.player);
  });
  EntityEvents.moved.subscribe(
    (event) => {
      if (!event.movedChunk) return;
      movedChunk(event.entity);
    },
    { type: "player" }
  );
}
init3();

// node_modules/@lpsmods/mc-utils/src/event/item.ts
import { EquipmentSlot as EquipmentSlot3, system as system12, world as world18 } from "@minecraft/server";
var ItemEvent = class {
  constructor(itemStack) {
    this.itemStack = itemStack;
  }
  itemStack;
};
var PlayerItemEvent = class extends ItemEvent {
  constructor(itemStack, player) {
    super(itemStack);
    this.player = player;
  }
  player;
};
var ItemEventSignal = class extends EventSignal {
  apply(event) {
    for (const fn of this.listeners) {
      if (fn?.options?.itemPredicate && !ItemUtils.matches(event.itemStack, fn.options.itemPredicate)) continue;
      try {
        fn.callback(event);
      } catch (err) {
        console.error(err);
      }
    }
  }
};
var ItemHoldEvent = class extends PlayerItemEvent {
};
var ItemHoldTickEvent = class extends PlayerItemEvent {
};
var ItemHoldEventSignal = class extends ItemEventSignal {
};
var ItemReleaseHoldEventSignal = class extends ItemEventSignal {
};
var ItemHoldTickEventSignal = class extends ItemEventSignal {
};
var ItemEvents = class {
  constructor() {
  }
  // /**
  //  * This event fires when a player strips a log.
  //  * @eventProperty
  //  */
  // static readonly playerStripped = new ItemStrippedEventSignal();
  // /**
  //  * This event fires when a player scrapes wax.
  //  * @eventProperty
  //  */
  // static readonly playerScrapedWax = new ItemScrapedWaxEventSignal();
  // /**
  //  * This event fires when a player scrapes oxidization.
  //  * @eventProperty
  //  */
  // static readonly playerScrapedOxidization = new ItemScrapedOxidizationEventSignal();
  /**
   * This event fires when a player holds an item.
   * @eventProperty
   */
  static playerHold = new ItemHoldEventSignal();
  /**
   * This event fires when a player stops holding an item.
   * @eventProperty
   */
  static playerReleaseHold = new ItemReleaseHoldEventSignal();
  /**
   * This event fires every tick the player is holding an item.
   * @eventProperty
   */
  static playerHoldTick = new ItemHoldTickEventSignal();
  static get size() {
    return this.playerHold.size + this.playerReleaseHold.size + this.playerHoldTick.size;
  }
};
function init4() {
  world18.afterEvents.playerHotbarSelectedSlotChange.subscribe((event) => {
    const container = event.player.getComponent("inventory")?.container;
    if (!container) return;
    const prevItemStack = container.getItem(event.previousSlotSelected);
    if (prevItemStack) {
      ItemEvents.playerReleaseHold.apply(new ItemHoldEvent(prevItemStack, event.player));
    }
    if (!event.itemStack) return;
    ItemEvents.playerHold.apply(new ItemHoldEvent(event.itemStack, event.player));
  });
  system12.runInterval(() => {
    if (!ItemEvents.playerHoldTick.size) return;
    for (const player of world18.getAllPlayers()) {
      const equ = player.getComponent("equippable");
      const itemStack = equ?.getEquipment(EquipmentSlot3.Mainhand);
      if (!itemStack) return;
      ItemEvents.playerHoldTick.apply(new ItemHoldTickEvent(itemStack, player));
    }
  });
}
init4();

// node_modules/@lpsmods/mc-utils/src/event/screen.ts
import {
  EquipmentSlot as EquipmentSlot4,
  system as system13,
  world as world19
} from "@minecraft/server";
var initialized2 = false;
var ScreenEvent = class {
  constructor(player, screenType, sourceType, options) {
    this.player = player;
    this.screenType = screenType;
    this.sourceType = sourceType;
    this.sourceBlock = options.sourceBlock;
    this.sourceEntity = options.sourceEntity;
  }
  player;
  screenType;
  sourceType;
  sourceBlock;
  sourceEntity;
};
var OpenScreenEvent = class extends ScreenEvent {
};
var CloseScreenEvent = class extends ScreenEvent {
};
var OpenScreenEventSignal = class extends EventSignal {
};
var CloseScreenEventSignal = class extends EventSignal {
};
var ScreenEvents = class {
  constructor() {
  }
  /**
   * This event fires when a player opens a screen.
   * @eventProperty
   */
  static openScreen = new OpenScreenEventSignal();
  /**
   * This event fires when a player closes a screen.
   * @eventProperty
   */
  static closeScreen = new CloseScreenEventSignal();
};
function trackClosedUI(event) {
  let lastPos = void 0;
  let lastRot = void 0;
  let delay = 2;
  const runId = system13.runInterval(() => {
    if (delay > 0) {
      delay--;
      return;
    }
    let pos = Vector3Utils.toString(event.player.location, { decimals: 2 });
    let rot = Hasher.stringify(event.player.getRotation());
    if (lastPos === void 0 || lastRot === void 0) {
      lastPos = pos;
      lastRot = rot;
      return;
    }
    if (lastPos !== pos || lastRot !== rot) {
      ScreenEvents.closeScreen.apply(event);
      system13.clearRun(runId);
    }
  });
}
function getBlockScreen(block) {
  if (BlockUtils.matches(block, "#anvil")) return "anvil_screen";
  if (BlockUtils.matches(block, "beacon")) return "beacon_screen";
  if (BlockUtils.matches(block, "blast_furnace")) return "blast_furnace_screen";
  if (BlockUtils.matches(block, "loom")) return "loom_screen";
  if (BlockUtils.matches(block, "lectern")) return "book_screen";
  if (BlockUtils.matches(block, "brewing_stand")) return "brewing_stand_screen";
  if (BlockUtils.matches(block, "cartography_table")) return "cartography_screen";
  if (BlockUtils.matches(block, "barrel")) return "barrel_screen";
  if (BlockUtils.matches(block, "#shulker_box")) return "shulker_box_screen";
  if (BlockUtils.matches(block, "ender_chest")) return "ender_chest_screen";
  if (BlockUtils.matches(block, "enchanting_table")) return "enchanting_screen";
  if (BlockUtils.matches(block, "furnace")) return "furnace_screen";
  if (BlockUtils.matches(block, "grindstone")) return "grindstone_screen";
  if (BlockUtils.matches(block, "crafting_table")) return "crafting_screen";
  if (BlockUtils.matches(block, "jigsaw")) return "jigsaw_editor_screen";
  if (BlockUtils.matches(block, "dispenser")) return "dispenser_screen";
  if (BlockUtils.matches(block, "hopper")) return "hopper_screen";
  if (BlockUtils.matches(block, "dropper")) return "dropper_screen";
  if (BlockUtils.matches(block, "crafter")) return "crafter_screen";
  if (BlockUtils.matches(block, "smithing_table")) return "smithing_table_screen";
  if (BlockUtils.matches(block, "smoker")) return "smoker_screen";
  if (BlockUtils.matches(block, "stonecutter_block")) return "stonecutter_screen";
  if (BlockUtils.matches(block, "structure_block")) return "structure_editor_screen";
  const blockPredicates = ["chest", "trapped_chest", "#copper_chests"];
  if (BlockUtils.matchAny(block, blockPredicates)) return "small_chest_screen";
  if (BlockUtils.matchAny(block, ["command_block", "chain_command_block", "repeating_command_block"]))
    return "command_block_screen";
}
function playerInteractWithBlock(event) {
  if (event.player.isSneaking) {
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    if (equ.getEquipment(EquipmentSlot4.Mainhand) !== void 0) return;
  }
  const screenType = getBlockScreen(event.block);
  if (!screenType) return;
  const cEvent = new OpenScreenEvent(event.player, screenType, "block" /* Block */, { sourceBlock: event.block });
  ScreenEvents.openScreen.apply(cEvent);
  trackClosedUI(new CloseScreenEvent(event.player, screenType, "block" /* Block */, { sourceBlock: event.block }));
}
function playerInteractWithEntity(event) {
  const npc = event.target.hasComponent("npc");
  if (npc) {
    ScreenEvents.openScreen.apply(
      new OpenScreenEvent(event.player, "npc", "entity" /* Entity */, { sourceEntity: event.target })
    );
    trackClosedUI(new CloseScreenEvent(event.player, "npc", "entity" /* Entity */, { sourceEntity: event.target }));
    return;
  }
  const screenType = event.target.getComponent("inventory")?.containerType;
  if (!screenType || screenType === "none") return;
  if (event.target.matches({ type: "chest_boat" })) {
    if (!event.player.isSneaking) return;
    ScreenEvents.openScreen.apply(
      new OpenScreenEvent(event.player, screenType, "entity" /* Entity */, { sourceEntity: event.target })
    );
    trackClosedUI(
      new CloseScreenEvent(event.player, screenType, "entity" /* Entity */, { sourceEntity: event.target })
    );
    return;
  }
  ScreenEvents.openScreen.apply(
    new OpenScreenEvent(event.player, screenType, "entity" /* Entity */, { sourceEntity: event.target })
  );
  trackClosedUI(
    new CloseScreenEvent(event.player, screenType, "entity" /* Entity */, { sourceEntity: event.target })
  );
}
function itemUse(event) {
  if (ItemUtils.matchAny(event.itemStack, ["writable_book", "written_book"])) {
    ScreenEvents.openScreen.apply(
      new OpenScreenEvent(event.source, "book_screen", "entity" /* Entity */, { sourceEntity: event.source })
    );
    trackClosedUI(
      new CloseScreenEvent(event.source, "book_screen", "entity" /* Entity */, { sourceEntity: event.source })
    );
    return;
  }
}
function init5() {
  initialized2 = true;
  world19.beforeEvents.playerInteractWithBlock.subscribe(playerInteractWithBlock);
  world19.beforeEvents.playerInteractWithEntity.subscribe(playerInteractWithEntity);
  world19.beforeEvents.itemUse.subscribe(itemUse);
}
if (!initialized2) init5();

// node_modules/@lpsmods/mc-utils/src/item/utils.ts
import {
  EnchantmentType as EnchantmentType3,
  EnchantmentTypes as EnchantmentTypes2,
  EquipmentSlot as EquipmentSlot6,
  GameMode as GameMode3,
  ItemStack as ItemStack9,
  Player as Player12
} from "@minecraft/server";
var ItemUtils = class _ItemUtils {
  /**
   * Replace slot with itemStack.
   * @param {Player} player
   * @param {number} slot
   * @param {ItemStack} resultStack
   */
  static setStack(player, slot, resultStack) {
    const inv = player.getComponent("inventory");
    const equ = player.getComponent("equippable");
    if (!equ) return;
    const stack = equ.getEquipment(slot);
    if (!stack) return;
    if (stack.amount === 1) {
      equ.setEquipment(slot, resultStack);
    } else {
      if (!inv || !inv.container) return;
      inv.container.addItem(resultStack);
      stack.amount -= 1;
      equ.setEquipment(slot, stack);
    }
  }
  /**
   * Decrease the number of items in slot.
   * @param {Player} player
   * @param {number} slot
   * @param {number} amount
   * @returns {boolean} True if it used emptyStack.
   */
  static decrementStack(player, slot = EquipmentSlot6.Mainhand, amount = 1, gameModeCheck = true, emptyStack) {
    if (gameModeCheck && player.getGameMode() == GameMode3.Creative) return false;
    const equ = player.getComponent("equippable");
    if (!equ) return false;
    const stack = equ.getEquipment(slot);
    if (!stack) return false;
    if (stack.amount <= amount) {
      equ.setEquipment(slot, emptyStack);
      return true;
    }
    stack.amount -= amount;
    equ.setEquipment(slot, stack);
    return false;
  }
  /**
   * Whether or not the itemName is in the players inventory.
   * @param {Player} player
   * @param {string} item
   * @returns
   */
  static has(player, item) {
    const inv = player.getComponent("minecraft:inventory");
    const itemName = item instanceof ItemStack9 ? item.typeId : item;
    if (!inv || !inv.container) return false;
    for (let slot = 0; slot < inv.container.size; slot++) {
      const itemStack = inv.container.getItem(slot);
      if (itemStack && itemStack.matches(itemName)) return true;
    }
    return false;
  }
  /**
   * Give or drop the item.
   * @param {Player} player
   * @param {ItemStack} itemStack
   * @returns {ItemStack}
   */
  static give(player, itemStack) {
    const inv = player.getComponent("inventory");
    if (!inv || !inv.container) return itemStack;
    if (inv.container.emptySlotsCount === 0) {
      player.dimension.spawnItem(itemStack, player.location);
      return itemStack;
    }
    inv.container.addItem(itemStack);
    return itemStack;
  }
  /**
   * Deals damage or decreases an item stack.
   * @param {Player} player
   * @param {ItemStack} itemStack
   * @param {Vector3} soundLocation
   */
  static usedIgnitable(player, itemStack, soundLocation) {
    if (itemStack.matches("fire_charge")) {
      player.dimension.playSound("mob.ghast.fireball", soundLocation ?? player.location);
      _ItemUtils.decrementStack(player, EquipmentSlot6.Mainhand);
      return;
    }
    if (itemStack.matches("flint_and_steel")) {
      player.dimension.playSound("fire.ignite", soundLocation ?? player.location);
      _ItemUtils.applyDamage(player, itemStack, 1);
      return;
    }
  }
  /**
   * Deals damage to this item's durability, considering unbreaking enchantment.
   * If the item's durability exceeds the maximum, it will break.
   * @param {ItemStack} itemStack The item stack to deal damage to.
   * @param {number} amount The amount of damage to apply (default is 1).
   * @returns {ItemStack}
   */
  static applyDamage(source, itemStack, amount = 1, slot) {
    if (source instanceof Player12 && source?.getGameMode() === GameMode3.Creative) return itemStack;
    const equ = source.getComponent("equippable");
    if (!equ) return itemStack;
    const durability = itemStack.getComponent("durability");
    if (!durability) return itemStack;
    const unbreakingLevel = itemStack.getComponent("enchantable")?.getEnchantment("unbreaking")?.level ?? 0;
    const shouldApplyDamage = Math.random() < 1 / (unbreakingLevel + 1);
    if (shouldApplyDamage) {
      durability.damage += amount;
      if (durability.damage >= durability.maxDurability) {
        equ.setEquipment(slot ?? EquipmentSlot6.Mainhand);
        source.dimension.playSound("random.break", source.location);
        return itemStack;
      }
      equ.setEquipment(slot ?? EquipmentSlot6.Mainhand, itemStack);
    }
    return itemStack;
  }
  /**
   * Starts the cooldown timer for this players item.
   * @param itemStack The item stack to start the cooldown.
   * @param player The player to cooldown.
   * @returns
   */
  static startCooldown(itemStack, player) {
    const cooldown = itemStack.getComponent("cooldown");
    if (!cooldown) return;
    cooldown.startCooldown(player);
  }
  /**
   * Converts a number of items in slot to another item.
   * @param {Players} player
   * @param {EquipmentSlot} slot
   * @param {ItemStack} itemStack
   * @param {number} amount
   * @param {boolean} gameModeCheck
   * @returns {ItemStack}
   */
  static convert(player, slot, itemStack, amount = 1, gameModeCheck = true) {
    const con = player.getComponent("equippable");
    if (!con) return itemStack;
    const main = con.getEquipment(slot);
    if (!main) return itemStack;
    const res = _ItemUtils.decrementStack(player, slot, amount, gameModeCheck, itemStack);
    if (!res) return itemStack;
    if (_ItemUtils.has(player, itemStack)) return itemStack;
    _ItemUtils.give(player, itemStack);
    return itemStack;
  }
  /**
   * Whether or not the entity is holding this item.
   * @param {Entity} entity
   * @param {string} itemPredicate An item name. Prefix with '#' for item tag or "!" to ignore.
   */
  static holding(entity, itemPredicate, equipmentSlot) {
    if (!entity || !entity.isValid) return false;
    const equ = entity.getComponent("equippable");
    if (!equ) return false;
    const itemStack = equ.getEquipment(equipmentSlot ?? EquipmentSlot6.Mainhand);
    if (!itemStack) return false;
    return Array.isArray(itemPredicate) ? this.matchAny(itemStack, itemPredicate) : this.matches(itemStack, itemPredicate);
  }
  /**
   * Match any item name.
   * @param {ItemStack} itemStack The item to match.
   * @param {string[]} itemPredicates An array of item names. Prefix with '#' for item tag or "!" to ignore.
   * @returns {boolean} Whether or not the item matched any of the item names.
   */
  static matchAny(itemStack, itemPredicates, states) {
    const itemSet = [...new Set(itemPredicates)];
    return itemSet.some((itemPredicate) => {
      return _ItemUtils.matches(itemStack, itemPredicate, states);
    });
  }
  /**
   * Match this item.
   * @param {ItemStack} itemStack The item to match.
   * @param {string} itemPredicate An item name. Prefix with '#' for item tag or "!" to ignore.
   * @returns {boolean}
   */
  static matches(itemStack, itemPredicate, states) {
    if (itemPredicate.charAt(0) === "#") {
      const tag = itemPredicate.slice(1);
      return itemStack.hasTag(tag) || CustomTags.items.matches(tag, itemStack.typeId);
    }
    if (itemPredicate.charAt(0) === "!") {
      return !itemStack.matches(itemPredicate.slice(1), states);
    }
    return itemStack.matches(itemPredicate, states);
  }
  /**
   * Remove item(s) from the entities inventory.
   * @param {Entity} entity
   * @param {string} itemPredicate An item name. Prefix with '#' for item tag or "!" to ignore.
   */
  static clear(entity, itemPredicate) {
    const container = entity.getComponent("inventory")?.container;
    if (!container) return;
    for (let i2 = 0; i2 < container.size; i2++) {
      const item = container.getItem(i2);
      if (!item) continue;
      if (!_ItemUtils.matches(item, itemPredicate)) continue;
      container.setItem(i2);
    }
  }
  /**
   * Enchants this item.
   * @param {ItemStack} itemStack
   * @param {EnchantmentType|string} enchantmentType
   * @param {number} level
   * @returns {ItemStack}
   */
  static enchant(itemStack, enchantmentType, level) {
    const enchant = itemStack.getComponent("enchantable");
    if (!enchant) return itemStack;
    const type2 = enchantmentType instanceof EnchantmentType3 ? enchantmentType : EnchantmentTypes2.get(enchantmentType);
    if (!type2) return itemStack;
    enchant.addEnchantment({ type: type2, level: level ?? 1 });
    return itemStack;
  }
};

// node_modules/@lpsmods/mc-utils/src/registry/flattenable.ts
var initialized3 = false;
var FlattenableBlockRegistry = class extends Registry {
  register(input, options) {
    if (!initialized3) init6();
    const id = input instanceof BlockType5 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes3.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var flattenableBlocks = new FlattenableBlockRegistry();
function init6() {
  initialized3 = true;
  world21.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack || !ItemUtils.matches(event.itemStack, "#is_shovel")) return;
    const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
    if (!source) return;
    const options = flattenableBlocks.get(source.typeId);
    if (!options) return;
    system14.run(() => {
      if (options.onConvert) options.onConvert(source, event);
      source.dimension.playSound(options.sound_event ?? "use.grass", source.location);
      BlockUtils.setType(source, options.block);
    });
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/strippable.ts
import { BlockType as BlockType6, BlockTypes as BlockTypes4, system as system15, world as world22 } from "@minecraft/server";
var initialized4 = false;
var StrippableBlockRegistry = class extends Registry {
  register(input, options) {
    if (!initialized4) init7();
    const id = input instanceof BlockType6 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes4.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var strippableBlocks = new StrippableBlockRegistry();
function init7() {
  initialized4 = true;
  world22.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack || !ItemUtils.matches(event.itemStack, "#is_axe")) return;
    const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
    if (!source) return;
    const options = strippableBlocks.get(source.typeId);
    if (!options) return;
    system15.run(() => {
      if (options.onConvert) options.onConvert(source, event);
      source.dimension.playSound(options.sound_event ?? "use.wood", source.location);
      BlockUtils.setType(source, options.block);
    });
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/oxidizable.ts
import { BlockType as BlockType7, BlockTypes as BlockTypes5, system as system16, world as world23 } from "@minecraft/server";
var initialized5 = false;
var OxidizableBlocksRegistry = class extends Registry {
  register(input, options) {
    if (!initialized5) init8();
    const id = input instanceof BlockType7 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes5.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var oxidizableBlocks = new OxidizableBlocksRegistry();
function init8() {
  initialized5 = true;
  world23.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack || !ItemUtils.matches(event.itemStack, "#is_axe")) return;
    const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
    if (!source) return;
    const options = oxidizableBlocks.get(source.typeId);
    if (!options) return;
    system16.run(() => {
      if (options.onConvert) options.onConvert(source, event);
      source.dimension.playSound(options.sound_event ?? "scrape", source.location);
      BlockUtils.setType(source, options.block);
    });
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/waxable.ts
import { BlockType as BlockType8, BlockTypes as BlockTypes6, system as system17, world as world24 } from "@minecraft/server";
var initialized6 = false;
var WaxableBlockRegistry = class extends Registry {
  register(input, options) {
    if (!initialized6) init9();
    const id = input instanceof BlockType8 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes6.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var waxableBlocks = new WaxableBlockRegistry();
function axe(event) {
  const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
  if (!source) return;
  for (const [k2, options] of waxableBlocks.entries()) {
    const id = options.block instanceof BlockType8 ? options.block.id : BlockTypes6.get(options.block)?.id;
    if (!id) continue;
    if (id === source.typeId) {
      system17.run(() => {
        if (options.onConvert) options.onConvert(source, event);
        source.dimension.playSound("copper.wax.off", source.location);
        BlockUtils.setType(source, k2);
      });
      return;
    }
  }
}
function honeycomb(event) {
  const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
  if (!source) return;
  const options = waxableBlocks.get(source.typeId);
  if (!options) return;
  system17.run(() => {
    if (options.onConvert) options.onConvert(source, event);
    source.dimension.playSound("copper.wax.on", source.location);
    BlockUtils.setType(source, options.block);
  });
}
function init9() {
  initialized6 = true;
  world24.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack) return;
    if (ItemUtils.matches(event.itemStack, "#is_axe")) return axe(event);
    if (ItemUtils.matches(event.itemStack, "#waxable")) return honeycomb(event);
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/tillable.ts
import { BlockType as BlockType9, BlockTypes as BlockTypes7, system as system18, world as world25 } from "@minecraft/server";
var initialized7 = false;
var TillableBlockRegistry = class extends Registry {
  register(input, options) {
    if (!initialized7) init10();
    const id = input instanceof BlockType9 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes7.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var tillableBlocks = new TillableBlockRegistry();
function init10() {
  initialized7 = true;
  world25.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack || !ItemUtils.matches(event.itemStack, "#is_hoe")) return;
    const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
    if (!source) return;
    const options = tillableBlocks.get(source.typeId);
    if (!options) return;
    system18.run(() => {
      if (options.onConvert) options.onConvert(source, event);
      source.dimension.playSound(options.sound_event ?? "use.gravel", source.location);
      BlockUtils.setType(source, options.block);
    });
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/shearable.ts
import { BlockType as BlockType10, BlockTypes as BlockTypes8, system as system19, world as world26 } from "@minecraft/server";
var initialized8 = false;
var ShearableBlocksRegistry = class extends Registry {
  register(input, options) {
    if (!initialized8) init11();
    const id = input instanceof BlockType10 ? input.id : input;
    return super.register(id, options);
  }
  get(name) {
    const k2 = [...this.keys()].find((k3) => {
      let b2 = BlockTypes8.get(k3);
      return !b2 || b2.id === name;
    });
    if (!k2) return void 0;
    return super.get(k2);
  }
};
var shearableBlocks = new ShearableBlocksRegistry();
function init11() {
  initialized8 = true;
  world26.beforeEvents.itemUse.subscribe((event) => {
    if (!event.itemStack || !ItemUtils.matches(event.itemStack, "#is_shears")) return;
    const source = event.source.getBlockFromViewDirection({ maxDistance: 6 })?.block;
    if (!source) return;
    const options = shearableBlocks.get(source.typeId);
    if (!options) return;
    system19.run(() => {
      if (options.onConvert) options.onConvert(source, event);
      source.dimension.playSound(options.sound_event ?? "pumpkin.carve", source.location);
      BlockUtils.setType(source, options.block);
    });
  });
}

// node_modules/@lpsmods/mc-utils/src/registry/tag.ts
var CustomTagRegistry = class extends Registry {
  register(name, object2, replace = false) {
    if (replace || !this.has(name)) {
      return super.register(
        name,
        this.resolve(
          name,
          object2.map((item) => this.transform(item))
        )
      );
    }
    const reg = this.get(name);
    if (!reg) return;
    object2.forEach((item) => reg.push(this.transform(item)));
    return super.register(name, this.resolve(name, reg));
  }
  matches(tag, object2) {
    const reg = this.get(tag);
    if (!reg) return false;
    const str = Identifier.parse(this.transform(object2)).toString();
    return reg.some((item) => item === str);
  }
  transform(object2) {
    return Identifier.parse(object2).toString();
  }
  resolve(tagName, object2) {
    let items = [];
    for (const item of object2) {
      if (item.charAt(0) === "#") {
        const name = Identifier.string(item.slice(1));
        if (name === tagName) continue;
        const tag = this.get(name);
        if (!tag) continue;
        items = [...items, ...tag];
        continue;
      }
      items.push(item);
    }
    return items;
  }
};
var CustomItemTags = class extends CustomTagRegistry {
  static registryId = "item_tags";
};
var CustomBlockTags = class extends CustomTagRegistry {
  static registryId = "block_tags";
};
var CustomTags = class {
  static items = new CustomItemTags();
  static blocks = new CustomBlockTags();
};
CustomTags.items.register("ignitable", ["flint_and_steel", "fire_charge"]);
CustomTags.items.register("waxable", ["honeycomb"]);
CustomTags.items.register(
  "concrete",
  COLORS.map((color) => `${color}_concrete`)
);
CustomTags.items.register(
  "concrete_powder",
  COLORS.map((color) => `${color}_concrete_powder`)
);
CustomTags.items.register(
  "wool",
  COLORS.map((color) => `${color}_wool`)
);
CustomTags.items.register("candle", ["candle", ...COLORS.map((color) => `${color}_candle`)]);
CustomTags.items.register("terracotta", ["terracotta", ...COLORS.map((color) => `${color}_terracotta`)]);
CustomTags.items.register(
  "glazed_terracotta",
  COLORS.map((color) => `${color}_glazed_terracotta`)
);
CustomTags.items.register(
  "carpet",
  COLORS.map((color) => `${color}_carpet`)
);
CustomTags.items.register(
  "stained_glass",
  COLORS.map((color) => `${color}_stained_glass`)
);
CustomTags.items.register(
  "stained_glass_pane",
  COLORS.map((color) => `${color}_stained_glass_pane`)
);
CustomTags.items.register(
  "harness",
  COLORS.map((color) => `${color}_harness`)
);
CustomTags.items.register("bundle", ["bundle", ...COLORS.map((color) => `${color}_bundle`)]);
CustomTags.items.register("shulker_box", ["undyed_shulker_box", ...COLORS.map((color) => `${color}_shulker_box`)]);
CustomTags.items.register(
  "banner",
  COLORS.map((color) => `${color}_banner`)
);
CustomTags.blocks.register(
  "concrete",
  COLORS.map((color) => `${color}_concrete`)
);
CustomTags.blocks.register(
  "concrete_powder",
  COLORS.map((color) => `${color}_concrete_powder`)
);
CustomTags.items.register(
  "wool",
  COLORS.map((color) => `${color}_wool`)
);
CustomTags.blocks.register("candle", ["candle", ...COLORS.map((color) => `${color}_candle`)]);
CustomTags.blocks.register("terracotta", ["terracotta", ...COLORS.map((color) => `${color}_terracotta`)]);
CustomTags.blocks.register(
  "glazed_terracotta",
  COLORS.map((color) => `${color}_glazed_terracotta`)
);
CustomTags.blocks.register(
  "carpet",
  COLORS.map((color) => `${color}_carpet`)
);
CustomTags.blocks.register(
  "stained_glass",
  COLORS.map((color) => `${color}_stained_glass`)
);
CustomTags.blocks.register(
  "stained_glass_pane",
  COLORS.map((color) => `${color}_stained_glass_pane`)
);
CustomTags.blocks.register("shulker_box", ["undyed_shulker_box", ...COLORS.map((color) => `${color}_shulker_box`)]);
CustomTags.blocks.register(
  "banner",
  COLORS.map((color) => `${color}_banner`)
);
CustomTags.blocks.register("copper_chests", [
  "copper_chest",
  "exposed_copper_chest",
  "weathered_copper_chest",
  "oxidized_copper_chest",
  "waxed_copper_chest",
  "waxed_exposed_copper_chest",
  "waxed_weathered_copper_chest",
  "waxed_oxidized_copper_chest"
]);
CustomTags.blocks.register("anvil", ["anvil", "chipped_anvil", "damaged_anvil"]);

// node_modules/@lpsmods/mc-utils/src/block/utils.ts
var BlockUtils = class _BlockUtils {
  /**
   * Changes the block type, but preserves the states.
   * @param {Block} block
   * @param {string} typeId
   * @returns {Block}
   */
  static setType(block, typeId, excludeStates) {
    const blockName = typeId instanceof BlockType11 ? typeId.id : typeId;
    const states = block.permutation.getAllStates();
    for (const state of excludeStates ?? []) {
      delete states[state];
    }
    try {
      block.setPermutation(BlockPermutation7.resolve(blockName ?? "air", states));
    } catch (err) {
      block.setType(blockName ?? "air");
    }
  }
  /**
   * Changes the block state value.
   * @param {Block} block
   * @param {string} stateName
   * @param {any} stateValue
   * @returns {Block}
   */
  static setState(block, stateName, stateValue) {
    block.setPermutation(block.permutation.withState(stateName, stateValue));
  }
  /**
   * Increase a number block state.
   * @param block
   * @param stateName
   * @param amount
   */
  static incrementState(block, stateName, amount = 1) {
    const value = block.permutation.getState(stateName) + amount;
    _BlockUtils.setState(block, stateName, value);
    return value;
  }
  /**
   * Decrease a number block state.
   * @param block
   * @param stateName
   * @param amount
   */
  static decrementState(block, stateName, amount = 1) {
    const value = block.permutation.getState(stateName) - amount;
    _BlockUtils.setState(block, stateName, value);
    return value;
  }
  /**
   * Toggle a boolean block state.
   * @param block
   * @param stateName
   */
  static toggleState(block, stateName) {
    const value = block.permutation.getState(stateName);
    _BlockUtils.setState(block, stateName, !value);
    return !value;
  }
  /**
   * Checks if both blocks have a matching block state.
   * @param {Block} block First block to compare.
   * @param {Block} block2 Second block to compare.
   * @param {string} stateName The block property name to compare.
   * @returns {boolean} Whether or no the properties match.
   */
  static matchState(block, block2, stateName) {
    return block.permutation.getState(stateName) === block2.permutation.getState(stateName);
  }
  static MAX_CACHE = 512;
  static CACHE = {};
  /**
   * Checks if the block has neighbor updates.
   * @param {BlockComponentTickEvent} e
   * @returns {undefined}
   */
  static getNeighborUpdate(e2) {
    var size = Object.keys(_BlockUtils.CACHE).length;
    if (size > _BlockUtils.MAX_CACHE) {
      _BlockUtils.CACHE = {};
    }
    var key = `${e2.block.location.x},${e2.block.location.y},${e2.block.location.z}`;
    const cached = _BlockUtils.CACHE[key];
    const perms = [
      e2.block.north()?.permutation ?? void 0,
      e2.block.south()?.permutation ?? void 0,
      e2.block.east()?.permutation ?? void 0,
      e2.block.west()?.permutation ?? void 0,
      e2.block.above()?.permutation ?? void 0,
      e2.block.below()?.permutation ?? void 0
    ];
    if (!perms) return void 0;
    if (!cached) {
      _BlockUtils.CACHE[key] = perms;
      return void 0;
    }
    for (let i2 = 0; i2 < perms.length; i2++) {
      if (cached[i2] != perms[i2]) {
        _BlockUtils.CACHE[key] = perms;
        return DirectionUtils.fromNumber(i2);
      }
    }
    return void 0;
  }
  /**
   * Checks if a given BlockPermutation exists within a specified taxicab distance.
   * @param {Block} origin - The starting location.
   * @param {number} maxDistance - The maximum taxicab distance to check.
   * @param condition - Function to test.
   * @returns {boolean} - True if the block is found within range, false otherwise.
   */
  static isWithinTaxicabDistance(origin, maxDistance, condition) {
    return MathUtils.taxicabDistance(origin, maxDistance, (location) => {
      const blk = origin.dimension.getBlock(location);
      if (blk && condition(blk)) return true;
    }) ?? false;
  }
  /**
   * Checks if a given BlockPermutation exists within a specified chebyshev distance.
   * @param {Block} origin - The starting block.
   * @param {number} maxDistance - The maximum chebyshev distance to check.
   * @param condition - Function to test.
   * @returns {boolean} - True if the block is found within range, false otherwise.
   */
  static isWithinChebyshevDistance(origin, maxDistance, condition) {
    return MathUtils.chebyshevDistance(origin, maxDistance, (location) => {
      const blk = origin.dimension.getBlock(location);
      if (blk && condition(blk)) return true;
    }) ?? false;
  }
  /**
   * Tests if the block is water or is waterlogged.
   * @param {Block} block
   * @returns {boolean}
   */
  static isWater(block) {
    return block.matches("water");
  }
  /**
   * Breaks this block like if a player has broken it.
   * @param {Block} block
   * @param {Player} player
   * @returns
   */
  static destroy(block, player) {
    if (player && player.getGameMode() === GameMode4.Creative) return block.setType("air");
    block.dimension.runCommand(`setblock ${block.location.x} ${block.location.y} ${block.location.z} air destroy`);
  }
  /**
   * Guess the oxidized state of the block or block name.
   * @param {Block|string} block
   * @returns {Oxidization}
   */
  static guessOxidization(block) {
    const typeId = Identifier.parse(block);
    const p2 = typeId.path.toLowerCase();
    if (p2.includes("exposed")) return 1 /* Exposed */;
    if (p2.includes("weathered")) return 2 /* Weathered */;
    if (p2.includes("oxidized")) return 3 /* Oxidized */;
    return 0 /* Normal */;
  }
  /**
   * Filter positions to only those without another block directly above.
   * @param {Vector3[]} positions
   * @returns {Vector3[]}
   */
  static getExposedBlocks(positions, direction = "above" /* Above */) {
    const posSet = new Set(positions.map((p2) => Vector3Utils.toString(p2)));
    return positions.filter((p2) => {
      if (direction === "above") {
        return !posSet.has(Vector3Utils.toString(Vector3Utils.add(p2, { x: 0, y: 1, z: 0 })));
      }
      if (direction === "below") {
        return !posSet.has(Vector3Utils.toString(Vector3Utils.add(p2, { x: 0, y: -1, z: 0 })));
      }
      if (direction === "side") {
        const sides = [
          Vector3Utils.toString(Vector3Utils.add(p2, { x: 1, y: 0, z: 0 })),
          Vector3Utils.toString(Vector3Utils.add(p2, { x: -1, y: 0, z: 0 })),
          Vector3Utils.toString(Vector3Utils.add(p2, { x: 0, y: 0, z: 1 })),
          Vector3Utils.toString(Vector3Utils.add(p2, { x: 0, y: 0, z: -1 }))
        ];
        return sides.some((sideKey) => !posSet.has(sideKey));
      }
      throw new Error(`Invalid direction: ${direction}`);
    });
  }
  /**
   * Match any block name.
   * @param {Block} block The block to match.
   * @param {string[]} blockPredicates An array of block names. Prefix with '#' for block tag or "!" to ignore.
   * @returns {boolean} Whether or not the block matched any of the block names.
   */
  static matchAny(block, blockPredicates, states) {
    const blockSet = [...new Set(blockPredicates)];
    return blockSet.some((blockPredicate) => {
      return _BlockUtils.matches(block, blockPredicate, states);
    });
  }
  /**
   * Match this block.
   * @param {Block} block The block to match.
   * @param {string} blockPredicate A block name. Prefix with '#' for block tag or "!" to ignore.
   * @returns {boolean}
   */
  static matches(block, blockPredicate, states) {
    if (blockPredicate.charAt(0) === "#") {
      const tag = blockPredicate.slice(1);
      return block.hasTag(tag) || CustomTags.blocks.matches(tag, block.typeId);
    }
    if (blockPredicate.charAt(0) === "!") {
      return !block.matches(blockPredicate.slice(1), states);
    }
    return block.matches(blockPredicate, states);
  }
  /**
   * Whether or not the block is a wall block.
   * @param {Block} block
   * @returns {boolean}
   */
  static isWall(block) {
    if (!block) return false;
    return block.hasTag("wall") || Identifier.parse(block).path.includes("wall");
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/base.ts
import {
  Direction as Direction3
} from "@minecraft/server";

// node_modules/superstruct/dist/index.mjs
var StructError = class extends TypeError {
  constructor(failure, failures) {
    let cached;
    const { message, explanation, ...rest } = failure;
    const { path } = failure;
    const msg = path.length === 0 ? message : `At path: ${path.join(".")} -- ${message}`;
    super(explanation ?? msg);
    if (explanation != null)
      this.cause = msg;
    Object.assign(this, rest);
    this.name = this.constructor.name;
    this.failures = () => {
      return cached ?? (cached = [failure, ...failures()]);
    };
  }
};
function isIterable(x2) {
  return isObject(x2) && typeof x2[Symbol.iterator] === "function";
}
function isObject(x2) {
  return typeof x2 === "object" && x2 != null;
}
function isNonArrayObject(x2) {
  return isObject(x2) && !Array.isArray(x2);
}
function isPlainObject(x2) {
  if (Object.prototype.toString.call(x2) !== "[object Object]") {
    return false;
  }
  const prototype = Object.getPrototypeOf(x2);
  return prototype === null || prototype === Object.prototype;
}
function print(value) {
  if (typeof value === "symbol") {
    return value.toString();
  }
  return typeof value === "string" ? JSON.stringify(value) : `${value}`;
}
function shiftIterator(input) {
  const { done, value } = input.next();
  return done ? void 0 : value;
}
function toFailure(result, context, struct, value) {
  if (result === true) {
    return;
  } else if (result === false) {
    result = {};
  } else if (typeof result === "string") {
    result = { message: result };
  }
  const { path, branch } = context;
  const { type: type2 } = struct;
  const { refinement, message = `Expected a value of type \`${type2}\`${refinement ? ` with refinement \`${refinement}\`` : ""}, but received: \`${print(value)}\`` } = result;
  return {
    value,
    type: type2,
    refinement,
    key: path[path.length - 1],
    path,
    branch,
    ...result,
    message
  };
}
function* toFailures(result, context, struct, value) {
  if (!isIterable(result)) {
    result = [result];
  }
  for (const r2 of result) {
    const failure = toFailure(r2, context, struct, value);
    if (failure) {
      yield failure;
    }
  }
}
function* run(value, struct, options = {}) {
  const { path = [], branch = [value], coerce: coerce2 = false, mask: mask2 = false } = options;
  const ctx = { path, branch, mask: mask2 };
  if (coerce2) {
    value = struct.coercer(value, ctx);
  }
  let status = "valid";
  for (const failure of struct.validator(value, ctx)) {
    failure.explanation = options.message;
    status = "not_valid";
    yield [failure, void 0];
  }
  for (let [k2, v2, s2] of struct.entries(value, ctx)) {
    const ts = run(v2, s2, {
      path: k2 === void 0 ? path : [...path, k2],
      branch: k2 === void 0 ? branch : [...branch, v2],
      coerce: coerce2,
      mask: mask2,
      message: options.message
    });
    for (const t4 of ts) {
      if (t4[0]) {
        status = t4[0].refinement != null ? "not_refined" : "not_valid";
        yield [t4[0], void 0];
      } else if (coerce2) {
        v2 = t4[1];
        if (k2 === void 0) {
          value = v2;
        } else if (value instanceof Map) {
          value.set(k2, v2);
        } else if (value instanceof Set) {
          value.add(v2);
        } else if (isObject(value)) {
          if (v2 !== void 0 || k2 in value)
            value[k2] = v2;
        }
      }
    }
  }
  if (status !== "not_valid") {
    for (const failure of struct.refiner(value, ctx)) {
      failure.explanation = options.message;
      status = "not_refined";
      yield [failure, void 0];
    }
  }
  if (status === "valid") {
    yield [void 0, value];
  }
}
var Struct = class {
  constructor(props) {
    const { type: type2, schema, validator, refiner, coercer = (value) => value, entries = function* () {
    } } = props;
    this.type = type2;
    this.schema = schema;
    this.entries = entries;
    this.coercer = coercer;
    if (validator) {
      this.validator = (value, context) => {
        const result = validator(value, context);
        return toFailures(result, context, this, value);
      };
    } else {
      this.validator = () => [];
    }
    if (refiner) {
      this.refiner = (value, context) => {
        const result = refiner(value, context);
        return toFailures(result, context, this, value);
      };
    } else {
      this.refiner = () => [];
    }
  }
  /**
   * Assert that a value passes the struct's validation, throwing if it doesn't.
   */
  assert(value, message) {
    return assert(value, this, message);
  }
  /**
   * Create a value with the struct's coercion logic, then validate it.
   */
  create(value, message) {
    return create(value, this, message);
  }
  /**
   * Check if a value passes the struct's validation.
   */
  is(value) {
    return is(value, this);
  }
  /**
   * Mask a value, coercing and validating it, but returning only the subset of
   * properties defined by the struct's schema. Masking applies recursively to
   * props of `object` structs only.
   */
  mask(value, message) {
    return mask(value, this, message);
  }
  /**
   * Validate a value with the struct's validation logic, returning a tuple
   * representing the result.
   *
   * You may optionally pass `true` for the `coerce` argument to coerce
   * the value before attempting to validate it. If you do, the result will
   * contain the coerced result when successful. Also, `mask` will turn on
   * masking of the unknown `object` props recursively if passed.
   */
  validate(value, options = {}) {
    return validate(value, this, options);
  }
};
function assert(value, struct, message) {
  const result = validate(value, struct, { message });
  if (result[0]) {
    throw result[0];
  }
}
function create(value, struct, message) {
  const result = validate(value, struct, { coerce: true, message });
  if (result[0]) {
    throw result[0];
  } else {
    return result[1];
  }
}
function mask(value, struct, message) {
  const result = validate(value, struct, { coerce: true, mask: true, message });
  if (result[0]) {
    throw result[0];
  } else {
    return result[1];
  }
}
function is(value, struct) {
  const result = validate(value, struct);
  return !result[0];
}
function validate(value, struct, options = {}) {
  const tuples = run(value, struct, options);
  const tuple = shiftIterator(tuples);
  if (tuple[0]) {
    const error = new StructError(tuple[0], function* () {
      for (const t4 of tuples) {
        if (t4[0]) {
          yield t4[0];
        }
      }
    });
    return [error, void 0];
  } else {
    const v2 = tuple[1];
    return [void 0, v2];
  }
}
function assign(...Structs) {
  const isType = Structs[0].type === "type";
  const schemas = Structs.map((s2) => s2.schema);
  const schema = Object.assign({}, ...schemas);
  return isType ? type(schema) : object(schema);
}
function define(name, validator) {
  return new Struct({ type: name, schema: null, validator });
}
function array(Element) {
  return new Struct({
    type: "array",
    schema: Element,
    *entries(value) {
      if (Element && Array.isArray(value)) {
        for (const [i2, v2] of value.entries()) {
          yield [i2, v2, Element];
        }
      }
    },
    coercer(value) {
      return Array.isArray(value) ? value.slice() : value;
    },
    validator(value) {
      return Array.isArray(value) || `Expected an array value, but received: ${print(value)}`;
    }
  });
}
function boolean() {
  return define("boolean", (value) => {
    return typeof value === "boolean";
  });
}
function never() {
  return define("never", () => false);
}
function number() {
  return define("number", (value) => {
    return typeof value === "number" && !isNaN(value) || `Expected a number, but received: ${print(value)}`;
  });
}
function object(schema) {
  const knowns = schema ? Object.keys(schema) : [];
  const Never = never();
  return new Struct({
    type: "object",
    schema: schema ? schema : null,
    *entries(value) {
      if (schema && isObject(value)) {
        const unknowns = new Set(Object.keys(value));
        for (const key of knowns) {
          unknowns.delete(key);
          yield [key, value[key], schema[key]];
        }
        for (const key of unknowns) {
          yield [key, value[key], Never];
        }
      }
    },
    validator(value) {
      return isNonArrayObject(value) || `Expected an object, but received: ${print(value)}`;
    },
    coercer(value, ctx) {
      if (!isNonArrayObject(value)) {
        return value;
      }
      const coerced = { ...value };
      if (ctx.mask && schema) {
        for (const key in coerced) {
          if (schema[key] === void 0) {
            delete coerced[key];
          }
        }
      }
      return coerced;
    }
  });
}
function optional(struct) {
  return new Struct({
    ...struct,
    validator: (value, ctx) => value === void 0 || struct.validator(value, ctx),
    refiner: (value, ctx) => value === void 0 || struct.refiner(value, ctx)
  });
}
function string() {
  return define("string", (value) => {
    return typeof value === "string" || `Expected a string, but received: ${print(value)}`;
  });
}
function type(schema) {
  const keys = Object.keys(schema);
  return new Struct({
    type: "type",
    schema,
    *entries(value) {
      if (isObject(value)) {
        for (const k2 of keys) {
          yield [k2, value[k2], schema[k2]];
        }
      }
    },
    validator(value) {
      return isNonArrayObject(value) || `Expected an object, but received: ${print(value)}`;
    },
    coercer(value) {
      return isNonArrayObject(value) ? { ...value } : value;
    }
  });
}
function unknown() {
  return define("unknown", () => true);
}
function coerce(struct, condition, coercer) {
  return new Struct({
    ...struct,
    coercer: (value, ctx) => {
      return is(value, condition) ? struct.coercer(coercer(value, ctx), ctx) : struct.coercer(value, ctx);
    }
  });
}
function defaulted(struct, fallback, options = {}) {
  return coerce(struct, unknown(), (x2) => {
    const f2 = typeof fallback === "function" ? fallback() : fallback;
    if (x2 === void 0) {
      return f2;
    }
    if (!options.strict && isPlainObject(x2) && isPlainObject(f2)) {
      const ret = { ...x2 };
      let changed = false;
      for (const key in f2) {
        if (ret[key] === void 0) {
          ret[key] = f2[key];
          changed = true;
        }
      }
      if (changed) {
        return ret;
      }
    }
    return x2;
  });
}
function max(struct, threshold, options = {}) {
  const { exclusive } = options;
  return refine(struct, "max", (value) => {
    return exclusive ? value < threshold : value <= threshold || `Expected a ${struct.type} less than ${exclusive ? "" : "or equal to "}${threshold} but received \`${value}\``;
  });
}
function min(struct, threshold, options = {}) {
  const { exclusive } = options;
  return refine(struct, "min", (value) => {
    return exclusive ? value > threshold : value >= threshold || `Expected a ${struct.type} greater than ${exclusive ? "" : "or equal to "}${threshold} but received \`${value}\``;
  });
}
function refine(struct, name, refiner) {
  return new Struct({
    ...struct,
    *refiner(value, ctx) {
      yield* struct.refiner(value, ctx);
      const result = refiner(value, ctx);
      const failures = toFailures(result, ctx, struct, value);
      for (const failure of failures) {
        yield { ...failure, refinement: name };
      }
    }
  });
}

// node_modules/@lpsmods/mc-utils/src/blockcomponent/base.ts
var NeighborUpdateEvent = class extends BlockEvent {
  constructor(block, sourceBlock, direction) {
    super(block);
    this.sourceBlock = sourceBlock;
    this.direction = direction;
  }
  /**
   * The block that was updated next to `block`
   */
  sourceBlock;
  /**
   * The direction the update came from.
   */
  direction;
};
var NearbyEntityBlockEvent = class extends BlockEvent {
  constructor(block, entity) {
    super(block);
    this.entity = entity;
  }
  /**
   * The nearby entity.
   */
  entity;
};
var ScheduledBlockEvent = class extends BlockEvent {
};
var BlockBaseComponent = class {
  static componentId;
  static components = [];
  scheduledEvents = /* @__PURE__ */ new Set();
  struct = object({});
  constructor() {
  }
  destroy = BlockUtils.destroy;
  baseTick(event, args) {
    this.afterTick(event, args);
    this.enterLeaveTick(event, args);
    this.neighborTick(event, args);
  }
  basePlace(event, args) {
    for (const direction in Direction3) {
      const sourceBlock = event.block.offset(DirectionUtils.toOffset(direction));
      if (!sourceBlock) continue;
      const updateEvent = new NeighborUpdateEvent(event.block, sourceBlock, direction);
      if (this.onNeighborUpdate) this.onNeighborUpdate(updateEvent, args);
    }
  }
  isInBlock(block, entity) {
    return Math.floor(entity.location.x) == block.location.x && Math.floor(entity.location.y) == block.location.y && Math.floor(entity.location.z) == block.location.z;
  }
  // TODO: Tick is per block instance (more blocks screws w/ timing)
  afterTick(event, args) {
    for (const e2 of this.scheduledEvents) {
      if (e2.timeLeft > 0) {
        e2.timeLeft--;
        continue;
      }
      try {
        if (event.block.typeId !== e2.block.typeId) return;
        const sEvent = new ScheduledBlockEvent(e2.block);
        e2.callback(sEvent, args);
      } finally {
        this.scheduledEvents.delete(e2);
      }
    }
  }
  enterLeaveTick(event, args) {
    const entities = event.dimension.getEntities({
      maxDistance: 1.5,
      location: event.block.location
    });
    const hash = Hasher.stringify(event.block);
    for (const entity of entities) {
      this.onNearbyEntityTick(new NearbyEntityBlockEvent(event.block, entity), args);
      let eBlock = entity.dimension.getBlock(entity.location);
      let blk = entity.getDynamicProperty("mcutils:in_block");
      let block = Hasher.parseBlock(blk);
      let bl = this.isInBlock(event.block, entity);
      if (bl && this.inBlockTick) this.inBlockTick(new EntityInBlockTickEvent(entity, event.block), args);
      if (bl && blk !== hash) {
        entity.setDynamicProperty("mcutils:in_block", hash);
        if (this.onEnter) this.onEnter(new EntityEnterBlockEvent(entity, event.block, block), args);
        continue;
      }
      if (!bl && blk === hash) {
        let same = event.block?.typeId == eBlock?.typeId;
        if (this.onLeave) this.onLeave(new EntityLeaveBlockEvent(entity, event.block, block), args);
        entity.setDynamicProperty("mcutils:in_block", Hasher.stringify(eBlock));
      }
    }
  }
  neighborTick(event, args) {
    const direction = BlockUtils.getNeighborUpdate(event);
    if (!direction) return;
    const updateBlock = event.block.offset(DirectionUtils.toOffset(direction));
    if (!updateBlock) return;
    if (this.onNeighborUpdate)
      this.onNeighborUpdate(new NeighborUpdateEvent(event.block, updateBlock, direction), args);
  }
  update(block, args) {
    const event = new NeighborUpdateEvent(block, block);
    if (this.onNeighborUpdate) this.onNeighborUpdate(event, args);
  }
  spawnParticle(block, effectName, location) {
    const loc = location ?? VECTOR3_ZERO;
    const pos = {
      x: block.location.x + 0.5 + loc.x / 16,
      y: block.location.y + loc.y / 16,
      z: block.location.z + 0.5 + loc.z / 16
    };
    block.dimension.spawnParticle(effectName, pos);
  }
  after(block, callback, tickDelay) {
    this.scheduledEvents.add({
      callback,
      block,
      totalTimeLeft: tickDelay,
      timeLeft: tickDelay
    });
  }
  // CUSTOM EVENTS
  /**
   * This function will be called when an entity is nearby.
   * @param {NearbyEntityBlockEvent} event
   */
  onNearbyEntityTick(event, args) {
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/bush.ts
import {
  EntityDamageCause as EntityDamageCause2,
  system as system20
} from "@minecraft/server";
var HarvestLootTable = class _HarvestLootTable {
  growth;
  lootTable;
  constructor(growth, lootTable) {
    this.growth = growth;
    this.lootTable = lootTable;
  }
  static parse(value) {
    const args = value.split(",");
    return new _HarvestLootTable(+args[0], args[1]);
  }
  static parseAll(values) {
    return values.map((x2) => _HarvestLootTable.parse(x2));
  }
};
var BushComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("bush");
  struct = object({
    growth_state: defaulted(string(), "mcutils:growth"),
    loot_tables: optional(array(string()))
  });
  /**
   * Vanilla bush block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  pickBush(event, options) {
    const id = Identifier.parse(event.block);
    const growth = event.block.permutation.getState(options.growth_state);
    const lootTables = HarvestLootTable.parseAll(
      options.loot_tables ?? [`2,${id.namespace}/harvest/${id.path}_2`, `3,${id.namespace}/harvest/${id.path}_3`]
    );
    const { x: x2, y: y2, z: z2 } = event.block.location;
    var success = false;
    for (const lootTable of lootTables) {
      if (lootTable.growth !== growth) continue;
      event.dimension.runCommand(`loot spawn ${x2} ${y2} ${z2} loot "${lootTable.lootTable}"`);
      success = true;
    }
    if (!success) return;
    event.dimension.playSound("block.sweet_berry_bush.pick", event.block.location);
    BlockUtils.setState(event.block, options.growth_state, 1);
  }
  moved(entity) {
    if (system20.currentTick % 10 !== 0) return;
    entity.applyDamage(1, { cause: EntityDamageCause2.contact });
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player || ItemUtils.holding(event.player, "bone_meal")) return;
    this.pickBush(event, options);
  }
  onTick(event, args) {
    this.enterLeaveTick(event, args);
  }
  inBlockTick(event, args) {
    const pos = Vector3Utils.toString(event.entity.location);
    const lastPos = event.entity.getDynamicProperty("mcutils:bush.lastPos") ?? void 0;
    if (pos !== lastPos) {
      event.entity.setDynamicProperty("mcutils:bush.lastPos", pos);
      this.moved(event.entity);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/button.ts
var ButtonComponent = class {
  static componentId = AddonUtils.makeId("button");
  struct = object({
    powered_state: defaulted(string(), "mcutils:powered"),
    delay: optional(number()),
    click_on_sound_event: optional(string()),
    click_off_sound_event: optional(string())
  });
  DELAY = 0;
  /**
   * Vanilla button block behavior.
   */
  constructor() {
    this.onTick = this.onTick.bind(this);
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getSound(block, powered) {
    if (block.hasTag("wood") && block.typeId.includes("cherry")) {
      return powered ? "click_on.cherry_wood_button" : "click_off.cherry_wood_button";
    }
    if (block.hasTag("wood") && block.typeId.includes("bamboo")) {
      return powered ? "click_on.bamboo_wood_button" : "click_off.bamboo_wood_button";
    }
    if (block.hasTag("wood") && block.typeId.includes("crimson") || block.typeId.includes("warped")) {
      return powered ? "click_on.nether_wood_button" : "click_off.nether_wood_button";
    }
    return "random.wood_click";
  }
  getDelay(block, options) {
    return options.delay ?? (block.hasTag("wood") ? 30 : 20);
  }
  // EVENTS
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const delay = event.block.getDynamicProperty("mcutils:delay") ?? 0;
    if (delay > 0) {
      let v2 = delay - 1;
      event.block.setDynamicProperty("mcutils:delay", v2);
      if (v2 == 0) {
        event.dimension.playSound(this.getSound(event.block, false), event.block.location);
        BlockUtils.setState(event.block, options.powered_state, false);
      }
    }
  }
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    const powered = event.block.permutation.getState(options.powered_state);
    const delay = this.getDelay(event.block, options);
    if (!powered) {
      event.block.setDynamicProperty("mcutils:delay", delay);
      event.dimension.playSound(this.getSound(event.block, true), event.block.location);
      return BlockUtils.setState(event.block, options.powered_state, true);
    }
    if (powered) {
      event.block.setDynamicProperty("mcutils:delay", delay);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/cake.ts
import {
  EquipmentSlot as EquipmentSlot7
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/entity/entity_handler.ts
import {
  world as world27
} from "@minecraft/server";
var initialized9 = false;
var EntityHandler = class _EntityHandler {
  static all = /* @__PURE__ */ new Map();
  options;
  entity;
  id;
  constructor(options, handleId) {
    this.options = options;
    this.id = handleId ?? RandomUtils.id(4);
    _EntityHandler.all.set(this.id, this);
    if (!initialized9) init12();
  }
  /**
   * Remove all entities from the world.
   */
  removeAll() {
    this.getEntities().forEach((entity) => entity.remove());
  }
  /**
   * Get all entities from all dimensions
   * @param {EntityQueryOptions} options Additional options
   * @returns {Entity[]}
   */
  getEntities(options) {
    const results = [];
    forAllDimensions((dim) => {
      for (const entity of dim.getEntities({ ...this.options, ...options ?? {} })) {
        results.push(entity);
      }
    });
    return results;
  }
  /**
   * Unregister api events.
   */
  delete() {
    _EntityHandler.all.delete(this.id);
  }
  // CUSTOM EVENTS
  /**
   * Fires when a entity mounts another entity.
   * @param {EntityMountEnterEvent} event
   */
  onMount(event) {
  }
  /**
   * Fires when a entity dismounts another entity.
   * @param {EntityMountExitEvent} event
   */
  onDismount(event) {
  }
  /**
   * Fires when a entity moves.
   * @param {EntityMovedEvent} event
   */
  onMoved(event) {
  }
  // EVENTS
  /**
   * Fires when a entity ticks.
   * @param {EntityTickEvent} event
   */
  onTick(event) {
  }
  /**
   * Fires when a player interacts with a entity.
   * @param {PlayerInteractWithEntityAfterEvent} event
   */
  onInteract(event) {
  }
  /**
   * Fires before a player interacts with an entity.
   * @param {PlayerInteractWithEntityBeforeEvent} event
   */
  onBeforeInteract(event) {
  }
  /**
   * Fires when a entity is removed.
   * @param {EntityRemoveBeforeEvent} event
   */
  onRemove(event) {
  }
  /**
   * Fires when a entity dies.
   * @param {EntityDieAfterEvent} event
   */
  onDie(event) {
  }
  /**
   * Fires when a entity's health has changed.
   * @param {EntityHealthChangedAfterEvent} event
   */
  onHealthChanged(event) {
  }
  /**
   * Fires when a entity hits a block.
   * @param {EntityHitBlockAfterEvent} event
   */
  onHitBlock(event) {
  }
  /**
   *  Fires when this entity hits another entity.
   * @param {EntityHitEntityAfterEvent} event
   */
  onHitEntity(event) {
  }
  /**
   *  Fires when this entity has been hit.
   * @param {EntityHitEntityAfterEvent} event
   */
  onHit(event) {
  }
  /**
   * Fires when a entity is hurt.
   * @param {EntityHurtAfterEvent} event
   */
  onHurt(event) {
  }
  /**
   * Fires when a entity is loaded.
   * @param {EntityLoadAfterEvent} event
   */
  onLoad(event) {
  }
  /**
   * Fires when a entity spawned.
   * @param {EntitySpawnAfterEvent} event
   */
  onSpawn(event) {
  }
  /**
   * Fires when a entity falls on a block.
   * @param {EntityFallOnEvent} event
   */
  onFallOn(event) {
  }
  /**
   * Fires when a entity steps on a block.
   * @param {EntityStepOnEvent} event
   */
  onStepOn(event) {
  }
};
function callHandle(name, entity, event) {
  if (!entity) return;
  for (const handler of EntityHandler.all.values()) {
    if (!entity || !entity.isValid || !entity.matches(handler.options ?? {})) continue;
    const func = handler[name];
    if (!func) continue;
    if (typeof func !== "function") continue;
    func(event);
  }
}
function init12() {
  initialized9 = true;
  EntityEvents.mount.subscribe((event) => {
    callHandle("onMount", event.entity, event);
  });
  EntityEvents.dismount.subscribe((event) => {
    callHandle("onDismount", event.entity, event);
  });
  EntityEvents.moved.subscribe((event) => {
    callHandle("onMoved", event.entity, event);
  });
  EntityEvents.tick.subscribe((event) => {
    callHandle("onTick", event.entity, event);
  });
  EntityEvents.fallOn.subscribe((event) => {
    callHandle("onFallOn", event.entity, event);
  });
  EntityEvents.stepOn.subscribe((event) => {
    callHandle("onStepOn", event.entity, event);
  });
  EntityEvents.stepOff.subscribe((event) => {
    callHandle("onStepOff", event.entity, event);
  });
  world27.afterEvents.playerInteractWithEntity.subscribe((event) => {
    callHandle("onInteract", event.target, event);
  });
  world27.beforeEvents.playerInteractWithEntity.subscribe((event) => {
    callHandle("onBeforeInteract", event.target, event);
  });
  world27.beforeEvents.entityRemove.subscribe((event) => {
    callHandle("onRemove", event.removedEntity, event);
  });
  world27.afterEvents.entityDie.subscribe((event) => {
    callHandle("onDie", event.deadEntity, event);
  });
  world27.afterEvents.entityHealthChanged.subscribe((event) => {
    callHandle("onHealthChanged", event.entity, event);
  });
  world27.afterEvents.entityHitBlock.subscribe((event) => {
    callHandle("onHitBlock", event.damagingEntity, event);
  });
  world27.afterEvents.entityHitEntity.subscribe((event) => {
    callHandle("onHit", event.hitEntity, event);
    callHandle("onHitEntity", event.damagingEntity, event);
  });
  world27.afterEvents.entityHurt.subscribe((event) => {
    callHandle("onHurt", event.hurtEntity, event);
  });
  world27.afterEvents.entityLoad.subscribe((event) => {
    callHandle("onLoad", event.entity, event);
  });
  world27.afterEvents.entitySpawn.subscribe((event) => {
    callHandle("onSpawn", event.entity, event);
  });
}

// node_modules/@lpsmods/mc-utils/src/entity/falling_block_handler.ts
import { ItemStack as ItemStack11 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/entity/specific_entity_handler.ts
import { world as world28 } from "@minecraft/server";
var SpecificEntityHandler = class extends EntityHandler {
  constructor(entity) {
    super({ type: entity.typeId, tags: [entity.id] }, entity.id);
    entity.addTag(entity.id);
    this.onRemove = this.onRemove.bind(this);
  }
  onRemove(event) {
    super.delete();
  }
  delete() {
    super.delete();
    const entity = world28.getEntity(this.id);
    if (!entity) return;
    entity.remove();
  }
};

// node_modules/@lpsmods/mc-utils/src/entity/falling_block_handler.ts
var FallingBlockEvent = class {
  constructor(block, beforePermutation, entity) {
    this.block = block;
    this.beforePermutation = beforePermutation;
    this.entity = entity;
    this.cancel = false;
  }
  block;
  beforePermutation;
  entity;
  cancel;
};
var FallingBlockHandler = class _FallingBlockHandler extends SpecificEntityHandler {
  blockId;
  component;
  args;
  constructor(component, args, entity, blockId) {
    super(entity);
    this.component = component;
    this.args = args;
    this.blockId = blockId;
    this.onFallOn = this.onFallOn.bind(this);
  }
  static create(component, args, block, entityId) {
    const pos = Vector3Utils.add(block.location, CENTER_ENTITY);
    const before = block.permutation;
    const blockId = block.typeId;
    block.setType("air");
    const entity = block.dimension.spawnEntity(entityId, pos);
    try {
      entity.triggerEvent(blockId);
    } catch (err) {
    }
    const handler = new _FallingBlockHandler(component, args, entity, blockId);
    const fallEvent = new FallingBlockEvent(block, before, entity);
    if (component.onFall) component.onFall(fallEvent, args);
    if (fallEvent.cancel) {
      handler.delete();
      return void 0;
    }
    return handler;
  }
  onFallOn(event) {
    const block = event.entity.dimension.getBlock(event.entity.location);
    if (!block || !block.isAir) return this.drop(event);
    const before = block.permutation;
    block.setType(this.blockId);
    const fallEvent = new FallingBlockEvent(block, before, event.entity);
    if (this.component.onLand) this.component.onLand(fallEvent, this.args);
    if (fallEvent.cancel) {
      block.setPermutation(before);
      return;
    }
    event.entity.remove();
    this.delete();
  }
  drop(event) {
    const stack = new ItemStack11(this.blockId);
    event.entity.dimension.spawnItem(stack, event.entity.location);
    event.entity.remove();
    this.delete();
  }
};

// node_modules/@lpsmods/mc-utils/src/entity/player_handler.ts
import {
  world as world29
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/entity/text_display.ts
import {
  system as system21
} from "@minecraft/server";
import { ModalFormData as ModalFormData2, ActionFormData as ActionFormData2 } from "@minecraft/server-ui";

// node_modules/@lpsmods/mc-utils/src/entity/utils.ts
import { ItemLockMode } from "@minecraft/server";
var EntityUtils = class {
  /**
   * Drops all items in the entities inventory.
   * @param {Entity} entity
   * @param {Vector3} location
   * @returns {boolean}
   */
  static dropAll(entity, location) {
    const container = entity.getComponent("inventory")?.container;
    if (!container) return false;
    for (let slot = 0; slot < container.size; slot++) {
      const itemStack = container.getItem(slot);
      if (!itemStack || itemStack.lockMode !== ItemLockMode.none) continue;
      entity.dimension.spawnItem(itemStack, location ?? entity.location);
    }
    return true;
  }
  /**
   * Get the direction the entity is facing.
   * @param {Entity} entity
   * @returns {Direction}
   */
  static getFacingDirection(entity) {
    return DirectionUtils.rot2dir(entity.getRotation());
  }
  /**
   * Remove all entities from all dimensions that match options.
   * @param {EntityQueryOptions} options
   */
  static removeAll(options) {
    forAllDimensions((dim) => dim.getEntities(options).forEach((entity) => entity.remove()));
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/cake.ts
var CakeInteraction = class _CakeInteraction {
  item;
  block;
  constructor(item, block) {
    this.item = item;
    this.block = block;
  }
  static parse(value) {
    const args = value.split("->");
    return new _CakeInteraction(args[0], args[1]);
  }
  static parseAll(interactions) {
    return interactions.map((x2) => _CakeInteraction.parse(x2));
  }
};
var CakeComponent = class {
  static componentId = AddonUtils.makeId("cake");
  struct = object({
    slice_state: defaulted(string(), "mcutils:slices"),
    max_slices: defaulted(number(), 6),
    interactions: defaulted(array(string()), []),
    nutrition: defaulted(number(), 2),
    saturation_modifier: defaulted(number(), 0)
  });
  SLICES = 6;
  /**
   * Vanilla cake block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  placeBlock(event, options) {
    if (!event.player) return false;
    const SLICES = event.block.permutation.getState(options.slice_state);
    if (SLICES != 0) {
      return false;
    }
    const equ = event.player.getComponent("equippable");
    if (!equ) return false;
    const mainhand = equ.getEquipment(EquipmentSlot7.Mainhand);
    if (!mainhand) {
      return false;
    }
    const actions = CakeInteraction.parseAll(options.interactions);
    let interaction = actions.find((x2) => mainhand.matches(x2.item));
    if (interaction) {
      event.dimension.playSound("cake.add_candle", event.block.location);
      event.dimension.setBlockType(event.block.location, interaction.block);
      ItemUtils.decrementStack(event.player, EquipmentSlot7.Mainhand);
      return true;
    }
    return false;
  }
  eat(event, options) {
    if (!event.player) return;
    if (!PlayerUtils.canEat(event.player)) return;
    PlayerUtils.eat(event.player, options.nutrition, options.saturation_modifier);
    var slice = event.block.permutation.getState(options.slice_state);
    if (slice === options.max_slices) {
      return event.dimension.setBlockType(event.block.location, "air");
    }
    event.block.setPermutation(event.block.permutation.withState(options.slice_state, slice + 1));
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!this.placeBlock(event, options)) {
      this.eat(event, options);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/candle_cake.ts
import {
  BlockPermutation as BlockPermutation9,
  ItemStack as ItemStack12,
  system as system22
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/validation.ts
import {
  BlockType as BlockType12,
  BlockTypes as BlockTypes9,
  DimensionType as DimensionType2,
  DimensionTypes as DimensionTypes3,
  EffectType as EffectType3,
  EffectTypes as EffectTypes2,
  EnchantmentType as EnchantmentType4,
  EnchantmentTypes as EnchantmentTypes3,
  EntityType as EntityType4,
  EntityTypes as EntityTypes3,
  ItemType as ItemType4,
  ItemTypes as ItemTypes3
} from "@minecraft/server";
var isBlock = define("BlockType", (value) => {
  return BlockTypes9.get(value instanceof BlockType12 ? value.id : value) !== void 0;
});
var isItem = define("ItemType", (value) => {
  return ItemTypes3.get(value instanceof ItemType4 ? value.id : value) !== void 0;
});
var isEntity = define("EntityType", (value) => {
  return EntityTypes3.get(value instanceof EntityType4 ? value.id : value) !== void 0;
});
var isEffect = define("EffectType", (value) => {
  return EffectTypes2.get(value instanceof EffectType3 ? value.getName() : value) !== void 0;
});
var isEnchant = define("EnchantmentType", (value) => {
  return EnchantmentTypes3.get(value instanceof EnchantmentType4 ? value.id : value) !== void 0;
});
var isDimension = define("DimensionType", (value) => {
  return DimensionTypes3.get(value instanceof DimensionType2 ? value.typeId : value) !== void 0;
});
var vec3 = define("Vector3", (value) => {
  return Array.isArray(value) && value.length >= 3 && value.length <= 3;
});
var vec2 = define("Vector2", (value) => {
  return Array.isArray(value) && value.length >= 2 && value.length <= 2;
});
var entityFilterPropertyOptions = object({
  propertyId: string(),
  exclude: optional(boolean()),
  value: optional(string())
});
var entityFilterScoreOptions = object({
  exclude: optional(boolean()),
  maxScore: optional(number()),
  minScore: optional(number()),
  objective: optional(string())
});
var entityFilter = object({
  excludeFamilies: optional(array(string())),
  excludeGameModes: optional(array(string())),
  excludeNames: optional(array(string())),
  excludeTags: optional(array(string())),
  excludeTypes: optional(array(string())),
  families: optional(array(string())),
  gameMode: optional(string()),
  maxHorizontalRotation: optional(number()),
  maxLevel: optional(number()),
  maxVerticalRotation: optional(number()),
  minHorizontalRotation: optional(number()),
  minLevel: optional(number()),
  minVerticalRotation: optional(number()),
  name: optional(string()),
  propertyOptions: optional(array(entityFilterPropertyOptions)),
  scoreOptions: optional(array(entityFilterScoreOptions)),
  tags: optional(array(string())),
  type: optional(string())
});
var entityQuery = assign(
  entityFilter,
  object({
    closest: optional(number()),
    farthest: optional(number()),
    location: optional(vec3),
    maxDistance: optional(number()),
    minDistance: optional(number()),
    volume: optional(vec3)
  })
);

// node_modules/@lpsmods/mc-utils/src/blockcomponent/candle_cake.ts
var CandleCakeComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("candle_cake");
  struct = object({
    candle: isItem,
    lit_state: defaulted(string(), "mcutils:lit"),
    slice_state: defaulted(string(), "mcutils:slices"),
    block: optional(isBlock),
    flame_position: defaulted(vec3, [0, 16, 0]),
    flame_particle: defaulted(string(), "minecraft:candle_flame_particle")
  });
  /**
   * Vanilla candle cake block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
    this.onTick = this.onTick.bind(this);
  }
  // Remove the "color" parts.
  getCakeBlock(block, options) {
    return options.block ?? TextUtils.stripAll(block.typeId, CANDLES, void 0, "_");
  }
  getCandleItem(block, options) {
    if (options.candle) return options.candle;
    const id = Identifier.parse(block);
    for (const color of COLORS) {
      let colorCandle = `${color}_candle`;
      let candleColor = `candle_${color}`;
      if (id.path.includes(colorCandle) || id.path.includes(candleColor)) return colorCandle;
    }
    return "candle";
  }
  setLit(event, value = true, options) {
    event.block.setPermutation(event.block.permutation.withState(options.lit_state, value));
  }
  eat(event, options) {
    if (!event.player) return;
    event.player.addEffect("saturation", 100, {
      amplifier: 0,
      showParticles: false
    });
    event.block.dimension.spawnItem(new ItemStack12(options.candle), event.block.center());
    const BLOCK = BlockPermutation9.resolve(this.getCakeBlock(event.block, options));
    event.block.setPermutation(BLOCK.withState(options.slice_state, 1));
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    const LIT = event.block.permutation.getState(options.lit_state);
    if (!event.player) return;
    const bl = ItemUtils.holding(event.player, "#ignitable");
    if (bl) {
      this.setLit(event, true, options);
      return true;
    }
    if (LIT && !bl) {
      this.setLit(event, false, options);
    } else {
      this.eat(event, options);
    }
  }
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const lit = event.block.permutation.getState(options.lit_state);
    if (!lit) return;
    if (system22.currentTick % 40 === 0) {
      const pos = options.flame_position;
      event.dimension.spawnParticle(
        options.flame_particle,
        Vector3Utils.add(event.block.location, {
          x: 0.5 + pos[0] / 16,
          y: pos[1] / 16,
          z: 0.5 + pos[2] / 16
        })
      );
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/candle.ts
import {
  EquipmentSlot as EquipmentSlot8,
  system as system23
} from "@minecraft/server";
var CandleFlamePosition = class _CandleFlamePosition {
  candles;
  location;
  constructor(candles, location) {
    this.candles = candles;
    this.location = location;
  }
  static parse(value) {
    const args = value.split(",");
    return new _CandleFlamePosition(+args[0], {
      x: +args[1],
      y: +args[2],
      z: +args[3]
    });
  }
  static parseAll(positions) {
    return positions.map((x2) => _CandleFlamePosition.parse(x2));
  }
};
var CandleComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("candle");
  struct = object({
    candles_state: defaulted(string(), "mcutils:candles"),
    lit_state: defaulted(string(), "mcutils:lit"),
    max_candles: defaulted(number(), 4),
    item: optional(isItem),
    flame_particle: defaulted(string(), "minecraft:candle_flame_particle"),
    flame_positions: defaulted(array(vec3), [0, 0, 0])
  });
  /**
   * Vanilla candle block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
    this.onTick = this.onTick.bind(this);
  }
  getCandleItem(block, options) {
    return options.item ?? block.typeId;
  }
  getSound(block) {
    return "use.candle";
  }
  #defaultFlames() {
    return CandleFlamePosition.parseAll([
      "1,0,8,0",
      "2,2,8,-1",
      "2,-2,7,0",
      "3,1,8,-1",
      "3,-2,7,0",
      "3,0,5,2",
      "4,1,8,-2",
      "4,-2,7,-2",
      "4,2,7,1",
      "4,-1,5,1"
    ]);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const lit = event.block.permutation.getState(options.lit_state);
    const count = event.block.permutation.getState(options.candles_state);
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    const mainhand = equ.getEquipment(EquipmentSlot8.Mainhand);
    if (count < options.max_candles && mainhand && mainhand.matches(this.getCandleItem(event.block, options))) {
      event.dimension.playSound(this.getSound(event.block), event.block.location);
      BlockUtils.incrementState(event.block, options.candles_state);
      ItemUtils.decrementStack(event.player, EquipmentSlot8.Mainhand);
      return;
    }
    if (!lit && mainhand && ItemUtils.matches(mainhand, "#ignitable")) {
      BlockUtils.setState(event.block, options.lit_state, true);
      ItemUtils.usedIgnitable(event.player, mainhand, event.block.location);
      return;
    }
    if (lit && !mainhand) {
      event.dimension.playSound("extinguish.candle", event.block.location);
      BlockUtils.setState(event.block, options.lit_state, false);
      return;
    }
  }
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const lit = event.block.permutation.getState(options.lit_state);
    if (!lit) return;
    const positions = options.flame_positions ? CandleFlamePosition.parseAll(options.flame_positions) : this.#defaultFlames();
    const candles = event.block.permutation.getState(options.candles_state);
    if (system23.currentTick % 40 === 0) {
      for (const pos of positions) {
        if (pos.candles !== candles) continue;
        this.spawnParticle(event.block, options.flame_particle, pos.location);
      }
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/cauldron.ts
import {
  ItemStack as ItemStack13,
  EquipmentSlot as EquipmentSlot9,
  BlockPermutation as BlockPermutation11
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/parser.ts
import { BlockPermutation as BlockPermutation10 } from "@minecraft/server";
var Parser = class {
  // stone_slab["minecraft:vertical_half"="top"]
  static parseBlockPermutation(value) {
    const match = value.match(/^([^\[\]]+)(?:\[(.+)\])?$/);
    if (!match) throw new Error("Invalid input format");
    const block = match[1];
    const statesStr = match[2];
    const states = {};
    if (statesStr) {
      for (const pair of statesStr.split(",")) {
        const [key, value2] = pair.split("=");
        if (key && value2) {
          let v2 = value2.trim();
          if (Number.isInteger(v2)) v2 = +v2;
          if (v2 === "true") v2 = true;
          if (v2 === "false") v2 = false;
          states[key.trim()] = v2;
        }
      }
    }
    return BlockPermutation10.resolve(block, states);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/cauldron.ts
var CauldronInteraction = class _CauldronInteraction {
  constructor(item, blockPermutation, resultItem) {
    this.item = item;
    this.resultItem = resultItem;
    this.blockPermutation = blockPermutation;
  }
  resultItem;
  item;
  blockPermutation;
  getResultStack() {
    return this.resultItem ? new ItemStack13(this.resultItem) : new ItemStack13("air");
  }
  static parse(value) {
    const args = value.split("->");
    const item = args[0];
    const perm = Parser.parseBlockPermutation(args[1]);
    const resultItem = args[2];
    if (!perm) return new _CauldronInteraction(item, BlockPermutation11.resolve("water_cauldron"), resultItem);
    return new _CauldronInteraction(item, perm, resultItem);
  }
  static parseAll(values) {
    if (!values) return [];
    return values.map((x2) => _CauldronInteraction.parse(x2));
  }
};
var CauldronComponent = class {
  static componentId = AddonUtils.makeId("cauldron");
  struct = object({
    interactions: array(string())
  });
  /**
   * Vanilla cauldron block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getInteraction(itemStack, options) {
    const actions = CauldronInteraction.parseAll(options.interactions);
    for (const action of actions) {
      if (itemStack.matches(action.item)) return action;
    }
  }
  update(event) {
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    const mainhand = equ.getEquipment(EquipmentSlot9.Mainhand);
    if (!mainhand) return;
    let interaction = this.getInteraction(mainhand, options);
    if (!interaction) return;
    event.block.setPermutation(interaction.blockPermutation);
    ItemUtils.convert(event.player, EquipmentSlot9.Mainhand, interaction.getResultStack());
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/concrete_powder.ts
var ConcretePowderComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("concrete_powder");
  struct = object({
    block: optional(isBlock)
  });
  /**
   * Vanilla concrete powder block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  hasWater(block) {
    let north = block.north();
    if (north && north.hasTag("water")) return true;
    let south = block.south();
    if (south && south.hasTag("water")) return true;
    let east = block.east();
    if (east && east.hasTag("water")) return true;
    let west = block.west();
    if (west && west.hasTag("water")) return true;
    let above = block.above();
    if (above && above.hasTag("water")) return true;
    let below = block.below();
    if (below && below.hasTag("water")) return true;
    return false;
  }
  getConcreteBlock(block, options) {
    return options.block ?? block.typeId.replace("_powder", "");
  }
  // EVENTS
  onTick(event, args) {
    const options = create(args.params, this.struct);
    if (!this.hasWater(event.block)) return;
    BlockUtils.setType(event.block, this.getConcreteBlock(event.block, options));
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/copper_bulb.ts
var CopperBulbComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("copper_bulb");
  struct = object({
    lit_state: defaulted(string(), "mcutils:lit"),
    powered_state: defaulted(string(), "mcutils:powered")
  });
  /**
   * Vanilla copper bulb block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  // EVENTS
  onTick(event, args) {
    super.baseTick(event, args);
  }
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    const lit = event.block.permutation.getState(options.lit_state);
    let level = event.sourceBlock.getRedstonePower();
    if (level === void 0) return;
    if (level === 0) {
      return BlockUtils.setState(event.block, options.powered_state, false);
    }
    BlockUtils.setState(event.block, options.powered_state, true);
    BlockUtils.setState(event.block, options.lit_state, !lit);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/coral.ts
var CoralComponent = class _CoralComponent {
  static componentId = AddonUtils.makeId("coral");
  struct = object({
    delay: defaulted(number(), 60),
    block: optional(isBlock)
  });
  static CACHE = new LRUCache();
  /**
   * Vanilla coral block behavior.
   */
  constructor() {
    this.onTick = this.onTick.bind(this);
  }
  getDeadCoralBlock(block, options) {
    return options.block ?? _CoralComponent.CACHE.getOrCompute(block.typeId, (key) => {
      const id = Identifier.parse(key);
      return id.prefix("dead_").toString();
    });
  }
  hasWater(block) {
    let north = block.north();
    if (north && north.hasTag("water")) return true;
    let south = block.south();
    if (south && south.hasTag("water")) return true;
    let east = block.east();
    if (east && east.hasTag("water")) return true;
    let west = block.west();
    if (west && west.hasTag("water")) return true;
    let above = block.above();
    if (above && above.hasTag("water")) return true;
    let below = block.below();
    if (below && below.hasTag("water")) return true;
    return false;
  }
  killBlock(block, options) {
    const blk = this.getDeadCoralBlock(block, options);
    BlockUtils.setType(block, blk);
  }
  // EVENTS
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const blk = event.block;
    const water = this.hasWater(blk);
    let delay = blk.getDynamicProperty("mcutils:delay") ?? 0;
    if (water && delay != 0) {
      blk.setDynamicProperty("mcutils:delay", 0);
      return;
    }
    if (!water && delay == 0) {
      blk.setDynamicProperty("mcutils:delay", options.delay);
      return;
    }
    if (delay > 0) {
      delay--;
      if (delay <= 0) {
        this.killBlock(event.block, options);
      }
      return blk.setDynamicProperty("mcutils:delay", delay);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/crop.ts
var CropComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("crop");
  struct = object({
    growth_state: defaulted(string(), "mcutils:growth"),
    max_stage: defaulted(number(), 7)
  });
  /**
   * Vanilla crop block behavior.
   */
  constructor() {
    super();
    this.onRandomTick = this.onRandomTick.bind(this);
  }
  getGrowthAmount(event) {
    return RandomUtils.int(2, 5);
  }
  applyGrowth(event, args) {
    const options = create(args.params, this.struct);
    var state = event.block.permutation.getState(options.growth_state);
    var i2 = state + this.getGrowthAmount(event);
    event.block.setPermutation(
      event.block.permutation.withState(options.growth_state, clampNumber(i2, 0, options.max_stage))
    );
    this.update(event.block, args);
  }
  grow(event, args) {
    this.applyGrowth(event, args);
  }
  // EVENTS
  onRandomTick(event, args) {
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/cross_collision.ts
var CrossCollisionComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("cross_collision");
  struct = object({
    north_state: defaulted(string(), "mcutils:north"),
    east_state: defaulted(string(), "mcutils:east"),
    south_state: defaulted(string(), "mcutils:south"),
    west_state: defaulted(string(), "mcutils:west")
  });
  /**
   * Fence, Iron bars, and glass pane like behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
    this.onPlace = this.onPlace.bind(this);
  }
  isAttachable(block) {
    return !block.isAir && !block.hasTag("non_full");
  }
  // EVENTS
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    if (!event.direction) return;
    if (this.isAttachable(event.sourceBlock)) {
      switch (event.direction.toLowerCase()) {
        case "north":
          return BlockUtils.setState(event.block, options.north_state, true);
        case "east":
          return BlockUtils.setState(event.block, options.east_state, true);
        case "south":
          return BlockUtils.setState(event.block, options.south_state, true);
        case "west":
          return BlockUtils.setState(event.block, options.west_state, true);
      }
    }
    switch (event.direction.toLowerCase()) {
      case "north":
        return BlockUtils.setState(event.block, options.north_state, false);
      case "east":
        return BlockUtils.setState(event.block, options.east_state, false);
      case "south":
        return BlockUtils.setState(event.block, options.south_state, false);
      case "west":
        return BlockUtils.setState(event.block, options.west_state, false);
    }
  }
  onTick(event, args) {
    this.baseTick(event, args);
  }
  onPlace(event, args) {
    this.basePlace(event, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/debug.ts
var DebugBlockComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("debug");
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  onPlayerInteract(event, args) {
    if (!event.player) return;
    event.player.sendMessage(JSON.stringify(event.block.permutation.getAllStates(), null, 2));
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/falling_block.ts
import {
  Direction as Direction5
} from "@minecraft/server";
var FallingBlockComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("falling_block");
  struct = object({
    entity: isEntity
  });
  /**
   * Vanilla falling block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
    this.onPlace = this.onPlace.bind(this);
  }
  fall(block, args) {
    const options = create(args.params, this.struct);
    FallingBlockHandler.create(this, args, block, options.entity);
  }
  // EVENTS
  onNeighborUpdate(event, args) {
    if (event.direction !== Direction5.Down) return;
    if (!event.sourceBlock.isAir) return;
    this.fall(event.block, args);
  }
  onTick(event, args) {
    this.baseTick(event, args);
  }
  onPlace(event, args) {
    const down = event.block.below();
    if (!down || !down.isAir) return;
    this.fall(event.block, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/farmland.ts
var FarmlandComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("farmland");
  struct = object({
    moisture_state: defaulted(string(), "mcutils:moisture"),
    block: defaulted(isBlock, "dirt"),
    max_moisture: defaulted(number(), 7),
    moist_block: defaulted(string(), "#water")
  });
  delay = 0;
  /**
   * Vanilla farmland block behavior.
   */
  constructor() {
    super();
    this.onRandomTick = this.onRandomTick.bind(this);
    this.onEntityFallOn = this.onEntityFallOn.bind(this);
  }
  isMoist(block, options) {
    for (let x2 = -5; x2 < 5; x2++) {
      for (let y2 = -1; y2 < 1; y2++) {
        for (let z2 = -5; z2 < 5; z2++) {
          const blk = block.offset({ x: x2, y: y2, z: z2 });
          if (blk && BlockUtils.matches(blk, options.moist_block)) return true;
        }
      }
    }
    return false;
  }
  // EVENTS
  onRandomTick(event, args) {
    const options = create(args.params, this.struct);
    const moisture = event.block.permutation.getState(options.moisture_state);
    const water = this.isMoist(event.block, options);
    if (water && moisture < options.max_moisture) {
      BlockUtils.setState(event.block, options.moisture_state, moisture + 1);
      return;
    }
    if (!water && moisture > 0) {
      BlockUtils.setState(event.block, options.moisture_state, moisture - 1);
      return;
    }
    if (!water && moisture == 0) {
      if (this.delay == 0) {
        this.delay = 1;
      } else {
        this.delay--;
        if (this.delay == 0) {
          BlockUtils.setType(event.block, options.block);
        }
      }
      return;
    }
  }
  onEntityFallOn(event, args) {
    const options = create(args.params, this.struct);
    if (event.fallDistance > 1) {
      BlockUtils.setType(event.block, options.block);
      return;
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/toggleable.ts
var ToggleableComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("toggleable");
  struct = object({
    toggle_state: defaulted(string(), "mcutils:open"),
    true_sound_event: defaulted(string(), "use.stone"),
    false_sound_event: defaulted(string(), "use.stone"),
    toggled_by_redstone: defaulted(boolean(), false)
  });
  /**
   * Toggleable block state behavior. (like; doors, trapdoors)
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getSound(open = false, args) {
    const options = create(args.params, this.struct);
    if (open) {
      return options.true_sound_event;
    }
    return options.false_sound_event;
  }
  toggle(block, args) {
    const options = create(args.params, this.struct);
    const bool = BlockUtils.toggleState(block, options.toggle_state);
    block.dimension.playSound(this.getSound(bool, args), block.location);
    this.update(block, args);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    this.toggle(event.block, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/fence_gate.ts
var FenceGateComponent = class extends ToggleableComponent {
  static componentId = AddonUtils.makeId("fence_gate");
  /**
   * Fence gate block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
    this.onTick = this.onTick.bind(this);
    this.onPlace = this.onPlace.bind(this);
    this.struct = assign(
      this.struct,
      object({
        in_wall_state: defaulted(string(), "mcutils:in_wall"),
        direction_state: defaulted(string(), "minecraft:cardinal_direction")
      })
    );
  }
  // EVENTS
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    const axis = DirectionUtils.toAxis(event.block.permutation.getState(options.direction_state));
    let inWall = false;
    switch (axis) {
      case "x":
        const e2 = event.block.east();
        const w = event.block.west();
        inWall = (BlockUtils.isWall(e2) || BlockUtils.isWall(w)) ?? false;
        break;
      case "z":
        const n2 = event.block.north();
        const s2 = event.block.south();
        inWall = (BlockUtils.isWall(n2) || BlockUtils.isWall(s2)) ?? false;
        break;
    }
    BlockUtils.setState(event.block, options.in_wall_state, inWall);
  }
  onTick(event, args) {
    this.baseTick(event, args);
  }
  onPlace(event, args) {
    this.basePlace(event, args);
  }
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (event.player) {
      const dir = event.block.permutation.getState(options.direction_state);
      const origin = event.player.location;
      const target = Vector3Utils.add(event.block.location, CENTER_ENTITY);
      const dir2 = DirectionUtils.relDir(origin, target)?.toString().toLowerCase();
      if (dir !== dir2) {
        BlockUtils.setState(event.block, options.direction_state, DirectionUtils.getOpposite(dir).toLowerCase());
      }
    }
    super.onPlayerInteract(event, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/fertilizable.ts
import {
  EquipmentSlot as EquipmentSlot10,
  GameMode as GameMode5
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/blockcomponent/sapling.ts
var SaplingComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("sapling");
  struct = object({
    growth_state: defaulted(string(), "mcutils:growth"),
    max_stage: defaulted(number(), 2),
    feature: defaulted(string(), "minecraft:oak_tree_feature")
  });
  /**
   * Vanilla sapling block behavior.
   */
  constructor() {
    super();
    this.onRandomTick = this.onRandomTick.bind(this);
  }
  getFeature(block, options) {
    return options.feature;
  }
  // EVENTS
  grow(event, args) {
    const options = create(args.params, this.struct);
    const STAGE = event.block.permutation.getState(options.growth_state);
    if (STAGE == 0) {
      BlockUtils.incrementState(event.block, options.growth_state);
      this.update(event.block, args);
      return;
    }
    const perm = event.block.permutation;
    event.block.setType("air");
    let bool = event.dimension.placeFeature(this.getFeature(event.block, options), event.block.location, false);
    if (!bool) {
      event.block.setPermutation(perm);
    }
  }
  onRandomTick(event, args) {
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/fertilizable.ts
var FertilizableComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("fertilizable");
  struct = object({
    growth_state: defaulted(string(), "mcutils:growth"),
    max_stage: defaulted(number(), 7),
    items: defaulted(array(string()), ["bone_meal"])
  });
  /**
   * Vanilla fertilizable block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getMaxStage(block, options) {
    const com = block.getComponent(CropComponent.componentId) ?? block.getComponent(SaplingComponent.componentId);
    if (!com) return options.max_stage ?? 7;
    return com.customComponentParameters.params.max_stage ?? 7;
  }
  getGrowthState(block, options) {
    const com = block.getComponent(CropComponent.componentId) ?? block.getComponent(SaplingComponent.componentId);
    if (!com) return options.growth_state ?? "mcutils:growth";
    return com.customComponentParameters.params.growth_state ?? "mcutils:growth";
  }
  fertilize(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return false;
    if (!this.isFertilizable(event, options)) return false;
    if (!this.canGrow(event, options)) return false;
    var pos = Vector3Utils.add(event.block.location, {
      x: 0.5,
      y: 0.5,
      z: 0.5
    });
    event.dimension.spawnParticle("minecraft:crop_growth_emitter", pos);
    event.dimension.playSound("item.bone_meal.use", pos);
    this.grow(event, args);
    if (event.player.getGameMode() === GameMode5.Survival) {
      ItemUtils.decrementStack(event.player, EquipmentSlot10.Mainhand);
    }
    return true;
  }
  isFertilizable(event, options) {
    if (!event.player) return false;
    const equ = event.player.getComponent("equippable");
    if (!equ) return false;
    const mainhand = equ.getEquipment(EquipmentSlot10.Mainhand);
    if (!mainhand || !ItemUtils.matchAny(mainhand, options.items)) return false;
    return true;
  }
  // TODO: Check light level
  canGrow(event, options) {
    const growthName = this.getGrowthState(event.block, options);
    const growthState = event.block.permutation.getState(growthName);
    return growthState <= this.getMaxStage(event.block, options);
  }
  getGrowthAmount(event) {
    return RandomUtils.int(2, 5);
  }
  grow(event, args) {
    const options = create(args.params, this.struct);
    const growthName = this.getGrowthState(event.block, options);
    const maxStage = this.getMaxStage(event.block, options);
    if (event.player) {
      if (event.player.getGameMode() === GameMode5.Creative) {
        BlockUtils.setState(event.block, growthName, maxStage);
        this.update(event.block, args);
        return;
      }
    }
    const growthState = event.block.permutation.getState(growthName);
    const i2 = growthState + this.getGrowthAmount(event);
    BlockUtils.setState(event.block, growthName, clampNumber(i2, 0, maxStage));
    this.update(event.block, args);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    return this.fertilize(event, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/flower_bed.ts
import {
  EquipmentSlot as EquipmentSlot11
} from "@minecraft/server";
var FlowerBedComponent = class {
  static componentId = AddonUtils.makeId("flower_bed");
  struct = object({
    flowers_state: defaulted(string(), "mcutils:flowers"),
    max_flowers: defaulted(number(), 4)
  });
  /**
   * Vanilla flower bed block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const flowers = event.block.permutation.getState(options.flowers_state);
    if (flowers >= options.max_flowers) return;
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    const itemStack = equ.getEquipment(EquipmentSlot11.Mainhand);
    if (!itemStack || itemStack.matches(event.block.typeId)) return;
    BlockUtils.incrementState(event.block, options.flowers_state);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/frosted_ice.ts
var FrostedIceComponent = class {
  static componentId = AddonUtils.makeId("frosted_ice");
  struct = object({
    age_state: defaulted(string(), "mcutils:age"),
    max_age: defaulted(number(), 7),
    converts_to: defaulted(isBlock, "water")
  });
  /**
   * Vanilla frosted ice block behavior.
   */
  constructor() {
    this.onRandomTick = this.onRandomTick.bind(this);
  }
  freeze(block, options) {
    const age = block.permutation.getState(options.age_state);
    if (age === 0) return;
    BlockUtils.decrementState(block, options.age_state);
  }
  thaw(block, options) {
    const age = block.permutation.getState(options.age_state);
    if (age === options.max_age) {
      return block.setType(options.converts_to);
    }
    BlockUtils.incrementState(block, options.age_state);
  }
  // EVENTS
  onRandomTick(event, args) {
    const options = create(args.params, this.struct);
    this.thaw(event.block, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/height.ts
import {
  EquipmentSlot as EquipmentSlot12,
  Direction as Direction6
} from "@minecraft/server";
var HeightComponent = class {
  static componentId = AddonUtils.makeId("height");
  struct = object({
    layers_state: defaulted(string(), "mcutils:layers"),
    max_layers: defaulted(number(), 8)
  });
  /**
   * Vanilla snow layer block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  canBeIncreased(event, options) {
    if (!event.player) return false;
    const state = event.block.permutation;
    const stack = event.player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot12.Mainhand);
    if (!stack) {
      return false;
    }
    const layers = state.getState(options.layers_state);
    return layers < options.max_layers && stack.typeId === event.block.getItemStack()?.typeId && (state.getState("minecraft:vertical_half") == "top" && event.face === Direction6.Down || state.getState("minecraft:vertical_half") == "bottom" && event.face === Direction6.Up);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const state = event.block.permutation;
    const layers = state.getState(options.layers_state);
    const newLayers = layers + 1;
    if (this.canBeIncreased(event, options)) {
      event.player.dimension.playSound(getInteractSound(event.block), event.block.location);
      event.block.setPermutation(state.withState(options.layers_state, newLayers));
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/lava_cauldron.ts
import {
  ItemStack as ItemStack14,
  EquipmentSlot as EquipmentSlot13,
  BlockPermutation as BlockPermutation12
} from "@minecraft/server";
var LavaCauldronInteraction = class _LavaCauldronInteraction {
  constructor(item, resultItem) {
    this.item = item;
    this.resultItem = resultItem;
  }
  item;
  resultItem;
  getResultStack() {
    return new ItemStack14(this.resultItem);
  }
  static parse(value) {
    const args = value.split("->");
    const item = args[0];
    const block = args[1];
    return new _LavaCauldronInteraction(item, block);
  }
  static parseAll(values) {
    if (!values) return [];
    return values.map((x2) => _LavaCauldronInteraction.parse(x2));
  }
};
var LavaCauldronComponent = class {
  static componentId = AddonUtils.makeId("lava_cauldron");
  struct = object({
    block: defaulted(isBlock, "cauldron"),
    interactions: defaulted(array(string()), [])
  });
  /**
   * Vanilla "lava" cauldron block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getInteraction(itemStack, options) {
    for (const action of LavaCauldronInteraction.parseAll(options.interactions)) {
      if (!action) continue;
      if (itemStack.matches(action.item)) {
        return action;
      }
    }
    return void 0;
  }
  update(event) {
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    const mainhand = equ.getEquipment(EquipmentSlot13.Mainhand);
    if (!mainhand) return;
    let interaction = this.getInteraction(mainhand, options);
    if (!interaction) return;
    ItemUtils.convert(event.player, EquipmentSlot13.Mainhand, interaction.getResultStack());
    event.block.setPermutation(BlockPermutation12.resolve(options.block, event.block.permutation.getAllStates()));
    this.update(event);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/layered_cauldron.ts
import {
  ItemStack as ItemStack15,
  EquipmentSlot as EquipmentSlot14,
  BlockPermutation as BlockPermutation13
} from "@minecraft/server";
var LayeredCauldronInteraction = class _LayeredCauldronInteraction {
  constructor(input, output, level) {
    this.input = input;
    this.output = output;
    this.level = level;
  }
  input;
  output;
  level;
  getOutputStack() {
    return new ItemStack15(this.output);
  }
  getBlock(block, options) {
    let level = block.permutation.getState(options.level_state);
    switch (this.level.charAt(0)) {
      case "+":
        level = level + +this.level.slice(1);
        break;
      case "-":
        level = level - +this.level.slice(1);
        break;
      default:
        level = +this.level;
        break;
    }
    return level < 1 ? BlockPermutation13.resolve(options.block) : block.permutation.withState(options.level_state, level);
  }
  static parse(value) {
    const args = value.split("->");
    const input = args[0];
    const args2 = args[1].split(",");
    const output = args2[0];
    const level = args2[1];
    return new _LayeredCauldronInteraction(input, output, level);
  }
  static parseAll(values) {
    if (!values) return [];
    return values.map((x2) => _LayeredCauldronInteraction.parse(x2));
  }
};
var LayeredCauldronComponent = class {
  static componentId = AddonUtils.makeId("layered_cauldron");
  struct = object({
    block: defaulted(isBlock, "cauldron"),
    level_state: defaulted(string(), "mcutils:level"),
    max_level: defaulted(number(), 3),
    interactions: defaulted(array(string()), [])
  });
  /**
   * Vanilla "water" cauldron block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getInteraction(itemStack, options) {
    const actions = LayeredCauldronInteraction.parseAll(options.interactions);
    for (const action of actions) {
      if (itemStack.matches(action.input)) return action;
    }
    return void 0;
  }
  update(event) {
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    const equ = event.player.getComponent("equippable");
    if (!equ) return;
    const mainhand = equ.getEquipment(EquipmentSlot14.Mainhand);
    if (!mainhand) return;
    let interaction = this.getInteraction(mainhand, options);
    if (!interaction) return;
    ItemUtils.convert(event.player, EquipmentSlot14.Mainhand, interaction.getOutputStack());
    event.block.setPermutation(interaction.getBlock(event.block, options));
    this.update(event);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/leaves.ts
var LeavesComponent = class {
  static componentId = AddonUtils.makeId("leaves");
  struct = object({
    distance_state: defaulted(string(), "mcutils:distance"),
    persistent_state: defaulted(string(), "mcutils:persistent"),
    delay: defaulted(number(), 0)
  });
  /**
   * Vanilla leaves block behavior.
   */
  constructor() {
    this.onRandomTick = this.onRandomTick.bind(this);
    this.onTick = this.onTick.bind(this);
  }
  // EVENTS
  onRandomTick(event, args) {
  }
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const blk = event.block;
    const persistent = blk.getState(options.persistent_state);
    if (persistent) return;
    const distance = blk.getState(options.distance_state);
    let delay = event.block.getDynamicProperty("mcutils:delay") ?? 0;
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/multiblock.ts
var Part = class _Part {
  name;
  offset;
  relative;
  constructor(name, offset, relative = false) {
    this.name = name;
    this.offset = offset;
    this.relative = relative;
  }
  isBase() {
    return Vector3Utils.equals(VECTOR3_ZERO, this.offset);
  }
  fromDir(direction) {
    if (!this.relative || this.isBase()) return this.offset;
    return DirectionUtils.offsetFromDirection(this.offset, direction);
  }
  static parse(value) {
    const seg = value.split(",");
    var relative = false;
    if (seg[1].charAt(0) === "^") {
      seg[0] = seg[0].slice(1);
      relative = true;
    }
    if (seg[2].charAt(0) === "^") {
      seg[1] = seg[1].slice(1);
      relative = true;
    }
    if (seg[3].charAt(0) === "^") {
      seg[2] = seg[2].slice(1);
      relative = true;
    }
    const x2 = +seg[1];
    const y2 = +seg[2];
    const z2 = +seg[3];
    return new _Part(seg[0], { x: x2, y: y2, z: z2 }, relative);
  }
  static parseAll(value) {
    if (!value) return [];
    const parts = [];
    for (const i2 of value) {
      const p2 = _Part.parse(i2);
      if (!p2) continue;
      parts.push(p2);
    }
    return parts;
  }
};
var MultiBlockReceiveEvent = class {
  constructor(block, sourceBlock, id, data) {
    this.block = block;
    this.dimension = block.dimension;
    this.sourceBlock = sourceBlock;
    this.id = id;
    this.data = data ?? {};
  }
  dimension;
  /**
   * The block that received the event.
   */
  block;
  /**
   * The block that sent the event.
   */
  sourceBlock;
  /**
   * The event ID.
   */
  id;
  /**
   * Additional event data.
   */
  data;
};
var MultiblockComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("multiblock");
  struct = object({
    part_state: defaulted(string(), "mcutils:part"),
    direction_state: optional(string()),
    sync_states: defaulted(boolean(), false),
    parts: defaulted(array(string()), [])
  });
  /**
   * Vanilla multiblock behavior. (like: doors, tall grass, beds)
   */
  constructor() {
    super();
    this.beforeOnPlayerPlace = this.beforeOnPlayerPlace.bind(this);
    this.onPlace = this.onPlace.bind(this);
    this.onPlayerBreak = this.onPlayerBreak.bind(this);
  }
  isBase(permutation, options) {
    const state = permutation.getState(options.part_state);
    const parts = Part.parseAll(options.parts);
    for (const part of parts) {
      if (!part.isBase()) continue;
      if (part.name === state) return true;
    }
    return false;
  }
  update(block, args) {
    super.update(block, args);
    const options = create(args.params, this.struct);
    if (!options.sync_states) return;
    this.syncStates(block, options);
  }
  syncStates(block, options) {
    if (!options.sync_states) return;
    const blocks = this.getOtherParts(block.permutation, block.dimension, block.location, options);
    for (const block2 of blocks) {
      if (!block2) continue;
      const part = block2.permutation.getState(options.part_state);
      const perm = block.permutation.withState(options.part_state, part);
      block2.setPermutation(perm);
    }
  }
  findBase(permutation, dimension, location, options) {
    const parts = Part.parseAll(options.parts);
    const basePart = parts.find((part) => part.isBase());
    if (!basePart) return void 0;
    const name = permutation.getState(options.part_state);
    if (basePart.name === name) return dimension.getBlock(location);
    const thisPart = parts.find((part) => part.name === name);
    if (!thisPart) return void 0;
    const dx = basePart.offset.x - thisPart.offset.x;
    const dy = basePart.offset.y - thisPart.offset.y;
    const dz = basePart.offset.z - thisPart.offset.z;
    let offset = { x: dx, y: dy, z: dz };
    if (options.direction_state) {
      const dir = permutation.getState(options.direction_state);
      offset = DirectionUtils.offsetFromDirection(offset, dir);
    }
    const blk = dimension.getBlock(location);
    if (!blk) return;
    return blk.offset(offset);
  }
  getOtherParts(permutation, dimension, location, options) {
    const base = this.findBase(permutation, dimension, location, options);
    if (!base) return [];
    const blocks = [];
    const name = permutation.getState(options.part_state);
    for (const part of Part.parseAll(options.parts)) {
      if (part.name === name) continue;
      var blk = base.offset(part.offset);
      if (options.direction_state) {
        const dir = permutation.getState(options.direction_state);
        blk = base.offset(part.fromDir(dir));
      }
      if (!blk) continue;
      blocks.push(blk);
    }
    return blocks;
  }
  /**
   * Send data to the other parts of the block.
   * @param {Block} block
   * @param {any} data
   * @returns
   */
  sendPart(block, args, id, data) {
    if (!this.onReceivePart) return;
    const options = create(args.params, this.struct);
    const blocks = this.getOtherParts(block.permutation, block.dimension, block.location, options);
    for (const target of blocks) {
      this.onReceivePart(new MultiBlockReceiveEvent(target, block, id, data), args);
    }
  }
  // EVENTS
  beforeOnPlayerPlace(event, args) {
    const options = create(args.params, this.struct);
    const parts = Part.parseAll(options.parts);
    for (const part of parts) {
      var block = event.block.offset(part.offset);
      if (options.direction_state) {
        const dir = event.permutationToPlace.getState(options.direction_state);
        block = event.block.offset(part.fromDir(dir));
      }
      if (!block || !block.isAir) {
        event.cancel = true;
        return;
      }
    }
  }
  onPlace(event, args) {
    const options = create(args.params, this.struct);
    if (!this.isBase(event.block.permutation, options)) return;
    const parts = Part.parseAll(options.parts);
    for (const part of parts) {
      if (part.isBase()) {
        BlockUtils.setState(event.block, options.part_state, part.name);
        continue;
      }
      var block = event.block.offset(part.offset);
      if (options.direction_state) {
        const dir = event.block.permutation.getState(options.direction_state);
        block = event.block.offset(part.fromDir(dir));
      }
      if (!block) continue;
      const perm = event.block.permutation.withState(options.part_state, part.name);
      block.setPermutation(perm);
    }
  }
  onPlayerBreak(event, args) {
    const options = create(args.params, this.struct);
    const blocks = this.getOtherParts(event.brokenBlockPermutation, event.dimension, event.block.location, options);
    for (const block of blocks) {
      this.destroy(block, event.player);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/oxidizable.ts
var OxidizableComponent = class {
  static componentId = AddonUtils.makeId("oxidizable");
  struct = object({
    block: optional(isBlock)
  });
  /**
   * Vanilla oxidizable block behavior.
   */
  constructor() {
    this.onRandomTick = this.onRandomTick.bind(this);
  }
  getBlock(block, options) {
    if (options.block) return options.block;
    const typeId = Identifier.parse(block.typeId);
    const age = BlockUtils.guessOxidization(block);
    switch (age) {
      case 0 /* Normal */:
        return typeId.suffix("exposed_").toString();
      case 1 /* Exposed */:
        return typeId.replace("exposed_", "weathered_").toString();
      case 2 /* Weathered */:
        return typeId.replace("weathered_", "oxidized_").toString();
    }
    return typeId.toString();
  }
  convertBlock(block, options) {
    BlockUtils.setType(block, this.getBlock(block, options));
  }
  // EVENTS
  onRandomTick(event, args) {
    const options = create(args.params, this.struct);
    this.convertBlock(event.block, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/powder_snow.ts
import {
  EquipmentSlot as EquipmentSlot15
} from "@minecraft/server";
var PowderSnowComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("powder_snow");
  struct = object({
    solid_state: defaulted(string(), "mcutils:solid"),
    fog_identifier: optional(string())
  });
  /**
   * Vanilla powder snow block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  onTick(event, args) {
    this.baseTick(event, args);
  }
  onEnter(event, args) {
    const options = create(args.params, this.struct);
    if (event.sameType) return;
    if (!options.fog_identifier) return;
    event.entity.runCommand(`fog @s push ${options.fog_identifier} ${event.block.typeId}`);
  }
  onLeave(event, args) {
    const options = create(args.params, this.struct);
    if (event.sameType) return;
    if (!options.fog_identifier) return;
    event.entity.runCommand(`fog @s remove ${event.block.typeId}`);
    event.entity.removeEffect("slowness");
    event.entity.removeEffect("slow_falling");
  }
  // Simulate viscosity
  inBlockTick(event, args) {
    event.entity.addEffect("slowness", 1220, {
      amplifier: 3,
      showParticles: false
    });
    event.entity.addEffect("slow_falling", 1220, {
      amplifier: 1,
      showParticles: false
    });
  }
  hasLeatherBoots(entity) {
    const equ = entity.getComponent("equippable");
    if (!equ) return false;
    const feet = equ.getEquipment(EquipmentSlot15.Feet);
    if (!feet) return false;
    return feet.matches("leather_boots");
  }
  // TODO: Check if entity is standing on this block.
  onNearbyEntityTick(event, args) {
    const options = create(args.params, this.struct);
    const solid = event.block.permutation.getState(options.solid_state);
    let boots = this.hasLeatherBoots(event.entity);
    if (!solid && boots) {
      BlockUtils.setState(event.block, options.solid_state, true);
      return;
    }
    if (solid && !boots) {
      BlockUtils.setState(event.block, options.solid_state, false);
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/pressure_plate.ts
var PressurePlateComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("pressure_plate");
  struct = object({
    filter: defaulted(entityFilter, { type: "player" }),
    powered_state: defaulted(string(), "mcutils:powered"),
    delay: defaulted(number(), 20),
    click_on_sound_event: defaulted(string(), "click_on.stone_pressure_plate"),
    click_off_sound_event: defaulted(string(), "click_off.stone_pressure_plate")
  });
  /**
   * Vanilla pressure plate block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  getSound(powered, options) {
    if (powered) {
      return options.click_on_sound_event ?? "click_on.stone_pressure_plate";
    }
    return options.click_off_sound_event ?? "click_off.stone_pressure_plate";
  }
  getEntities(block, options) {
    const filter = deepCopy(options.filter);
    filter.maxDistance = 1.5;
    filter.location = block.location;
    return block.dimension.getEntities(filter).filter(
      (entity) => Math.floor(entity.location.x) == block.location.x && Math.floor(entity.location.y) == block.location.y && Math.floor(entity.location.z) == block.location.z
    );
  }
  // EVENTS
  // Check for entities
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const delay = event.block.getDynamicProperty("mcutils:delay") ?? 0;
    const powered = event.block.permutation.getState(options.powered_state);
    const entities = this.getEntities(event.block, options);
    if (!powered && entities.length > 0) {
      event.block.setDynamicProperty("mcutils:delay", options.delay);
      event.dimension.playSound(this.getSound(true, options), event.block);
      BlockUtils.setState(event.block, options.powered_state, true);
      return;
    }
    if (powered && entities.length === 0 && delay > 0) {
      let v2 = delay - 1;
      event.block.setDynamicProperty("mcutils:delay", v2);
      if (v2 == 0) {
        event.dimension.playSound(this.getSound(false, options), event.block);
        BlockUtils.setState(event.block, options.powered_state, false);
      }
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/redstone_lamp.ts
var RedstoneLampComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("redstone_lamp");
  struct = object({
    lit_state: defaulted(string(), "mcutils:lit"),
    delay: defaulted(number(), 0)
  });
  /**
   * Vanilla redstone lamp block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  updateNeighbors(block, value, options) {
    MathUtils.taxicabDistance(block.location, 1, (pos) => {
      const blk = block.dimension.getBlock(pos);
      if (!blk || blk.typeId != block.typeId) return;
      blk.setState(options.lit_state, value);
    });
  }
  // EVENTS
  // TODO: Prevent spam
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    let level = event.sourceBlock.getRedstonePower();
    if (level == void 0) return;
    if (level == 0) {
      return this.updateNeighbors(event.block, false, options);
    }
    this.updateNeighbors(event.block, true, options);
  }
  onTick(event, args) {
    super.baseTick(event, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/scrape_oxidization.ts
import {
  MolangVariableMap
} from "@minecraft/server";
var ScrapeOxidizationComponent = class {
  static componentId = AddonUtils.makeId("scrape_oxidization");
  struct = object({
    block: optional(isBlock),
    particle_effect: defaulted(string(), "minecraft:wax_particle"),
    sound_effect: defaulted(string(), "scrape")
  });
  /**
   * Vanilla scrape oxidization block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getBlock(block, options) {
    if (options.block) return options.block;
    const typeId = Identifier.parse(block.typeId);
    const age = BlockUtils.guessOxidization(block);
    switch (age) {
      case 3 /* Oxidized */:
        return typeId.replace("oxidized_", "weathered_").toString();
      case 2 /* Weathered */:
        return typeId.replace("weathered_", "exposed_").toString();
      case 1 /* Exposed */:
        return typeId.replace("exposed_", "").toString();
    }
    return typeId.toString();
  }
  convertBlock(block, options) {
    BlockUtils.setType(block, this.getBlock(block, options));
  }
  onPlayerInteract(event, args) {
    if (!event.player) return;
    const options = create(args.params, this.struct);
    if (!ItemUtils.holding(event.player, "#is_axe")) return;
    this.convertBlock(event.block, options);
    const variables = new MolangVariableMap();
    variables.setColorRGB("color", { red: 0, green: 0, blue: 0 });
    variables.setVector3("direction", VECTOR3_ZERO);
    event.block.dimension.spawnParticle(
      options.particle_effect ?? "minecraft:wax_particle",
      event.block.location,
      variables
    );
    event.block.dimension.playSound(options.sound_effect ?? "scrape", event.block.location);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/scrape_wax.ts
import {
  MolangVariableMap as MolangVariableMap2
} from "@minecraft/server";
var ScrapeWaxComponent = class {
  static componentId = AddonUtils.makeId("scrape_wax");
  struct = object({
    block: optional(isBlock),
    particle_effect: defaulted(string(), "minecraft:wax_particle"),
    sound_effect: defaulted(string(), "copper.wax.off")
  });
  /**
   * Vanilla scrape wax block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getBlock(block, options) {
    const typeId = Identifier.parse(block.typeId);
    return options.block ?? typeId.replace("waxed_", "").toString();
  }
  convertBlock(block, options) {
    BlockUtils.setType(block, this.getBlock(block, options));
  }
  onPlayerInteract(event, args) {
    if (!event.player) return;
    const options = create(args.params, this.struct);
    if (!ItemUtils.holding(event.player, "#is_axe")) return;
    this.convertBlock(event.block, options);
    const variables = new MolangVariableMap2();
    variables.setColorRGB("color", { red: 1, green: 1, blue: 1 });
    variables.setVector3("direction", { x: 1, y: 1, z: 0 });
    event.block.dimension.spawnParticle(
      options.particle_effect ?? "minecraft:wax_particle",
      event.block.location,
      variables
    );
    event.block.dimension.playSound(options.sound_effect ?? "copper.wax.off", event.block.location);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/sittable.ts
var SittableBlockEvent = class {
  constructor(block, dimension, player) {
    this.block = block;
    this.dimension = dimension;
    this.player = player;
  }
  block;
  dimension;
  player;
  cancel = false;
};
var SittableComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("sittable");
  struct = object({
    seat_position: defaulted(vec3, [0, 8, 0]),
    seat_animations: defaulted(array(string()), [])
  });
  /**
   * Sittable block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  canSit() {
    return true;
  }
  getPos(block, options) {
    const pos = options.seat_position;
    return Vector3Utils.add(Vector3Utils.add(block.location, CENTER_ENTITY), {
      x: pos[0] / 16,
      y: pos[1] / 16,
      z: pos[2] / 16
    });
  }
  getRot(block, options) {
    return void 0;
  }
  sit(block, player, options) {
    const sitEvent = new SittableBlockEvent(block, block.dimension, player);
    if (this.onMountEnter) this.onMountEnter(sitEvent);
    if (sitEvent.cancel) return;
    let pos = this.getPos(block, options);
    let rot = this.getRot(block, options);
    PlayerUtils.sit(
      player,
      pos,
      rot,
      (cancel) => {
        const sitEvent2 = new SittableBlockEvent(block, block.dimension, player);
        if (this.onMountExit) this.onMountExit(sitEvent2);
        cancel = sitEvent2.cancel;
      },
      options.seat_animations
    );
    player.onScreenDisplay.setActionBar({
      translate: `action.hint.exit.${block.typeId}`
    });
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player) return;
    if (!this.canSit()) return;
    this.sit(event.block, event.player, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/slab.ts
import {
  EquipmentSlot as EquipmentSlot16,
  Direction as Direction7
} from "@minecraft/server";
var SlabComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("slab");
  struct = object({
    double_state: defaulted(string(), "mcutils:double")
  });
  /**
   * Vanilla slab block behavior.
   */
  constructor() {
    super();
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  canBeDoubled(event, options) {
    if (!event.player) return false;
    const state = event.block.permutation;
    const stack = event.player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot16.Mainhand);
    if (!stack) {
      return false;
    }
    return !state.getState(options.double_state) && stack.typeId === event.block.getItemStack()?.typeId && (state.getState("minecraft:vertical_half") == "top" && event.face === Direction7.Down || state.getState("minecraft:vertical_half") == "bottom" && event.face === Direction7.Up);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    const state = event.block.permutation;
    if (this.canBeDoubled(event, options)) {
      event.player?.dimension.playSound(getInteractSound(event.block), event.block.location);
      event.block.setPermutation(state.withState(options.double_state, true));
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/sponge.ts
var SpongeComponent = class {
  static componentId = AddonUtils.makeId("sponge");
  struct = object({
    block: optional(isBlock),
    liquid_block: defaulted(isBlock, "water"),
    air_block: defaulted(isBlock, "air"),
    size: defaulted(number(), 7)
  });
  /**
   * Vanilla sponge block behavior.
   */
  constructor() {
    this.onPlace = this.onPlace.bind(this);
  }
  getWetBlock(block, options) {
    const id = Identifier.parse(block.typeId);
    return options.block ?? id.prefix("wet_").toString();
  }
  // Replace water with air
  absorbLiquid(block, options) {
    return MathUtils.taxicabDistance(block.location, options.size ?? 7, (pos) => {
      const blk = block.dimension.getBlock(pos);
      if (blk?.matches(options.liquid_block ?? "water")) {
        blk.setType(options.air_block ?? "air");
        return true;
      }
      return void 0;
    });
  }
  // EVENTS
  onPlace(event, args) {
    const options = create(args.params, this.struct);
    const bool = this.absorbLiquid(event.block, options);
    if (bool) event.block.setType(this.getWetBlock(event.block, options));
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/stairs.ts
var StairsComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("stairs");
  struct = object({
    direction_state: defaulted(string(), "minecraft:cardinal_direction"),
    half_state: defaulted(string(), "minecraft:vertical_half"),
    shape_state: defaulted(string(), "mcutils:shape")
  });
  /**
   * Vanilla stairs block behavior.
   */
  constructor() {
    super();
    this.onPlace = this.onPlace.bind(this);
    this.onTick = this.onTick.bind(this);
  }
  isStairs(block) {
    return block.hasTag("minecraft:stairs") || block.hasTag("stairs") || block.typeId.toString().endsWith("stairs");
  }
  isDifferentOrientation(block, dir, options) {
    var blockState = block.offset(DirectionUtils.toOffset(dir));
    if (!blockState) return;
    return !this.isStairs(blockState) || !BlockUtils.matchState(block, blockState, options.direction_state) || !BlockUtils.matchState(block, blockState, options.half_state);
  }
  getStairsShape(block, options) {
    var direction3;
    var direction2;
    var direction = block.permutation.getState(options.direction_state);
    var blockState = block.offset(DirectionUtils.toOffset(direction));
    if (!blockState) return "straight";
    if (this.isStairs(blockState) && BlockUtils.matchState(block, blockState, options.half_state) && DirectionUtils.toAxis(direction2 = blockState.permutation.getState(options.direction_state)) != DirectionUtils.toAxis(block.permutation.getState(options.direction_state)) && this.isDifferentOrientation(block, DirectionUtils.getOpposite(direction2), options)) {
      if (TextUtils.titleCase(direction2) == DirectionUtils.rotateYCounterclockwise(direction)) {
        return "inner_right";
      }
      return "inner_left";
    }
    var blockState2 = block.offset(DirectionUtils.toOffset(DirectionUtils.getOpposite(direction)));
    if (!blockState2) return "straight";
    if (this.isStairs(blockState2) && BlockUtils.matchState(block, blockState2, options.half_state) && DirectionUtils.toAxis(direction3 = blockState2.permutation.getState(options.direction_state)) != DirectionUtils.toAxis(block.permutation.getState(options.direction_state)) && this.isDifferentOrientation(block, direction3, options)) {
      if (TextUtils.titleCase(direction3) == DirectionUtils.rotateYCounterclockwise(direction)) {
        return "outer_right";
      }
      return "outer_left";
    }
    return "straight";
  }
  // EVENTS
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    const state = event.block.permutation;
    var shape = this.getStairsShape(event.block, options);
    if (state.getState(options.shape_state) != shape) {
      BlockUtils.setState(event.block, options.shape_state, shape);
    }
  }
  onPlace(event, args) {
    this.update(event.block, args);
  }
  onTick(event, args) {
    super.baseTick(event, args);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/strippable.ts
import {
  BlockPermutation as BlockPermutation14
} from "@minecraft/server";
var StrippableComponent = class _StrippableComponent {
  static componentId = AddonUtils.makeId("strippable");
  struct = object({
    block: optional(isBlock),
    sound_event: defaulted(string(), "dig.wood")
  });
  static CACHE = new LRUCache();
  /**
   * Vanilla strippable block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getStrippedBlock(block, options) {
    return options.block ?? _StrippableComponent.CACHE.getOrCompute(block.typeId, (key) => {
      const id = Identifier.parse(key);
      return id.prefix("stripped_").toString();
    });
  }
  stripBlock(block, options) {
    block.setPermutation(
      BlockPermutation14.resolve(this.getStrippedBlock(block, options), block.permutation.getAllStates())
    );
    block.dimension.playSound(options.sound_event ?? "dig.wood", block.location);
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player || !ItemUtils.holding(event.player, "#is_axe")) return;
    this.stripBlock(event.block, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/time_detector.ts
var TimeDetectorComponent = class {
  static componentId = AddonUtils.makeId("time_detector");
  struct = object({
    inverted_state: defaulted(string(), "mcutils:inverted"),
    powered_state: defaulted(string(), "mcutils:powered"),
    time_interval: defaulted(vec2, [0, 0])
  });
  /**
   * Vanilla time detector block behavior. (like; daylight detector)
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
    this.onTick = this.onTick.bind(this);
  }
  // EVENTS
  // inverted, it outputs a signal strength of 15 minus the current internal sky light level, where values over 15 or below 0 are taken as 15 or 0 respectively.
  onTick(event, args) {
    const options = create(args.params, this.struct);
    const inverted = event.block.permutation.getState(options.inverted_state);
    if (inverted) {
    }
  }
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    BlockUtils.toggleState(event.block, options.inverted_state);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/vertical_slab.ts
import { EquipmentSlot as EquipmentSlot17 } from "@minecraft/server";
var VerticalSlabComponent = class extends SlabComponent {
  static componentId = AddonUtils.makeId("vertical_slab");
  /**
   * Vertical slab block behavior.
   */
  constructor() {
    super();
    this.struct = assign(
      this.struct,
      object({
        direction_state: defaulted(string(), "minecraft:cardinal_direction")
      })
    );
  }
  canBeDoubled(event, options) {
    if (!event.player) return false;
    const state = event.block.permutation;
    const dir = state.getState(options.direction_state);
    const stack = event.player.getComponent("minecraft:equippable")?.getEquipment(EquipmentSlot17.Mainhand);
    if (!stack) {
      return false;
    }
    return !state.getState(options.double_state) && stack.typeId === event.block.getItemStack()?.typeId && DirectionUtils.getOpposite(dir) == event.face;
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/wall.ts
var WallComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("wall");
  struct = object({
    north_state: defaulted(string(), "mcutils:north"),
    east_state: defaulted(string(), "mcutils:east"),
    south_state: defaulted(string(), "mcutils:south"),
    west_state: defaulted(string(), "mcutils:west"),
    up_state: defaulted(string(), "mcutils:up")
  });
  /**
   * Vanilla wall block behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
    this.onPlace = this.onPlace.bind(this);
  }
  isAttachable(block) {
    return !block.isAir && !block.hasTag("non_full");
  }
  isWall(block) {
    if (block === void 0) return false;
    return block.hasTag("minecraft:wall") || block.typeId.includes("wall");
  }
  #upperBit(block) {
    const north = block.north();
    const south = block.south();
    const east = block.east();
    const west = block.west();
    const above = block.above();
    if (!above) return false;
    const nUp = above.north();
    const sUp = above.south();
    const eUp = above.east();
    const wUp = above.west();
    if (this.isWall(above)) return true;
    if (this.isWall(north) && this.isWall(south) && !this.isWall(east) && !this.isWall(west)) return false;
    if (!this.isWall(north) && !this.isWall(south) && this.isWall(east) && this.isWall(west)) return false;
    return true;
  }
  // EVENTS
  onPlace(event, args) {
    this.basePlace(event, args);
  }
  onTick(event, args) {
    this.baseTick(event, args);
  }
  onNeighborUpdate(event, args) {
    const options = create(args.params, this.struct);
    const above = event.block.above();
    if (above && this.#upperBit(event.block)) {
      BlockUtils.setState(event.block, options.up_state, true);
    } else {
      BlockUtils.setState(event.block, options.up_state, false);
    }
    if (!event.direction) return;
    if (this.isAttachable(event.sourceBlock)) {
      if (above && this.isWall(above)) {
        switch (event.direction.toLowerCase()) {
          case "north":
            return BlockUtils.setState(event.block, options.north_state, "tall");
          case "east":
            return BlockUtils.setState(event.block, options.east_state, "tall");
          case "south":
            return BlockUtils.setState(event.block, options.south_state, "tall");
          case "west":
            return BlockUtils.setState(event.block, options.west_state, "tall");
        }
      }
      switch (event.direction.toLowerCase()) {
        case "north":
          return BlockUtils.setState(event.block, options.north_state, "low");
        case "east":
          return BlockUtils.setState(event.block, options.east_state, "low");
        case "south":
          return BlockUtils.setState(event.block, options.south_state, "low");
        case "west":
          return BlockUtils.setState(event.block, options.west_state, "low");
      }
    }
    switch (event.direction.toLowerCase()) {
      case "north":
        return BlockUtils.setState(event.block, options.north_state, "none");
      case "east":
        return BlockUtils.setState(event.block, options.east_state, "none");
      case "south":
        return BlockUtils.setState(event.block, options.south_state, "none");
      case "west":
        return BlockUtils.setState(event.block, options.west_state, "none");
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/waxable.ts
import {
  MolangVariableMap as MolangVariableMap3
} from "@minecraft/server";
var WaxableComponent = class {
  static componentId = AddonUtils.makeId("waxable");
  struct = object({
    block: optional(isBlock),
    particle_effect: defaulted(string(), "minecraft:wax_particle"),
    sound_effect: defaulted(string(), "copper.wax.on"),
    items: defaulted(array(string()), [])
  });
  /**
   * Vanilla waxable block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  getBlock(block, options) {
    const typeId = Identifier.parse(block.typeId);
    return options.block ?? typeId.prefix("waxed_").toString();
  }
  convertBlock(block, options) {
    BlockUtils.setType(block, this.getBlock(block, options));
  }
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    if (!event.player || !ItemUtils.holding(event.player, options.items ?? [])) return;
    this.convertBlock(event.block, options);
    const variables = new MolangVariableMap3();
    variables.setColorRGB("color", { red: 1, green: 1, blue: 1 });
    variables.setVector3("direction", { x: 1, y: 0, z: 0 });
    event.block.dimension.spawnParticle(options.particle_effect, event.block.location, variables);
    event.block.dimension.playSound(options.sound_effect, event.block.location);
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/viscosity.ts
var ViscosityComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("viscosity");
  struct = object({
    value: number()
  });
  /**
   * Block viscosity behavior.
   */
  constructor() {
    super();
    this.onTick = this.onTick.bind(this);
  }
  // EVENTS
  onTick(event, args) {
    this.enterLeaveTick(event, args);
  }
  onEnter(event, args) {
    if (event.sameType) return;
    const options = create(args.params, this.struct);
    if (options.value === 0) return;
    if (options.value < 0) {
      event.entity.addEffect("slowness", MAX_EFFECT, { amplifier: Math.abs(options.value) - 1, showParticles: false });
      return;
    }
    event.entity.addEffect("speed", MAX_EFFECT, { amplifier: options.value - 1, showParticles: false });
  }
  onLeave(event, args) {
    if (event.sameType) return;
    const options = create(args.params, this.struct);
    if (options.value === 0) return;
    if (options.value < 0) {
      event.entity.removeEffect("slowness");
      return;
    }
    event.entity.removeEffect("speed");
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/tile_entity.ts
var TileEntityComponent = class extends BlockBaseComponent {
  static componentId = AddonUtils.makeId("tile_entity");
  struct = object({
    entity: isEntity
  });
  /**
   * Vanilla tile entity block behavior. (Like; chests, barrels)
   */
  constructor() {
    super();
    this.onPlace = this.onPlace.bind(this);
    this.onPlayerBreak = this.onPlayerBreak.bind(this);
  }
  createEntity(block, entityType) {
    const entity = block.dimension.spawnEntity(entityType, Vector3Utils.add(block.location, CENTER_ENTITY));
    entity.setDynamicProperty("common:tile.block", block.typeId);
    entity.nameTag = block.localizationKey;
    return entity;
  }
  /**
   * Get the entity for this tile.
   * @param {Block} block
   * @param {TileEntityOptions} options
   * @returns {Entity}
   */
  getEntity(block, options) {
    const entities = block.dimension.getEntitiesAtBlockLocation(block.location).filter((entity) => entity.matches({ type: options.entity }));
    if (entities.length == 0) {
      return this.createEntity(block, options.entity);
    }
    return entities[0];
  }
  // EVENTS
  onPlace(event, args) {
    const options = create(args.params, this.struct);
    this.createEntity(event.block, options.entity);
  }
  onPlayerBreak(event, args) {
    const options = create(args.params, this.struct);
    const entity = this.getEntity(event.block, options);
    entity.remove();
  }
};

// node_modules/@lpsmods/mc-utils/src/blockcomponent/food.ts
var FoodBlockComponent = class {
  static componentId = AddonUtils.makeId("food");
  struct = object({
    nutrition: defaulted(number(), 0),
    saturation_modifier: defaulted(number(), 0),
    can_always_eat: defaulted(boolean(), false),
    using_converts_to: optional(isBlock)
  });
  /**
   * Food block behavior.
   */
  constructor() {
    this.onPlayerInteract = this.onPlayerInteract.bind(this);
  }
  eat(event, options) {
    if (!event.player) return;
    if (!PlayerUtils.canEat(event.player)) return;
    PlayerUtils.eat(event.player, options.nutrition, options.saturation_modifier);
    if (options.using_converts_to) {
      BlockUtils.setType(event.block, options.using_converts_to);
    }
  }
  // EVENTS
  onPlayerInteract(event, args) {
    const options = create(args.params, this.struct);
    this.eat(event, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/command/custom_effect.ts
import {
  CustomCommandParamType
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/effect/custom.ts
import {
  system as system24,
  world as world30
} from "@minecraft/server";
var initialized10 = false;
var CustomEffectEvent = class {
  constructor(entity, effect) {
    this.entity = entity;
    if (!effect.amplifier) effect.amplifier = 0;
    if (!effect.showParticles) effect.showParticles = true;
    this.effect = effect;
  }
  entity;
  effect;
};
var CustomEffectTickEvent = class extends CustomEffectEvent {
};
var CustomEffectStartEvent = class extends CustomEffectEvent {
  cancel = false;
};
var CustomEffectEndEvent = class extends CustomEffectEvent {
  cancel = false;
};
var CustomEffectUtils = class {
  static struct = object({
    effect: string(),
    duration: number(),
    totalDuration: number(),
    showParticles: defaulted(boolean(), true),
    amplifier: defaulted(min(max(number(), 255), 0), 0),
    params: defaulted(object(), {})
  });
  static getStorage(entity) {
    return new VersionedDataStorage("mcutils:custom_effects", 1, entity);
  }
  /**
   * All effects the entity has.
   * @param {Entity} entity
   * @returns {CustomEffectInstance[]}
   */
  static getAll(entity) {
    const store = this.getStorage(entity);
    return store.get("active_effects", []);
  }
  /**
   * Apply a custom effect to an entity.
   * @param {Entity} entity
   * @param {string} effectType Custom effect id.
   * @param {number} duration
   * @param {CustomEffectUtilsOptions} options
   * @returns {boolean}
   */
  static add(entity, effectType, duration, options) {
    const effect = customEffectRegistry.get(effectType);
    if (!effect) throw new Error(`Effect "${effectType}" not found!`);
    const instance = this.struct.create({
      duration,
      effect: effectType,
      totalDuration: duration,
      amplifier: options?.amplifier,
      showParticles: options?.showParticles
    });
    const event = new CustomEffectStartEvent(entity, instance);
    if (effect.onStart) effect.onStart(event);
    if (event.cancel) return false;
    const effects = this.getAll(entity);
    const instance2 = effects.find((effect2) => effect2.effect === effectType);
    if (instance2) {
      instance2.duration = event.effect.duration;
      instance2.amplifier = event.effect.amplifier;
    } else {
      effects.push(event.effect);
    }
    const store = this.getStorage(entity);
    store.set("active_effects", effects);
    return true;
  }
  /**
   * Remove a custom effect from an entity.
   * @param {Entity} entity
   * @param {string} effectType Custom effect id.
   */
  static remove(entity, effectType) {
    if (!customEffectRegistry.has(effectType)) throw new Error(`Effect "${effectType}" not found!`);
    let effects = this.getAll(entity);
    effects = effects.filter((instance) => {
      if (instance.effect !== effectType) return true;
      const effect = customEffectRegistry.get(instance.effect);
      const event = new CustomEffectEndEvent(entity, instance);
      if (effect?.onEnd) effect.onEnd(event);
      return !event.cancel;
    });
    const store = this.getStorage(entity);
    store.set("active_effects", effects);
  }
  /**
   * Remove all effects from the entity.
   * @param {Entity} entity
   */
  static removeAll(entity) {
    let effects = this.getAll(entity);
    effects = effects.filter((instance) => {
      const event = new CustomEffectEndEvent(entity, instance);
      const effect = customEffectRegistry.get(instance.effect);
      if (effect?.onEnd) effect.onEnd(event);
      return !event.cancel;
    });
    const store = this.getStorage(entity);
    store.set("active_effects", effects);
  }
  /**
   * Whether or not the entity has the effect.
   * @param {Entity} entity
   * @param {string} effectName Custom effect Id.
   * @returns {boolean}
   */
  static has(entity, effectName) {
    return this.getAll(entity).some((instance) => instance.effect === effectName);
  }
};
var CustomEffects = class extends Registry {
  static registryId = "custom_effects";
  register(name, customEffect) {
    if (!initialized10) init13();
    return super.register(name, customEffect);
  }
};
var customEffectRegistry = new CustomEffects();
function decreaseDuration(entity, effects) {
  const results = [];
  for (const instance of effects) {
    instance.duration--;
    if (instance.duration <= 0) {
      const effect = customEffectRegistry.get(instance.effect);
      const event = new CustomEffectEndEvent(entity, instance);
      if (effect?.onEnd) effect.onEnd(event);
      if (!event.cancel) continue;
    }
    results.push(instance);
  }
  const store = CustomEffectUtils.getStorage(entity);
  store.set("active_effects", results);
}
function tick3() {
  forAllDimensions((dim) => {
    for (const entity of dim.getEntities()) {
      const effects = CustomEffectUtils.getAll(entity);
      effects.forEach((instance) => {
        const effect = customEffectRegistry.get(instance.effect);
        const event = new CustomEffectTickEvent(entity, instance);
        if (effect?.onTick) effect.onTick(event);
      });
      if (system24.currentTick % 20 !== 0) return;
      decreaseDuration(entity, effects);
    }
  });
}
function callHandle2(name, entity, event) {
  if (!entity) return;
  for (const k2 of customEffectRegistry.keys()) {
    const effect = customEffectRegistry.get(k2);
    if (!effect || !entity || !entity.isValid) continue;
    if (!CustomEffectUtils.has(entity, k2)) continue;
    const func = effect[name];
    if (!func) continue;
    if (typeof func !== "function") continue;
    func(event);
  }
}
function init13() {
  initialized10 = true;
  system24.runInterval(tick3);
  EntityEvents.mount.subscribe((event) => {
    callHandle2("onMount", event.entity, event);
  });
  EntityEvents.dismount.subscribe((event) => {
    callHandle2("onDismount", event.entity, event);
  });
  EntityEvents.moved.subscribe((event) => {
    callHandle2("onMoved", event.entity, event);
  });
  EntityEvents.tick.subscribe((event) => {
    callHandle2("onTick", event.entity, event);
  });
  EntityEvents.fallOn.subscribe((event) => {
    callHandle2("onFallOn", event.entity, event);
  });
  EntityEvents.stepOn.subscribe((event) => {
    callHandle2("onStepOn", event.entity, event);
  });
  EntityEvents.stepOff.subscribe((event) => {
    callHandle2("onStepOff", event.entity, event);
  });
  world30.afterEvents.playerInteractWithEntity.subscribe((event) => {
    callHandle2("onInteract", event.target, event);
  });
  world30.beforeEvents.playerInteractWithEntity.subscribe((event) => {
    callHandle2("onBeforeInteract", event.target, event);
  });
  world30.beforeEvents.entityRemove.subscribe((event) => {
    callHandle2("onRemove", event.removedEntity, event);
  });
  world30.afterEvents.entityDie.subscribe((event) => {
    callHandle2("onDie", event.deadEntity, event);
  });
  world30.afterEvents.entityHealthChanged.subscribe((event) => {
    callHandle2("onHealthChanged", event.entity, event);
  });
  world30.afterEvents.entityHitBlock.subscribe((event) => {
    callHandle2("onHitBlock", event.damagingEntity, event);
  });
  world30.afterEvents.entityHitEntity.subscribe((event) => {
    callHandle2("onHitEntity", event.damagingEntity, event);
  });
  world30.afterEvents.entityHurt.subscribe((event) => {
    callHandle2("onHurt", event.hurtEntity, event);
  });
  world30.afterEvents.entityLoad.subscribe((event) => {
    callHandle2("onLoad", event.entity, event);
  });
  world30.afterEvents.entitySpawn.subscribe((event) => {
    callHandle2("onSpawn", event.entity, event);
  });
}

// node_modules/@lpsmods/mc-utils/src/command/custom_effect.ts
var CustomEffectCommand = class {
  static registered = false;
  static options = {
    name: "mcutils:custom-effect",
    description: "Add or remove custom status effects.",
    permissionLevel: 1,
    mandatoryParameters: [
      { type: CustomCommandParamType.Enum, name: "mcutils:custom_effect_operation" },
      { type: CustomCommandParamType.EntitySelector, name: "entity" }
    ],
    optionalParameters: [
      { type: CustomCommandParamType.Enum, name: "mcutils:custom_effect" },
      { type: CustomCommandParamType.Integer, name: "duration" },
      { type: CustomCommandParamType.Integer, name: "amplifier" },
      { type: CustomCommandParamType.Boolean, name: "showParticles" }
    ]
  };
  static executeGive(entity, effect, duration, amplifier, showParticles) {
    if (!effect) throw new Error(`"effect" is required!`);
    if (!duration) throw new Error(`"duration" is required!`);
    CustomEffectUtils.add(entity, effect, duration, {
      amplifier: amplifier ?? 0,
      showParticles: showParticles ?? false
    });
  }
  static executeClear(entity, effect) {
    if (effect) return CustomEffectUtils.remove(entity, effect);
    CustomEffectUtils.removeAll(entity);
  }
  static execute(ctx, operation, entities, effect, duration, amplifier, showParticles) {
    try {
      switch (operation) {
        case "give":
          entities.forEach((entity) => this.executeGive(entity, effect, duration, amplifier, showParticles));
          return { status: entities.length };
        case "clear":
          entities.forEach((entity) => this.executeClear(entity, effect));
          return { status: entities.length };
      }
    } catch (err) {
      return { status: 0, message: "\xA7c" + err };
    }
  }
  static register(registry) {
    if (this.registered) return;
    registry.registerEnum("mcutils:custom_effect_operation", ["clear", "give"]);
    registry.registerEnum("mcutils:custom_effect", [...customEffectRegistry.keys()]);
    registry.registerCommand(this.options, this.execute.bind(this));
    this.registered = true;
  }
};

// node_modules/@lpsmods/mc-utils/src/command/custom_enchant.ts
import {
  CustomCommandParamType as CustomCommandParamType2,
  EquipmentSlot as EquipmentSlot18,
  system as system25
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/enchantment/custom.ts
import {
  world as world31
} from "@minecraft/server";
var initialized11 = false;
var CustomEnchantmentEvent = class extends ItemEvent {
  cancel = false;
  constructor(itemStack, enchantment) {
    super(itemStack);
    this.enchantment = enchantment;
  }
  enchantment;
};
var ItemCustomEnchantEvent = class extends CustomEnchantmentEvent {
};
var ItemCustomDisenchantEvent = class extends CustomEnchantmentEvent {
};
var CustomEnchantmentUtils = class {
  static struct = object({
    enchant: string(),
    level: defaulted(min(number(), 1), 1),
    params: defaulted(object(), {})
  });
  static getStorage(itemStack) {
    return new VersionedDataStorage("mcutils:custom_enchantments", 1, itemStack);
  }
  /**
   * All enchantments the item has.
   * @param {ItemStack} itemStack
   * @returns {CustomEnchantmentInstance[]}
   */
  static getAll(itemStack) {
    const store = this.getStorage(itemStack);
    return store.get("enchantments", []);
  }
  /**
   * Add a custom enchantment to this item.
   * @param {ItemStack} itemStack
   * @param {string} enchantmentType Custom enchantment id.
   * @param {number} level The enchantment level.
   * @returns {ItemStack|undefined} The enchanted item stack.
   */
  static add(itemStack, enchantmentType, level) {
    if (this.has(itemStack, enchantmentType)) throw new Error(`Item already has enchantment "${enchantmentType}"`);
    const enchant = customEnchantmentRegistry.get(enchantmentType);
    if (!enchant) return itemStack;
    if ((level ?? 1) > enchant.getMaxLevel()) throw new Error(`Level must be at most ${enchant.getMaxLevel()}`);
    const enchants = this.getAll(itemStack);
    const instance = this.struct.create({ enchant: enchantmentType, level: level ?? 1 });
    enchants.push(instance);
    const event = new ItemCustomEnchantEvent(itemStack, instance);
    if (enchant?.onEnchant) enchant.onEnchant(event);
    if (event.cancel) return void 0;
    const store = this.getStorage(itemStack);
    store.set("enchantments", enchants);
    const lore = itemStack.getLore();
    lore.unshift(enchant.getLoreName(instance));
    itemStack.setLore(lore);
    return itemStack;
  }
  /**
   * Remove a custom enchantment from this item.
   * @param {ItemStack} itemStack
   * @param {string} enchantmentType Custom enchantment id.
   * @returns {ItemStack}
   */
  static remove(itemStack, enchantmentType) {
    if (!customEnchantmentRegistry.has(enchantmentType)) throw new Error(`Enchant "${enchantmentType}" not found!`);
    let enchants = this.getAll(itemStack);
    enchants = enchants.filter((instance) => {
      if (instance.enchant !== enchantmentType) return true;
      const enchant = customEnchantmentRegistry.get(instance.enchant);
      const event = new ItemCustomEnchantEvent(itemStack, instance);
      if (enchant?.onDisenchant) enchant.onDisenchant(event);
      if (!event.cancel) {
        const lore = enchant?.getLoreName(instance);
        const data = itemStack.getLore().filter((text) => text !== lore);
        itemStack.setLore(data);
      }
      return !event.cancel;
    });
    const store = this.getStorage(itemStack);
    store.set("enchantments", enchants);
    return itemStack;
  }
  /**
   * Remove all custom enchantments from this item.
   * @param {ItemStack} itemStack
   * @returns {ItemStack}
   */
  static removeAll(itemStack) {
    let enchants = this.getAll(itemStack);
    enchants = enchants.filter((instance) => {
      const enchant = customEnchantmentRegistry.get(instance.enchant);
      const event = new ItemCustomDisenchantEvent(itemStack, instance);
      if (enchant?.onDisenchant) enchant.onDisenchant(event);
      if (!event.cancel) {
        const lore = enchant?.getLoreName(instance);
        const data = itemStack.getLore().filter((text) => text !== lore);
        itemStack.setLore(data);
      }
      return event.cancel;
    });
    const store = this.getStorage(itemStack);
    store.set("enchantments", enchants);
    return itemStack;
  }
  /**
   * Whether or not the item has the custom enchantment.
   * @param {ItemStack} itemStack
   * @param {string} enchantmentType Custom enchantment id.
   * @returns {boolean}
   */
  static has(itemStack, enchantmentType) {
    return this.getAll(itemStack).some((instance) => instance.enchant === enchantmentType);
  }
};
var CustomEnchantments = class extends Registry {
  static registryId = "custom_enchantment";
  register(name, customEnchantment) {
    if (!initialized11) init14();
    return super.register(name, customEnchantment);
  }
};
var customEnchantmentRegistry = new CustomEnchantments();
function callHandle3(name, itemStack, event) {
  if (!itemStack) return;
  for (const k2 of customEnchantmentRegistry.keys()) {
    const enchant = customEnchantmentRegistry.get(k2);
    if (!enchant || !itemStack) continue;
    if (!CustomEnchantmentUtils.has(itemStack, k2)) continue;
    const func = enchant[name];
    if (!func) continue;
    if (typeof func !== "function") continue;
    func(event);
  }
}
function init14() {
  initialized11 = true;
  ItemEvents.playerHold.subscribe((event) => {
    callHandle3("onPlayerHold", event.itemStack, event);
  });
  ItemEvents.playerReleaseHold.subscribe((event) => {
    callHandle3("onPlayerReleaseHold", event.itemStack, event);
  });
  ItemEvents.playerHoldTick.subscribe((event) => {
    callHandle3("onPlayerHoldTick", event.itemStack, event);
  });
  world31.afterEvents.itemCompleteUse.subscribe((event) => {
    callHandle3("onCompleteUse", event.itemStack, event);
  });
  world31.afterEvents.itemReleaseUse.subscribe((event) => {
    callHandle3("onReleaseUse", event.itemStack, event);
  });
  world31.afterEvents.itemStartUse.subscribe((event) => {
    callHandle3("onStartUse", event.itemStack, event);
  });
  world31.afterEvents.itemStartUseOn.subscribe((event) => {
    callHandle3("onStartUseOn", event.itemStack, event);
  });
  world31.afterEvents.itemStopUse.subscribe((event) => {
    callHandle3("onStopUse", event.itemStack, event);
  });
  world31.afterEvents.itemStopUseOn.subscribe((event) => {
    callHandle3("onStopUseOn", event.itemStack, event);
  });
  world31.afterEvents.itemUse.subscribe((event) => {
    callHandle3("onUse", event.itemStack, event);
  });
  world31.beforeEvents.itemUse.subscribe((event) => {
    callHandle3("beforeUse", event.itemStack, event);
  });
}

// node_modules/@lpsmods/mc-utils/src/command/utils.ts
import {
  CustomCommandSource,
  Player as Player15,
  world as world32
} from "@minecraft/server";
var CustomCommandUtils = class {
  static getSource(ctx) {
    switch (ctx.sourceType) {
      case CustomCommandSource.Block:
        return ctx.sourceBlock;
      case CustomCommandSource.Entity:
        return ctx.sourceEntity;
      case CustomCommandSource.NPCDialogue:
        return ctx.initiator;
    }
    return void 0;
  }
  static getDimension(ctx) {
    const source = this.getSource(ctx);
    if (!source) return world32.getDimension("overworld");
    return source.dimension;
  }
  static sendError(ctx, message) {
    const source = this.getSource(ctx);
    if (source instanceof Player15) {
      source.sendMessage(`\xA7c${message}`);
      return;
    }
    world32.sendMessage(`\xA7c${message}`);
  }
  static getPlayer(ctx, player) {
    if (player && player instanceof Player15) return player;
    if (!ctx.sourceEntity) throw new Error("No source entity");
    if (!(ctx.sourceEntity instanceof Player15)) throw new Error("This command can only be ran by players");
    return ctx.sourceEntity;
  }
  static wrapCatch(error, callback) {
    try {
      return callback();
    } catch (err) {
      if (err instanceof error) return { status: 1, message: err.message };
      console.error(err);
      return { status: 1, message: "commands.generic.exception" };
    }
  }
  static wrapCatchAll(errors, callback) {
    try {
      return callback();
    } catch (err) {
      if (!err) return;
      for (const error of errors) {
        if (error && typeof error === "function" && err instanceof error)
          return { status: 1, message: err.message };
      }
      console.error(err);
      return { status: 1, message: "commands.generic.exception" };
    }
  }
};

// node_modules/@lpsmods/mc-utils/src/command/custom_enchant.ts
var CustomEnchantCommand = class {
  static registered = false;
  static options = {
    name: "mcutils:custom-enchant",
    description: "Add a custom enchantment.",
    permissionLevel: 1,
    mandatoryParameters: [
      { type: CustomCommandParamType2.EntitySelector, name: "entities" },
      { type: CustomCommandParamType2.Enum, name: "mcutils:custom_enchantment" }
    ],
    optionalParameters: [{ type: CustomCommandParamType2.Integer, name: "level" }]
  };
  static executeMob(ctx, entity, enchantmentType, level) {
    const equ = entity.getComponent("equippable");
    if (!equ) return;
    let itemStack = equ.getEquipment(EquipmentSlot18.Mainhand);
    if (!itemStack) return;
    const bl = CustomEnchantmentUtils.add(itemStack, enchantmentType, level);
    if (!bl) {
      CustomCommandUtils.sendError(ctx, "Failed to set enchantment");
      return;
    }
    equ.setEquipment(EquipmentSlot18.Mainhand, itemStack);
  }
  static execute(ctx, entities, enchantmentType, level) {
    try {
      system25.run(() => {
        entities.forEach((entity) => {
          this.executeMob(ctx, entity, enchantmentType, level);
        });
      });
      return { status: entities.length };
    } catch (err) {
      return { status: 0, message: "\xA7c" + err };
    }
  }
  static register(registry) {
    if (this.registered) return;
    registry.registerEnum("mcutils:custom_enchantment", [...customEnchantmentRegistry.keys()]);
    registry.registerCommand(this.options, this.execute.bind(this));
    this.registered = true;
  }
};

// node_modules/@lpsmods/mc-utils/src/feature/feature_handler.ts
import {
  system as system26,
  world as world33
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/feature/feature.ts
import {
  LocationInUnloadedChunkError as LocationInUnloadedChunkError4,
  StructureRotation,
  system as system27,
  world as world34
} from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/itemcomponent/tool.ts
var ToolComponent = class {
  static componentId = AddonUtils.makeId("tool");
  struct = object({
    damage_when_mined: defaulted(boolean(), false),
    damage_when_hit: defaulted(boolean(), false)
  });
  /**
   * Deals damage to the item when you break a block or hit an entity.
   */
  constructor() {
    this.onMineBlock = this.onMineBlock.bind(this);
    this.onHitEntity = this.onHitEntity.bind(this);
  }
  onMineBlock(event, args) {
    const options = create(args.params, this.struct);
    if (options.damage_when_mined != void 0 && !options.damage_when_mined) return;
    if (!event.itemStack) return;
    ItemUtils.applyDamage(event.source, event.itemStack, 1);
  }
  onHitEntity(event, args) {
    const options = create(args.params, this.struct);
    if (options.damage_when_hit != void 0 && !options.damage_when_hit) return;
    if (!event.itemStack) return;
    ItemUtils.applyDamage(event.attackingEntity, event.itemStack, 1);
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/axe.ts
var AxeComponent = class _AxeComponent extends ToolComponent {
  static componentId = AddonUtils.makeId("axe");
  struct = object({
    size: defaulted(number(), 1),
    sound_event: defaulted(string(), "use.gravel"),
    interactions: defaulted(
      array(
        object({
          block: isBlock,
          converted_block: isBlock
        })
      ),
      []
    )
  });
  interactions = _AxeComponent.defaultInteractions();
  /**
   * Makes this item strip logs like an axe.
   */
  constructor() {
    super();
    this.onUseOn = this.onUseOn.bind(this);
  }
  static defaultInteractions() {
    return {
      oak_log: "stripped_oak_log",
      spruce_log: "stripped_spruce_log",
      birch_log: "stripped_birch_log",
      jungle_log: "stripped_jungle_log",
      acacia_log: "stripped_acacia_log",
      dark_oak_log: "stripped_dark_oak_log",
      mangrove_log: "stripped_mangrove_log",
      cherry_log: "stripped_cherry_log",
      pale_oak_log: "stripped_pale_oak_log",
      bamboo_block: "stripped_bamboo_block",
      crimson_stem: "stripped_crimson_stem",
      warped_stem: "stripped_warped_stem",
      oak_wood: "stripped_oak_wood",
      spruce_wood: "stripped_spruce_wood",
      birch_wood: "stripped_birch_wood",
      jungle_wood: "stripped_jungle_wood",
      acacia_wood: "stripped_acacia_wood",
      dark_oak_wood: "stripped_dark_oak_wood",
      mangrove_wood: "stripped_mangrove_wood",
      cherry_wood: "stripped_cherry_wood",
      pale_oak_wood: "stripped_pale_oak_wood",
      crimson_hyphae: "stripped_crimson_hyphae",
      warped_hyphae: "stripped_warped_hyphae",
      waxed_copper: "copper_block",
      waxed_weathered_copper: "weathered_copper",
      waxed_exposed_copper: "exposed_copper",
      waxed_oxidized_copper: "oxidized_copper",
      oxidized_copper: "weathered_copper",
      weathered_copper: "exposed_copper",
      exposed_copper: "copper_block",
      waxed_cut_copper: "cut_copper",
      waxed_weathered_cut_copper: "weathered_cut_copper",
      waxed_exposed_cut_copper: "exposed_cut_copper",
      waxed_oxidized_cut_copper: "oxidized_cut_copper",
      oxidized_cut_copper: "weathered_cut_copper",
      weathered_cut_copper: "exposed_cut_copper",
      exposed_cut_copper: "cut_copper",
      waxed_copper_bulb: "copper_bulb",
      waxed_weathered_copper_bulb: "weathered_copper_bulb",
      waxed_exposed_copper_bulb: "exposed_copper_bulb",
      waxed_oxidized_copper_bulb: "oxidized_copper_bulb",
      oxidized_copper_bulb: "weathered_copper_bulb",
      weathered_copper_bulb: "exposed_copper_bulb",
      exposed_copper_bulb: "copper_bulb",
      waxed_copper_trapdoor: "copper_trapdoor",
      waxed_weathered_copper_trapdoor: "weathered_copper_trapdoor",
      waxed_exposed_copper_trapdoor: "exposed_copper_trapdoor",
      waxed_oxidized_copper_trapdoor: "oxidized_copper_trapdoor",
      oxidized_copper_trapdoor: "weathered_copper_trapdoor",
      weathered_copper_trapdoor: "exposed_copper_trapdoor",
      exposed_copper_trapdoor: "copper_trapdoor",
      waxed_copper_grate: "copper_grate",
      waxed_weathered_copper_grate: "weathered_copper_grate",
      waxed_exposed_copper_grate: "exposed_copper_grate",
      waxed_oxidized_copper_grate: "oxidized_copper_grate",
      oxidized_copper_grate: "weathered_copper_grate",
      weathered_copper_grate: "exposed_copper_grate",
      exposed_copper_grate: "copper_grate",
      waxed_chiseled_copper: "chiseled_copper",
      waxed_weathered_chiseled_copper: "weathered_chiseled_copper",
      waxed_exposed_chiseled_copper: "exposed_chiseled_copper",
      waxed_oxidized_chiseled_copper: "oxidized_chiseled_copper",
      oxidized_chiseled_copper: "weathered_chiseled_copper",
      weathered_chiseled_copper: "exposed_chiseled_copper",
      exposed_chiseled_copper: "chiseled_copper",
      waxed_cut_copper_stairs: "cut_copper_stairs",
      waxed_weathered_cut_copper_stairs: "weathered_cut_copper_stairs",
      waxed_exposed_cut_copper_stairs: "exposed_cut_copper_stairs",
      waxed_oxidized_cut_copper_stairs: "oxidized_cut_copper_stairs",
      oxidized_cut_copper_stairs: "weathered_cut_copper_stairs",
      weathered_cut_copper_stairs: "exposed_cut_copper_stairs",
      exposed_cut_copper_stairs: "cut_copper_stairs",
      waxed_cut_copper_slab: "cut_copper_slab",
      waxed_weathered_cut_copper_slab: "weathered_cut_copper_slab",
      waxed_exposed_cut_copper_slab: "exposed_cut_copper_slab",
      waxed_oxidized_cut_copper_slab: "oxidized_cut_copper_slab",
      oxidized_cut_copper_slab: "weathered_cut_copper_slab",
      weathered_cut_copper_slab: "exposed_cut_copper_slab",
      exposed_cut_copper_slab: "cut_copper_slab"
    };
  }
  getInteraction(block, options) {
    for (const interaction of options.interactions) {
      if (block.matches(interaction.block)) {
        return interaction;
      }
    }
    return void 0;
  }
  /**
   * Convert the block.
   * @param {Block} block The block that should be converted.
   * @param {ItemUseOnEvent} event The item event for context.
   */
  convertBlock(block, event, options) {
    let result;
    if (!(result = this.getInteraction(block, options))) return;
    block.setType(result.block);
  }
  interactBlock(event, options) {
    event.block.dimension.playSound("use.gravel", event.block.location, {
      volume: 1
    });
    offsetVolume({ x: options.size, y: options.size, z: options.size }, (pos) => {
      try {
        const target = event.block.offset(pos);
        if (!target) return;
        return this.convertBlock(target, event, options);
      } catch (err) {
      }
    });
  }
  // EVENTS
  onUseOn(event, args) {
    const options = create(args.params, this.struct);
    if (!this.getInteraction(event.block, options)) return;
    this.interactBlock(event, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/base.ts
import {
  world as world35,
  EquipmentSlot as EquipmentSlot19
} from "@minecraft/server";
var ItemBaseComponent = class extends Ticking {
  static componentId;
  static components = [];
  struct = object({});
  /**
   * Custom item component containing additional item events.
   */
  constructor() {
    super();
  }
  tick() {
    if (!this.onHoldTick && !this.onHold && !this.onReleaseHold) return;
    for (const player of world35.getAllPlayers()) {
      const equ = player.getComponent("equippable");
      if (!equ) continue;
      const mainStack = equ.getEquipment(EquipmentSlot19.Mainhand);
      if (!mainStack) return;
      const onHoldEvent = new ItemHoldEvent(mainStack, player);
      if (mainStack) {
        const event = new ItemHoldEvent(mainStack, player);
        if (this.onHoldTick) this.onHoldTick(event);
      }
      const holdTag = `hold.test`;
      if (mainStack && !player.hasTag(holdTag)) {
        player.addTag(holdTag);
        if (this.onHold) this.onHold(onHoldEvent);
      }
      if (!mainStack && player.hasTag(holdTag)) {
        player.removeTag(holdTag);
        if (this.onReleaseHold) this.onReleaseHold(onHoldEvent);
      }
    }
  }
};
function init15() {
  world35.afterEvents.entityHitBlock.subscribe((event) => {
    for (const com of ItemBaseComponent.components) {
      if (com.onHitBlock) com.onHitBlock(event);
    }
  });
}
init15();

// node_modules/@lpsmods/mc-utils/src/itemcomponent/flint_and_steel.ts
var FlintAndSteelComponent = class extends ToolComponent {
  static componentId = AddonUtils.makeId("flint_and_steel");
  struct = object({
    block: optional(isBlock),
    size: defaulted(number(), 1)
  });
  /**
   * Makes this item place fire like a flint and steel.
   */
  constructor() {
    super();
    this.onUseOn = this.onUseOn.bind(this);
  }
  getBlock(block, options) {
    return options.block ?? "fire";
  }
  /**
   * Place fire on the block.
   * @param {Block} block The block that was interacted with.
   * @param {ItemUseOnEvent} event The item event for context.
   */
  convertBlock(block, event, options) {
    const target = block.above();
    if (!target || !target.isAir) return;
    target.setType(this.getBlock(block, options));
  }
  #tillBlock(event, options) {
    event.block.dimension.playSound("fire.ignite", event.block.location, {
      volume: 1
    });
    offsetVolume({ x: options.size, y: 0, z: options.size }, (pos) => {
      try {
        const target = event.block.offset(pos);
        if (!target) return;
        this.convertBlock(target, event, options);
      } catch (err) {
      }
    });
  }
  canBeTilled(block, options) {
    const target = this.getBlock(block, options);
    return block.hasTag("dirt") && !block.matches(target) || block.matches("grass_path");
  }
  // EVENTS
  onUseOn(event, args) {
    const options = create(args.params, this.struct);
    if (!this.canBeTilled(event.block, options)) return;
    this.#tillBlock(event, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/guide_book.ts
import { ItemStack as ItemStack17, world as world36 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/itemcomponent/info_book.ts
import {
  system as system28
} from "@minecraft/server";
var InfoBookComponent = class _InfoBookComponent extends ItemBaseComponent {
  static componentId = AddonUtils.makeId("info_book");
  struct = object({
    developer_mode: defaulted(boolean(), false),
    default: defaulted(string(), "home"),
    translation_pattern: defaulted(string(), "guide.{NAMESPACE}:{KEY}"),
    back_button: optional(
      object({
        label: optional(string()),
        icon: optional(string()),
        top_margin: optional(number()),
        bottom_margin: optional(number()),
        bottom_divider: defaulted(boolean(), false),
        top_divider: defaulted(boolean(), false)
      })
    ),
    "mcutils:search": optional(
      object({
        include_buttons: defaulted(boolean(), false),
        include_titles: defaulted(boolean(), false),
        title: optional(string()),
        body: optional(string()),
        include_titles_label: optional(string()),
        include_buttons_label: optional(string()),
        result_title: optional(string()),
        result_body: optional(string())
      })
    )
  });
  customPages = /* @__PURE__ */ new Map();
  ui;
  /**
   * A simple UI guide book for add-ons.
   */
  constructor(pages) {
    super();
    this.ui = new PagedActionForm(pages, { id: _InfoBookComponent.componentId });
    this.ui.t = this.t;
    this.onUse = this.onUse.bind(this);
  }
  t(event, key) {
    const options = event.options;
    if (typeof key !== "string") return key;
    if (key.charAt(0) == "#") {
      const namespace = Identifier.parse(event?.ctx?.itemId ?? _InfoBookComponent.componentId).namespace;
      return "#" + options.translation_pattern.replace("{NAMESPACE}", namespace).replace("{KEY}", key.slice(1));
    }
    return key;
  }
  // EVENTS
  onUse(event, args) {
    const options = create(args.params, this.struct);
    if (options.developer_mode) {
      this.ui.validatePage(options.default);
    }
    system28.run(() => {
      if (!event.itemStack) return;
      this.ui.clearHistory(event.source);
      this.ui.show(event.source, void 0, options, { itemId: event.itemStack.typeId });
    });
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/guide_book.ts
var GuideBookComponent = class extends InfoBookComponent {
  static componentId = AddonUtils.makeId("guide_book");
  /**
   * Guide book item behavior.
   */
  constructor(pages) {
    super(pages);
  }
  static setup(guideBookName) {
    world36.afterEvents.playerSpawn.subscribe((event) => {
      if (!event.initialSpawn) return;
      const bl = event.player.getDynamicProperty(guideBookName) ?? false;
      if (bl) return;
      const stack = new ItemStack17(guideBookName);
      stack.keepOnDeath = true;
      ItemUtils.give(event.player, stack);
      event.player.setDynamicProperty(guideBookName, true);
    });
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/hoe.ts
var HoeComponent = class extends ToolComponent {
  static componentId = AddonUtils.makeId("hoe");
  struct = object({
    size: defaulted(number(), 1),
    block: defaulted(isBlock, "farmland")
  });
  /**
   * Makes this item till dirt like a hoe.
   */
  constructor() {
    super();
    this.onUseOn = this.onUseOn.bind(this);
  }
  getBlock(block, options) {
    return options.block;
  }
  /**
   * Convert the block to farmland.
   * @param {Block} block The block that should be converted to farmland.
   * @param {ItemUseOnEvent} event The item event for context.
   */
  convertBlock(block, event, options) {
    if (!this.canBeTilled(block, options)) return;
    block.setType(this.getBlock(block, options));
  }
  #tillBlock(event, options) {
    event.block.dimension.playSound("use.gravel", event.block.location, {
      volume: 1
    });
    offsetVolume({ x: options.size, y: 0, z: options.size }, (pos) => {
      try {
        const target = event.block.offset(pos);
        if (!target) return;
        return this.convertBlock(target, event, options);
      } catch (err) {
      }
    });
  }
  canBeTilled(block, options) {
    const target = this.getBlock(block, options);
    return block.hasTag("dirt") && !block.matches(target) || block.matches("grass_path");
  }
  // EVENTS
  onUseOn(event, args) {
    const options = create(args.params, this.struct);
    if (!this.canBeTilled(event.block, options)) return;
    this.#tillBlock(event, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/shovel.ts
var ShovelComponent = class extends ToolComponent {
  static componentId = AddonUtils.makeId("shovel");
  struct = object({
    size: defaulted(number(), 1),
    block: defaulted(isBlock, "grass_path")
  });
  /**
   * Makes this item flatten dirt like a shovel.
   */
  constructor() {
    super();
    this.onUseOn = this.onUseOn.bind(this);
  }
  getBlock(block, options) {
    return options.block;
  }
  /**
   * Convert the block to a dirt path.
   * @param {Block} block The block that should be converted to a dirt path.
   * @param {ItemUseOnEvent} event The item event for context.
   */
  convertBlock(block, event, options) {
    if (!this.canBeFlattened(block, options)) return;
    block.setType(this.getBlock(block, options));
  }
  #flattenBlock(event, options) {
    event.block.dimension.playSound("use.gravel", event.block.location, {
      volume: 1
    });
    offsetVolume({ x: options.size, y: 0, z: options.size }, (pos) => {
      try {
        const target = event.block.offset(pos);
        if (!target) return;
        return this.convertBlock(target, event, options);
      } catch (err) {
      }
    });
  }
  canBeFlattened(block, options) {
    const target = this.getBlock(block, options);
    return block.hasTag("dirt") && !block.matches(target) && !block.hasTag("farmland") && !block.typeId.includes("farmland");
  }
  onUseOn(event, args) {
    const options = create(args.params, this.struct);
    if (!this.canBeFlattened(event.block, options)) return;
    this.#flattenBlock(event, options);
  }
};

// node_modules/@lpsmods/mc-utils/src/itemcomponent/writable_book.ts
import {
  EquipmentSlot as EquipmentSlot20
} from "@minecraft/server";
var WritableBookComponent = class {
  static componentId = AddonUtils.makeId("writable_book");
  struct = object({
    max_pages: defaulted(number(), 50)
  });
  /**
   * Writeable book item behavior.
   */
  constructor() {
    this.onUse = this.onUse.bind(this);
  }
  onUse(event, args) {
    if (!event.itemStack) return;
    const options = create(args.params, this.struct);
    this.show(event.source, event.itemStack, 1, options);
  }
  saveItem(player, itemStack) {
    const equ = player.getComponent("equippable");
    if (!equ) return;
    equ.setEquipment(EquipmentSlot20.Mainhand, itemStack);
  }
  // Set itemstack when updated.
  show(player, itemStack, page, options) {
    const body = itemStack.getDynamicProperty(`mcutils:page_${page}`);
    const maxPages = options.max_pages;
    const form = {
      title: {
        translate: "book.pageIndicator",
        with: {
          rawtext: [{ text: page.toString() }, { text: maxPages.toString() }]
        }
      },
      body: TextUtils.renderMarkdown(body ?? "*Page empty*") + "\n\n",
      buttons: [
        {
          label: "Previous Page",
          onClick: (event) => {
            this.show(player, itemStack, page - 1, options);
          },
          condition: (event) => page > 1
        },
        {
          label: "Next Page",
          onClick: (event) => {
            this.show(player, itemStack, page + 1, options);
          },
          condition: (event) => page < maxPages
        },
        {
          label: "Edit Page",
          onClick: (event) => {
            const modal = {
              title: `Editing Page ${page}`,
              options: {
                content: { type: "text", label: "Content", value: body }
              },
              submitLabel: "#addExternalServerScreen.saveButtonLabel",
              onSubmit: (formEvent) => {
                itemStack.setDynamicProperty(`mcutils:page_${page}`, formEvent.formResult.content);
                this.saveItem(player, itemStack);
                this.show(player, itemStack, page, options);
              }
            };
            const edit = new ModalFormHandler(modal);
            edit.show(player);
          }
        }
      ]
    };
    const ui = new ActionFormHandler(form);
    ui.show(player);
  }
};

// node_modules/@lpsmods/mc-utils/src/loot/block_loot_handler.ts
import { GameMode as GameMode6, system as system29, world as world37 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/loot/entity_loot_handler.ts
import { world as world38 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/developer_tools/base.ts
import { Player as Player18 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/developer_tools/tools.ts
import { Player as Player17 } from "@minecraft/server";
var DevTool = class _DevTool {
  static all = /* @__PURE__ */ new Map();
  id;
  options;
  constructor(id, options) {
    this.id = id;
    this.options = options ?? {};
    _DevTool.all.set(id, this);
  }
};
var PlayerDataTool = class _PlayerDataTool extends DevTool {
  static toolId = "player_data";
  constructor() {
    super(_PlayerDataTool.toolId, { name: "Show Player Data", description: "Displays player data in the action bar." });
  }
  onTick(event) {
    if (!(event.entity instanceof Player17)) return;
    const dim = event.entity.dimension;
    const { x: x2, y: y2, z: z2 } = event.entity.location;
    const rot = event.entity.getRotation();
    const dir = DirectionUtils.rot2dir(rot);
    const d2 = dim.id.replace("minecraft:", "");
    const b2 = dim.getBiome({ x: x2, y: y2, z: z2 }).id.replace("minecraft:", "");
    event.entity.onScreenDisplay.setActionBar({
      text: `\xA7lPlayer Data\xA7r
Dimension: ${d2}
Biome: ${b2}
Position: ${x2.toFixed(2)}, ${y2.toFixed(2)}, ${z2.toFixed(
        2
      )}
Rotation: ${rot.x.toFixed(2)} ${rot.y.toFixed(2)}
Facing Direction: ${dir}`
    });
  }
};
new PlayerDataTool();

// node_modules/@lpsmods/mc-utils/src/main.ts
import { system as system30 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/mixins.ts
import { ItemStack as ItemStack19, Block as Block29, ScoreboardObjective as ScoreboardObjective2, Player as Player19, Entity as Entity28 } from "@minecraft/server";
ItemStack19.prototype.startCooldown = function(player) {
  ItemUtils.startCooldown(this, player);
};
ItemStack19.prototype.executeMolang = function(expression) {
  return MolangUtils.item(this, expression);
};
Block29.prototype.executeMolang = function(expression) {
  return MolangUtils.block(this, expression);
};
Block29.prototype.clearDynamicProperties = function() {
  const store = new DataStorage2(`mcutils:block_${this.location.x},${this.location.y},${this.location.z}`);
  store.clear();
};
Block29.prototype.getDynamicProperty = function(identifier) {
  const store = new DataStorage2(`mcutils:block_${this.location.x},${this.location.y},${this.location.z}`);
  return store.getItem(identifier);
};
Block29.prototype.getDynamicPropertyIds = function() {
  const store = new DataStorage2(`mcutils:block_${this.location.x},${this.location.y},${this.location.z}`);
  return store.keys();
};
Block29.prototype.getDynamicPropertyTotalByteCount = function() {
  const store = new DataStorage2(`mcutils:block_${this.location.x},${this.location.y},${this.location.z}`);
  return store.getSize();
};
Block29.prototype.setDynamicProperty = function(identifier, value) {
  const store = new DataStorage2(`mcutils:block_${this.location.x},${this.location.y},${this.location.z}`);
  store.setItem(identifier, value);
};
Block29.prototype.getState = function(stateName) {
  return this.permutation.getState(stateName);
};
Block29.prototype.setState = function(stateName, value) {
  BlockUtils.setState(this, stateName, value);
};
Block29.prototype.incrementState = function(stateName, amount) {
  return BlockUtils.incrementState(this, stateName, amount);
};
Block29.prototype.decrementState = function(stateName, amount) {
  return BlockUtils.decrementState(this, stateName, amount);
};
Block29.prototype.getEnergyLevel = function() {
  const level = this.getDynamicProperty("api:energy_level");
  if (level === void 0) return void 0;
  return level;
};
Block29.prototype.setEnergyLevel = function(amount) {
  this.setDynamicProperty("api:energy_level", amount);
};
Block29.prototype.increaseEnergyLevel = function(amount) {
  const value = (this.getEnergyLevel() ?? 0) + (amount ?? 1);
  this.setEnergyLevel(value);
  return value;
};
Block29.prototype.decreaseEnergyLevel = function(amount) {
  const value = (this.getEnergyLevel() ?? 0) - (amount ?? 1);
  this.setEnergyLevel(value);
  return value;
};
Entity28.prototype.executeMolang = function(expression) {
  return MolangUtils.entity(this, expression);
};
Player19.prototype.applyArmor = function(armorSet, condition) {
  PlayerUtils.applyArmor(this, armorSet, condition);
};
ScoreboardObjective2.prototype.tryGetScore = function(name, defaultValue) {
  return WorldUtils.tryGetScore(this, name, defaultValue ?? 0);
};
String.prototype.toTitleCase = function() {
  return TextUtils.titleCase(this);
};

// node_modules/@lpsmods/mc-utils/src/area_detector.ts
import { BlockVolume as BlockVolume4, world as world39 } from "@minecraft/server";

// node_modules/@lpsmods/mc-utils/src/queue.ts
import { system as system31, world as world40 } from "@minecraft/server";

// scripts/command/debug.ts
var DebugCommand = class {
  static registered = false;
  static options = {
    name: makeId("debug"),
    description: "Debug configuration.",
    permissionLevel: 1,
    mandatoryParameters: [{ name: makeId("debug_action"), type: CustomCommandParamType3.Enum }]
  };
  static execute(ctx, debugAction) {
    const dim = CustomCommandUtils.getDimension(ctx);
    switch (debugAction) {
      case "refresh":
        refreshBlocks(dim);
        return { status: 0, message: "Refreshed all blocks!" };
      case "config":
        const player = CustomCommandUtils.getPlayer(ctx);
        system32.run(() => {
          showConfig(player);
        });
        return { status: 0, message: "Showing config!" };
    }
    return { status: 1, message: "Unknown action!" };
  }
  static register(registry) {
    if (this.registered) return;
    registry.registerEnum(makeId("debug_action"), ["refresh", "config"]);
    registry.registerCommand(this.options, this.execute);
    this.registered = true;
  }
};

// scripts/config.ts
var worldSettings = new Settings(makeId("config"));
worldSettings.defineProperty("vanilla", { type: "boolean", value: true });
worldSettings.defineProperty("modded", { type: "string", value: "{}" });

// node_modules/@bedrock-oss/add-on-registry/registry.js
var Registry2 = {
  "andexsa": {
    name: "8Crafter's Entity Scale, NBT, and Behavior Modifier, Bossbar, and Morph Addon",
    creator: "8Crafter"
  },
  "andexdb": {
    name: "8Crafter's Server Utilities & Debug Sticks",
    creator: "8Crafter"
  },
  "andexrp": {
    name: "8Crafter's Entity Scale, NBT, and Behavior Modifier, Bossbar, and Morph Addon",
    creator: "8Crafter"
  },
  "andexsl": {
    name: "8Crafter's Secret Items Loader",
    creator: "8Crafter"
  },
  "aria_pp": {
    name: "Planes Pro",
    creator: "AriaCreations"
  },
  "ascent_paint": {
    name: "Paint Add-On",
    creator: "ASCENT"
  },
  "ascent_htcg": {
    name: "Hermitcraft TCG Add-On",
    creator: "Hermitcraft x ASCENT"
  },
  "bf_rb": {
    name: "Biomes",
    creator: "Block Factory"
  },
  "bs_bwad": {
    name: "Builders Wands",
    creator: "Block Studios"
  },
  "bluemods": {
    name: "BlueMods Anticheat",
    creator: "BlueShadow"
  },
  "cc_fairytales": {
    name: "Fairy Tales",
    creator: "Chillcraft Studios"
  },
  "cc_abyss": {
    name: "Abyssal Echoes",
    creator: "Chillcraft Studios"
  },
  "cc_mechs": {
    name: "Mech Expansion",
    creator: "Chillcraft Studios"
  },
  "cc_su": {
    name: "SCP: Uncaged Add-On",
    creator: "Cloud Corp"
  },
  "darkosto_elemental_crops": {
    name: "Elemental Crops",
    creator: "Darkosto"
  },
  "float_fc": {
    name: "Forest Craft",
    creator: "Float Studios"
  },
  "float_fca": {
    name: "Fur Craft",
    creator: "Float Studios"
  },
  "float_br": {
    name: "The Backrooms Add-On",
    creator: "Float Studios"
  },
  "fl_heli": {
    name: "Helicopters+",
    creator: "Floruit"
  },
  "fl_opp": {
    name: "Ores++",
    creator: "Floruit"
  },
  "fl_wings": {
    name: "Wings++",
    creator: "Floruit"
  },
  "floruit_senna": {
    name: "Senna World",
    creator: "Floruit"
  },
  "canopy": {
    name: "Canopy",
    creator: "ForestOfLight"
  },
  "construct": {
    name: "Construct",
    creator: "ForestOfLight"
  },
  "understudy": {
    name: "Understudy",
    creator: "ForestOfLight"
  },
  "statistic-display": {
    name: "Statistic Display",
    creator: "ForestOfLight"
  },
  "nudge": {
    name: "Nudge",
    creator: "ForestOfLight"
  },
  "gm1_ord": {
    name: "Sonic",
    creator: "Gamemode One"
  },
  "gm1_zen": {
    name: "How to Train Your Dragon",
    creator: "Gamemode One"
  },
  "gds_icu": {
    name: "Combat Utilities",
    creator: "Glowfischdesigns"
  },
  "gds_we": {
    name: "World Editing",
    creator: "Glowfischdesigns"
  },
  "hf_mzs": {
    name: "Mowzie\u2019s Mobs",
    creator: "Honeyfrost"
  },
  "jm": {
    name: "jeanmajid",
    creator: "jeanmajid"
  },
  "jig_atw": {
    name: "ALL THE WOOL",
    creator: "Jigarbov Productions"
  },
  "jig_bmu": {
    name: "Battle Mutants",
    creator: "Jigarbov Productions"
  },
  "jig_ccomp": {
    name: "Computers",
    creator: "Jigarbov Productions"
  },
  "jig_mtd": {
    name: "Detect-Ore",
    creator: "Jigarbov Productions"
  },
  "jig_pcs": {
    name: "Papercraft Mob Stickers",
    creator: "Jigarbov Productions"
  },
  "jig_pco": {
    name: "Advanced Compass",
    creator: "Jigarbov Productions"
  },
  "jig_poip": {
    name: "Poisonous Potato",
    creator: "Jigarbov Productions"
  },
  "jig_teta": {
    name: "Tetris\xAE Add-On",
    creator: "Jigarbov Productions"
  },
  "jig_common": {
    name: "Cross-AddOn Jigarbov Pack",
    creator: "Jigarbov Productions"
  },
  "kubo_mg": {
    name: "MORPH Add-On",
    creator: "Kubo Studios"
  },
  "kubo_ss": {
    name: "SECURITY SYSTEMS Add-On",
    creator: "Kubo Studios"
  },
  "kubo_mv": {
    name: "VILLAGERS++ Add-On",
    creator: "Kubo Studios"
  },
  "kubo_aj": {
    name: "ANIME JUTSU Add-On",
    creator: "Kubo Studios"
  },
  "kubo_rpg": {
    name: "RPG Add-On",
    creator: "Kubo Studios"
  },
  "kubo_fs": {
    name: "FISHING++ Add-On",
    creator: "Kubo Studios"
  },
  "lpsm_assetsplus": {
    name: "Assets+",
    creator: "Legopitstop"
  },
  "lpsm_more_pumpkins": {
    name: "More Pumpkins",
    creator: "Legopitstop"
  },
  "mobpie_furn": {
    name: "Furniture Add-On",
    creator: "Mob Pie"
  },
  "mobpie_animal": {
    name: "Animals Add-On",
    creator: "Mob Pie"
  },
  "mobpie_cars": {
    name: "Luxury Cars Add-On",
    creator: "Mob Pie"
  },
  "mobpie_doors": {
    name: "Secret Doors Add-On",
    creator: "Mob Pie"
  },
  "mco_tde": {
    name: "The Dawn Era",
    creator: "Mush Co"
  },
  "nps_mot": {
    name: "More Ores and Tools",
    creator: "Netherpixel"
  },
  "oreville_15yr": {
    name: "15 Year Party Supplies",
    creator: "Oreville Studios"
  },
  "oreville_vm": {
    name: "Vibrant Memories Add-On",
    creator: "Oreville Studios"
  },
  "oreville_rb": {
    name: "Realistic Biomes Add-On",
    creator: "Oreville Studios"
  },
  "oreville_tc": {
    name: "Time Capsule Add-On",
    creator: "Oreville Studios"
  },
  "oreville_wb": {
    name: "World Builder Add-On",
    creator: "Oreville Studios"
  },
  "oreville_hp": {
    name: "Health Bars Add-On",
    creator: "Oreville Studios"
  },
  "panascais_realism": {
    name: "REALISM \\ Fields + Forests",
    creator: "Panascais"
  },
  "panascais_dwellers": {
    name: "DWELLERS Add-On",
    creator: "Panascais"
  },
  "panascais_end": {
    name: "Eternal End Add-On",
    creator: "Panascais"
  },
  "pu_biomes": {
    name: "MORE BIOMES Add-On",
    creator: "Pixelusion"
  },
  "pu_bn": {
    name: "BURNT Add-On",
    creator: "Pixelusion"
  },
  "pu_blasters": {
    name: "BLASTERS Add-On",
    creator: "Pixelusion"
  },
  "pixelusion_dbp": {
    name: "PORTAL BACKPACKS Add-On",
    creator: "Pixelusion"
  },
  "pixelusion_td": {
    name: "Training Dummies Add-On",
    creator: "Pixelusion"
  },
  "pu_se": {
    name: "SHIELDS Add-On",
    creator: "Pixelusion"
  },
  "pod_farm": {
    name: "FARMING",
    creator: "Podcrash"
  },
  "pod_gard": {
    name: "GARDENING",
    creator: "Podcrash"
  },
  "pod_engi": {
    name: "MACHINES",
    creator: "Podcrash"
  },
  "pod_rpg": {
    name: "RPG SKILLS",
    creator: "Podcrash"
  },
  "pod_trn": {
    name: "TRAINS",
    creator: "Podcrash"
  },
  "pokeb": {
    name: "PokeBedrock",
    creator: "Smell of Curry"
  },
  "httyd": {
    name: "Age of Berk",
    creator: "S3XT4 Studios"
  },
  "sqst_bkpk": {
    name: "Backpacks",
    creator: "Scai Quest"
  },
  "sqst_ihfs": {
    name: "AutoFisher",
    creator: "Scai Quest"
  },
  "sqst_oreb": {
    name: "Ore Beetles",
    creator: "Scai Quest"
  },
  "sqst_plsh": {
    name: "Plushies",
    creator: "Scai Quest"
  },
  "sqst_xpcb": {
    name: "XP Crystal Bank",
    creator: "Scai Quest"
  },
  "sqst_mtls": {
    name: "Multitool",
    creator: "Scai Quest"
  },
  "shapescape_ext": {
    name: "The Extinct",
    creator: "Shapescape"
  },
  "spark_portals": {
    name: "Spark Portals",
    creator: "Spark Universe"
  },
  "spark": {
    name: "RealismCraft",
    creator: "Spark Universe"
  },
  "spark_vfx": {
    name: "Realism VFX",
    creator: "Spark Universe"
  },
  "spark_disasters": {
    name: "Insane Disasters",
    creator: "Spark Universe"
  },
  "spark_amm1": {
    name: "Lava Chicken Add-On",
    creator: "Spark Universe"
  },
  "spark_amm2": {
    name: "A Minecraft Movie: Add-On",
    creator: "Spark Universe"
  },
  "spark_amm3": {
    name: "A Minecraft Movie Jetpack Add-On",
    creator: "Spark Universe"
  },
  "spark_pets": {
    name: "Spark Pets (Lite)",
    creator: "Spark Universe"
  },
  "spark_pets_pro": {
    name: "Spark Pets (Premium)",
    creator: "Spark Universe"
  },
  "spark_spongebob": {
    name: "SpongeBob SquarePants",
    creator: "Spark Universe"
  },
  "squaredreams_fhd": {
    name: "Furniture HD",
    creator: "Square Dreams"
  },
  "squaredreams_realism": {
    name: "Realism+",
    creator: "Square Dreams"
  },
  "squaredreams_bam": {
    name: "Morph Into Anything",
    creator: "Square Dreams"
  },
  "sf_gaa": {
    name: "McDonald's Add-On",
    creator: "Starfish Studios"
  },
  "sf_cma": {
    name: "CRAFTYMON",
    creator: "Starfish Studios"
  },
  "sf_hba": {
    name: "Hamsters+",
    creator: "Starfish Studios"
  },
  "sf_scp": {
    name: "Can You Survive?",
    creator: "Starfish Studios"
  },
  "sf_hei": {
    name: "Moana 2",
    creator: "Starfish Studios"
  },
  "sf_afm": {
    name: "Another Furniture",
    creator: "Starfish Studios"
  },
  "sf_nba": {
    name: "Naturalist",
    creator: "Starfish Studios"
  },
  "sf.baby_dragons": {
    name: "DRAGON PETS",
    creator: "Starfish Studios"
  },
  "stark_ep": {
    name: "Enchantments Plus",
    creator: "StarkTMA"
  },
  "tm_aqc": {
    name: "Aquaculture",
    creator: "Team Metallurgy"
  },
  "mb_af": {
    name: "Auto Factory",
    creator: "Team Metallurgy"
  },
  "tep_lm": {
    name: "LUNAR MOON Add-On",
    creator: "Teplight"
  },
  "twf_jb": {
    name: "Chomp",
    creator: "The World Foundry"
  },
  "twfae_cos": {
    name: "Lamp Lights",
    creator: "The World Foundry"
  },
  "twf_bmt": {
    name: "Bubble",
    creator: "The World Foundry"
  },
  "twf_calm": {
    name: "C.A.L.M.",
    creator: "The World Foundry"
  },
  "snst_bckp": {
    name: "Backpacks++ Add-On",
    creator: "ThunderAy"
  },
  "snst_morph": {
    name: "BE a MOB Add-On",
    creator: "ThunderAy"
  },
  "senior_bv": {
    name: "Vanilla Biomes+ Add-On",
    creator: "ThunderAy"
  },
  "tomhmagic_realight": {
    name: "Realight Reimagined",
    creator: "Tomhmagic Creations"
  },
  "thm_ecp": {
    name: "Economy+",
    creator: "Tomhmagic Creations"
  },
  "thm_rmt": {
    name: "Realm Management Tool",
    creator: "Tomhmagic Creations"
  },
  "ulkd_ess": {
    name: "Essentials",
    creator: "Unlinked"
  },
  "ulkd_alch": {
    name: "Alchemy",
    creator: "Unlinked"
  },
  "wypnt_ef": {
    name: "Epic Fantasy",
    creator: "Waypoint Studios"
  },
  "wonder_tech": {
    name: "Advanced Machines Add-On",
    creator: "Wonder"
  },
  "wonder_aps": {
    name: "Advanced Power Suits Add-On",
    creator: "Wonder"
  },
  "wonder_cons": {
    name: "Construction Add-On",
    creator: "Wonder"
  },
  "wonder_ores": {
    name: "More Ores Tools Armor Add-On",
    creator: "Wonder"
  },
  "xp_furniture": {
    name: "Furniture",
    creator: "XP GAMES"
  },
  "xp_dl": {
    name: "Dynamic Light",
    creator: "XP GAMES"
  },
  "xp_cd": {
    name: "Cave Dweller",
    creator: "XP GAMES"
  }
};

// scripts/main.ts
var START = { x: 1, y: 63, z: 1 };
var cachedBlocks = [];
var cachedMods = {};
var busy = false;
function getModIds() {
  if (Object.keys(cachedMods).length === 0) {
    const namespaces = [
      ...new Set(
        BlockTypes10.getAll().map((x2) => Identifier.parse(x2.id).namespace).filter((namespace) => namespace !== "minecraft" && namespace !== PROJECT_ID)
      )
    ];
    for (const name of namespaces) {
      const entry = Registry2[name];
      cachedMods[name] = entry ? entry.name : name;
    }
  }
  return cachedMods;
}
function setModState(identifier, value) {
  const modded = JSON.parse(worldSettings.get("modded") ?? "{}");
  modded[identifier] = value ?? true;
  worldSettings.set("modded", JSON.stringify(modded));
}
function isModEnabled(identifier) {
  const modded = JSON.parse(worldSettings.get("modded") ?? "{}");
  return identifier in modded ? modded[identifier] : true;
}
function showConfig(player) {
  if (busy) {
    player.sendMessage(`chat.${PROJECT_ID}:${busy}`);
    return;
  }
  const form = {
    title: `menu.${PROJECT_ID}:config`,
    options: {
      vanilla: { label: `options.${PROJECT_ID}:vanilla`, type: "toggle", value: worldSettings.get("vanilla") }
    },
    onSubmit(event) {
      const res = event.formResult;
      worldSettings.set("vanilla", res.vanilla);
      for (const id of Object.keys(getModIds())) {
        setModState(id, res[id]);
      }
      refreshBlocks(player.dimension, true);
    },
    submitLabel: "structure_block.mode.save"
  };
  const modded = JSON.parse(worldSettings.get("modded"));
  for (const [id, name] of Object.entries(getModIds())) {
    const label = { rawtext: [{ translate: "options.lpsm_dw:modded", with: { rawtext: [{ text: name }] } }] };
    form.options[id] = { label, type: "toggle", value: isModEnabled(id) };
  }
  const ui = new ModalFormHandler(form);
  ui.show(player);
}
function sortBlocks(left, right) {
  const c2 = left.id.split(":")[0];
  const l2 = right.id.split(":")[0];
  return "minecraft" === c2 && "minecraft" !== l2 ? -1 : "minecraft" !== c2 && "minecraft" === l2 ? 1 : left.id.localeCompare(right.id);
}
function getAllBlocks() {
  if (0 === cachedBlocks.length) {
    for (const e2 of BlockTypes10.getAll().sort(sortBlocks)) {
      const def = BlockPermutation15.resolve(e2.id);
      cachedBlocks.push(def);
    }
  }
  return cachedBlocks.filter((x2) => {
    const namespace = Identifier.parse(x2.type.id).namespace;
    if (namespace === "minecraft") return worldSettings.get("vanilla");
    return isModEnabled(namespace);
  });
}
function placeBlock(dimension, origin, block) {
  if (makeId("air") === block.type.id) return;
  for (let x2 = origin.x - 1; x2 < origin.x + 2; x2++) {
    for (let y2 = origin.y - 1; y2 < origin.y + 2; y2++) {
      for (let z2 = origin.z - 1; z2 < origin.z + 2; z2++) {
        const pos = { x: x2, y: y2, z: z2 };
        dimension.setBlockType(pos, makeId("air"));
      }
    }
  }
  dimension.setBlockPermutation(origin, block);
}
function* clearBlocks(dimension) {
  const vol = new BlockVolume5(
    Vector3Utils.add(START, { x: -1, y: -2, z: -1 }),
    Vector3Utils.add(START, { x: 7 * 16, y: 2, z: 7 * 16 })
  );
  const min2 = vol.getMin();
  const max2 = vol.getMax();
  for (let x2 = min2.x; x2 < max2.x; x2++) {
    for (let y2 = min2.y; y2 < max2.y; y2++) {
      for (let z2 = min2.z; z2 < max2.z; z2++) {
        try {
          dimension.setBlockType({ x: x2, y: y2, z: z2 }, "air");
        } catch (err) {
        }
      }
    }
    yield;
  }
}
function* placeBlocksGenerator(dimension, clear) {
  busy = true;
  if (clear) yield* clearBlocks(dimension);
  var x2 = START.x;
  var y2 = START.y;
  var z2 = START.z;
  for (const r2 of getAllBlocks()) {
    var pos = { x: x2, y: y2, z: z2 };
    try {
      placeBlock(dimension, pos, r2);
    } catch (o2) {
      x2 = x2 - 1 + 1;
    }
    if (x2 < 110) {
      x2 = x2 + 1 + 1;
    } else {
      x2 = 1;
      z2 = z2 + 1 + 1;
    }
  }
  busy = false;
  EntityUtils.removeAll({ type: "item" });
}
function refreshBlocks(dimension, clear = false) {
  system33.runJob(placeBlocksGenerator(dimension, clear));
}
function playerBreakBlock(event) {
  if (busy) return;
  refreshBlocks(event.dimension);
}
function playerSpawn(event) {
  if (!event.initialSpawn) return;
  if (busy) return;
  const dim = event.player.dimension;
  dim.runCommand("function load");
  refreshBlocks(dim, true);
}
function startup(event) {
  DebugCommand.register(event.customCommandRegistry);
}
world41.afterEvents.playerBreakBlock.subscribe(playerBreakBlock);
world41.afterEvents.playerSpawn.subscribe(playerSpawn);
system33.beforeEvents.startup.subscribe(startup);
export {
  refreshBlocks,
  showConfig
};

//# sourceMappingURL=../debug/main.js.map
